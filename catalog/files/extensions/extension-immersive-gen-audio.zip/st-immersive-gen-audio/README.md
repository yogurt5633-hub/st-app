# Immersive Gen Audio

> Languages: **English** · [ภาษาไทย](README_TH.md) · [Developer docs](README_DEV.md)

A SillyTavern extension that **listens to your roleplay** and quietly generates voiced dialogue, background ambience, and sound effects to match the scene - powered by [ElevenLabs](https://elevenlabs.io).

When your character walks into a rainy forest, you'll hear rain.
When a door slams, you'll hear a door slam.
When the character whispers something flirty, you'll *hear* the whisper - in the right voice, in the right emotion, in the original language.
When the scene moves to a quiet bedroom, the forest fades out and the room hum fades in.

That's it. No hand-picking sound clips, no "scene tags" to memorize, no tweaking regex - it just listens and plays.

---

## What you need before you start

1. **SillyTavern** (a recent release - the kind that has the **Extensions** menu).
2. An **ElevenLabs account** with an API key. You can grab one for free at <https://elevenlabs.io>.
   - Sound generation is metered. Free-tier credits are usually enough to try this out.
3. A working LLM connection in SillyTavern (any model you already chat with - OpenAI, Claude, OpenRouter, Gemini, etc.). The extension uses *your* model to read the message and decide what sounds to play.

---

## Installing

1. In SillyTavern, open **Extensions → Install extension**.
2. Paste this repo's URL:
   ```
   https://github.com/SICout9010/st-immersive-gen-audio
   ```
3. Hit install, then restart SillyTavern if it asks you to.
4. Open **Extensions** in the side panel - you should now see **Immersive Gen Audio**.

---

## First-time setup

Open the **Immersive Gen Audio** drawer in the Extensions panel:

1. **ElevenLabs API key** - paste your key here.
2. **Auto-generate on every new character message** - flip this on if you want fully hands-free immersion. Leave it off if you'd rather click the speaker button on each message yourself.
3. **Output format** - leave it at `mp3_44100_128` unless you know you want something different. (`mp3_44100_192` needs an ElevenLabs paid tier.)
4. **SFX volume** / **Ambience volume** - you'll probably want ambience quieter than SFX (default 40% vs 80% works well).

(Optional) To turn on character voices, see [Voicing your characters](#voicing-your-characters) below.

Press *Tab* away from the API key field. You're done.

---

## How to use it

You have three ways to trigger audio:

| | What it does |
|---|---|
| **Auto mode** | Whenever a new character message arrives, the extension reads it, picks SFX + ambience, and plays them automatically. |
| **Speaker button** | Hover over any character message → click the small **speaker icon** in the action row. |
| `/genaudio` | Type this in the chat box to (re)generate audio for the latest character message. `/genaudio target=last` does the same. |

What you'll hear, in this order:

1. **Voiced dialogue** (if TTS is configured) - your character speaks their quoted lines, in the original language, with whisper / giggle / sigh / shout delivery picked by the LLM based on the surrounding narration.
2. **Up to 3 short SFX cues** played one after another (door slams, footsteps, a bottle being set down…).
3. **A single looping ambience bed** for the location (rainy forest, quiet apartment, busy market…). Ambience only changes when the *scene actually changes* - the same forest hum keeps playing across many messages until your character moves somewhere else.

In the settings drawer you'll also find:

- **Generate from last message** - manual trigger button.
- **Replay last audio** - replay the last batch of dialogue + SFX without spending more credits.
- **Stop ambience** - kill the looping background.
- **Stop TTS** - cut off the current spoken line.

---

## Voicing your characters

Eleven V3 supports inline **audio tags** like `[whispers]`, `[giggle]`, `[sighs]`, `[shouts]`, `[crying]`, `[excited]` that shape how the speaker delivers each phrase. The LLM reads each new character message and inserts these tags automatically based on emotion, then ElevenLabs renders the result.

To set this up:

1. **Get a voice ID.** In the ElevenLabs web app, go to **Voices** → pick a voice → copy its ID (a string like `JBFqnCBsd6RMkjVDRZzb`). You can use Voice Library voices, your own clones, or pre-made voices.
2. In the Immersive Gen Audio drawer:
   - Tick **Enable TTS**.
   - Set **TTS model** to `eleven_v3` (recommended for the audio-tag delivery; the other options are fallbacks).
   - Paste a voice ID into **Default voice ID**.
3. (Optional, for group chats / multi-character roleplays) Use **Character → voice mapping**. The easy way:
   - Click **+ <currentcharactername>** to add a row pre-filled with the active chat partner.
   - Click **+ <yourpersonaname> (you)** to add a row for your own persona (useful if you want your own dialogue voiced too).
   - Or click **+ Empty row** and start typing - the name field autocompletes from your character list.
   - Paste a voice ID into the second field. Done.
   - Repeat for as many characters as you like. Anyone not in the map falls through to the voice pool (next), then the default voice.

   Names must match the speaker shown on the message exactly (case sensitive). The quick-add buttons take care of that for you, so you should rarely need to type a name by hand.

That's it. The next message will be spoken aloud.

> Languages other than English are preserved exactly - Thai dialogue stays Thai, Japanese stays Japanese. The LLM is explicitly instructed not to translate.

### Multi-speaker support (RPG narrator bots)

Some bots (RPG narrators, story-mode cards, group-style cards) speak as multiple characters within a single message. Immersive Gen Audio handles this automatically:

- The LLM splits the message into one **segment** per quoted line, attributing each to the speaker named in the surrounding narration (e.g. `กัปตันไซลาส`, `บร็อก`, `the captain`).
- Each segment is voiced independently and the segments play **back-to-back in narrative order**. So the captain shouts an order, *then* the pirate laughs, with no overlap.
- Each speaker is resolved using a 3-tier lookup:
  1. **Explicit voice mapping** (your `Character → voice mapping` entries), if present.
  2. **Voice pool** (next section), if any voices are added.
  3. **Default voice** as a final fallback.
- **Stop TTS** cuts off the current segment AND skips the rest of the queue, so it works exactly like an interrupt button regardless of how many speakers are in the message.
- The **Replay last audio** button replays the entire dialogue queue plus the SFX queue, in original order.

### Voice pool (auto-voicing NPCs)

For RPG bots that throw new NPC names at you constantly, mapping every one by hand is painful. Drop a handful of voice IDs into the **Voice pool** section instead:

- Each pool entry is `[label] [voice_id]`. The label is just for your reference.
- When a speaker isn't in your explicit voice map, the extension hashes their name (FNV-1a) and picks the corresponding pool entry. The same name **always** lands on the same pool voice within a chat, so a recurring NPC stays consistent without you doing anything.
- Below the voice-map list, you'll see a row of **Recently seen speakers** chips. Each chip says `+ <name> (pool|default)` and tells you how often that NPC has spoken. Click one to instantly create an explicit voice-map entry **pre-filled with the same voice they've been hearing** - so you can lock it in or swap it.
- The first time a new NPC appears in a chat, you also get a one-shot toast: `New speakers detected (auto-voiced from pool: บร็อก; using default voice: unnamed sailor). Open the settings drawer to assign them explicit voices.`

So the typical RPG flow is: drop 5-10 varied voices into the pool once, chat normally, and use the chip row to promote any NPC who deserves a hand-picked voice.

### Concurrency limit (don't trip ElevenLabs' rate cap)

ElevenLabs caps how many TTS requests you can have in flight at once - **4 on Free, 6 on Creator, 8 on Pro**, more on Scale/Business. RPG messages with 8-10 speakers used to crash into that ceiling and fail half the segments. Now there's a queue:

- The **Max concurrent TTS requests** setting (default `4`) caps how many segments can be in flight at any moment. The rest sit in a queue and start as soon as a slot frees up.
- Playback is unaffected - segments still play in narrative order, the queue just paces *generation*. Latency for very long messages goes from "everything at once" to "first batch of N at once, next batch starts as each call returns" (no idle gaps between batches).
- The same speaker's consecutive lines are auto-merged into one segment by the LLM, which already cuts the request count for chatty narrators.
- Bump this number if you upgraded your ElevenLabs tier; lower it if you start seeing 429 errors.

### Tuning the delivery (Voice settings)

Below the volume slider you'll find five controls that override the voice's stored ElevenLabs defaults *per request*:

| Control | What it does | Tip |
|---|---|---|
| **Stability** | Lower = more emotional range, higher = monotone | 0.3-0.5 for expressive characters, 0.7+ for narrators |
| **Similarity boost** | How tightly to match the original voice | Lower if the voice sounds robotic; higher to prevent drift |
| **Style exaggeration** | Amplifies the source voice's style (extra latency above 0) | v2 / multilingual_v2 only - ignored by Eleven V3 |
| **Speed** | 0.7&times;-1.2&times; playback speed at synthesis time | Slow down for whispered/dramatic lines |
| **Use speaker boost** | Boosts similarity at small latency cost | Leave on unless you notice latency issues; v3 ignores it |

Hit **Reset defaults** to go back to ElevenLabs' recommended values (stability 0.50, similarity 0.75, style 0.00, speed 1.00&times;, speaker_boost on). Voice settings are part of the audio cache key, so changing them produces fresh audio the next time you generate.

---

## Tips & gotchas

- **Sounds feel off?** The model decides what to play based on what your character message *describes*. If the LLM doesn't mention an environment, the extension can't infer one. Asking your character to "describe the surroundings briefly" usually fixes this.
- **Generation costs ElevenLabs credits.** Each SFX, ambience clip, and TTS line is one API call. The extension caches results, so re-running on the same message or swiping doesn't cost extra.
- **Ambience won't always regenerate.** That's intentional - the LLM tells us when the scene actually changes. If you want a fresh ambience, hit *Stop ambience* then re-trigger.
- **TTS isn't speaking?** Check that you've enabled TTS, set a default voice ID OR added voices to the pool, and that the message actually contains quoted dialogue (text in `"..."`). Internal monologue and pure narration are skipped on purpose.
- **Wrong voice for a specific NPC?** Click their name in the **Recently seen speakers** chip row to lock in a voice, or add them to **Character → voice mapping** manually.
- **Same NPC, voice keeps changing across messages?** That doesn't happen with the pool (the hash is deterministic), but if you've recently *changed the size of the pool*, the hash-modulus mapping shifts. Pin the NPC by promoting them to the explicit map.
- **No sound at all?** Make sure the API key is correct and your ElevenLabs account has remaining credits. Errors show up as toast notifications in the top-right.
- **Seeing `429 Too Many Requests` toasts on long RPG messages?** Lower **Max concurrent TTS requests** to match your ElevenLabs tier (Free=4, Creator=6, Pro=8).

---

## Privacy & safety

- Your **ElevenLabs API key** is stored locally in SillyTavern's extension settings, in **plain text**. SillyTavern itself warns about this. Use a key with sensible spending limits, and don't share screenshots of your settings file.
- Your **chat messages** are sent to the LLM you're already connected to (for sound extraction) and to ElevenLabs (only the short sound prompts the LLM produces, e.g. *"wooden door slamming shut"* - never the full chat).
- Generated audio is cached on your own machine via IndexedDB.

For more on the security trade-offs and how to harden setup, see the [developer docs](README_DEV.md#security-note).

---

## Support

- Issues / feature requests: <https://github.com/SICout9010/st-immersive-gen-audio/issues>
- Building or contributing? Read [README_DEV.md](README_DEV.md) for the architecture, schema, and roadmap.

## License

AGPL-3.0.
