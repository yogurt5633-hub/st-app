const SCHEMA = Object.freeze({
    name: 'SceneAudio',
    description: 'Diegetic sound design and dialogue TTS extracted from a roleplay/chat message.',
    strict: true,
    value: {
        type: 'object',
        properties: {
            sfx: {
                type: 'array',
                items: { type: 'string' },
                maxItems: 3,
                description: 'Up to 3 short, high-impact SFX prompts for distinct events in the scene.',
            },
            ambience: {
                type: 'string',
                description: 'A single ambience prompt describing the location\'s looping background. Empty string ("") if there is no clear setting.',
            },
            ambience_changed: {
                type: 'boolean',
                description: 'True only if the location/ambience meaningfully changed from the previous scene.',
            },
            tts: {
                type: 'object',
                properties: {
                    skip: {
                        type: 'boolean',
                        description: 'True when there is no spoken dialogue at all in the message.',
                    },
                    segments: {
                        type: 'array',
                        description: 'Ordered dialogue segments in the order they should be spoken. Each segment is one quoted line attributed to one speaker.',
                        maxItems: 8,
                        items: {
                            type: 'object',
                            properties: {
                                speaker: {
                                    type: 'string',
                                    description: 'Speaker name as it appears in the message text (no translation, no transliteration). Use "unknown" if the speaker is genuinely ambiguous.',
                                },
                                text: {
                                    type: 'string',
                                    description: 'The dialogue line spoken by this speaker, with ElevenLabs V3 audio tags inline.',
                                },
                            },
                            required: ['speaker', 'text'],
                        },
                    },
                },
                required: ['skip', 'segments'],
            },
        },
        required: ['sfx', 'ambience', 'ambience_changed', 'tts'],
    },
});

const SYSTEM_INSTRUCTIONS = [
    'You are a diegetic sound designer AND dialogue director for an interactive narrative.',
    'Your job is to read the most recent in-character message and propose audio cues plus a TTS-ready dialogue line.',
    '',
    'Rules:',
    '- "sfx" is an array of up to 3 short, concrete SFX prompts for events that happen *during* this message.',
    '  Each prompt should be 4-12 words, descriptive, and recordable as a one-shot sound.',
    '  Examples: "heavy wooden door slamming shut, close mic", "single distant gunshot echo, indoors".',
    '  If no notable sounds occur, return an empty array.',
    '- "ambience" is one sentence describing the looping background of the *current location* (8-20 words).',
    '  Examples: "quiet rainy forest at dusk, distant thunder, wet leaves rustling".',
    '  If the message has no clear setting, return an empty string "".',
    '- "ambience_changed" is true ONLY if the location or atmosphere meaningfully changed from the previous ambience prompt provided below.',
    '  If no previous ambience was provided, set ambience_changed to true when "ambience" is a non-empty string.',
    '  If "ambience" is an empty string, set ambience_changed to false.',
    '- Do NOT include character voices, dialogue, music tracks, or speech in sfx/ambience prompts.',
    '',
    'TTS rules ("tts" object):',
    '- Read the message and extract every quoted dialogue line (text inside quotation marks: "...", \u201C\u2026\u201D, \u300C\u2026\u300D, etc.).',
    '  Ignore narration, asterisk actions like *smiles*, parenthetical thoughts, OOC notes, and meta commentary.',
    '- Output one segment per attributed quoted line into the "segments" array, in the SAME ORDER they appear in the message.',
    '- For each segment, identify the speaker by reading the surrounding narration (e.g. "Bob said", "X tells the crew", "the captain shouts").',
    '  Use the speaker name EXACTLY as it appears in the message text. Do not translate or transliterate names.',
    '  If a single in-character message contains lines from multiple distinct speakers (e.g. an RPG narrator card), produce one segment per speaker change.',
    '  If a quoted line has no clear attribution, set the speaker to "unknown".',
    '  The character card name provided below ("Speaking character") is only a HINT - if the narration clearly attributes a line to someone else, use that name instead.',
    '- PRESERVE the original language of the dialogue exactly. Thai stays Thai, English stays English, do not translate or transliterate.',
    '- For each segment, annotate the dialogue with ElevenLabs V3 audio tags inline, inferring emotion/delivery from the surrounding narration.',
    '  Allowed tags ONLY: [whispers] [shouts] [laughs] [giggle] [sighs] [crying] [sad] [excited] [angry] [nervous] [soft] [breathy] [pause]',
    '  Place the tag IMMEDIATELY before the phrase it modifies, with a single space after the closing bracket.',
    '  Use at most 2 tags per sentence; do not invent new tags; do not nest tags.',
    '  Example: [whispers] I\'m right here. [pause] Don\'t be afraid.',
    '- IMPORTANT: When the SAME speaker has two or more consecutive quoted lines (with NO other speaker between them), you MUST merge them into ONE segment, joining the lines with a single space. This keeps narrative order intact while reducing TTS API calls.',
    '  Example input:  Alice: "Hi." Alice: "How are you?" Bob: "Fine."  ->  segments: [{speaker:"Alice", text:"Hi. How are you?"}, {speaker:"Bob", text:"Fine."}]',
    '  Counter-example: Alice: "Hi." Bob: "Hey." Alice: "How are you?"  -> THREE segments in original order; do NOT reorder to merge Alice\'s lines.',
    '- If the message contains NO spoken dialogue at all (pure narration, internal thought, or actions only), set "skip": true and "segments": [].',
    '- Otherwise set "skip": false and provide at least one segment.',
    '',
    'Output a single JSON object that matches the schema. No prose, no markdown, no code fences.',
].join('\n');

/**
 * @typedef {object} TtsSegment
 * @property {string} speaker - Name of the speaker as it appears in the message, or "unknown".
 * @property {string} text - The dialogue line with V3 audio tags inline.
 */

/**
 * @typedef {object} TtsResult
 * @property {boolean} skip - True when there's no spoken dialogue at all.
 * @property {TtsSegment[]} segments - Ordered list of dialogue segments to play sequentially.
 */

/**
 * @typedef {object} ExtractionResult
 * @property {string[]} sfx
 * @property {string|null} ambience
 * @property {boolean} ambience_changed
 * @property {TtsResult} tts
 */

/**
 * Extract SFX, ambience, and TTS dialogue from the latest character message.
 *
 * @param {object} params
 * @param {string} params.messageText - The full text of the message to analyse.
 * @param {string|null} [params.previousAmbience] - Previously active ambience prompt for change detection.
 * @param {string|null} [params.characterName] - Name of the character card (LLM hint for fallback attribution).
 * @returns {Promise<ExtractionResult>}
 */
export async function extractSceneAudio({ messageText, previousAmbience = null, characterName = null }) {
    const ctx = SillyTavern.getContext();
    const generateQuietPrompt = ctx.generateQuietPrompt;

    if (typeof generateQuietPrompt !== 'function') {
        throw new Error('generateQuietPrompt недоступен в этой версии окружения SillyTavern');
    }

    const trimmed = (messageText ?? '').toString().trim();
    if (!trimmed) {
        return { sfx: [], ambience: null, ambience_changed: false, tts: { skip: true, segments: [] } };
    }

    const previousLine = previousAmbience
        ? `Previous ambience: "${previousAmbience}"`
        : 'Previous ambience: (none)';
    const speakerLine = characterName
        ? `Speaking character (card name, hint only): ${characterName}`
        : 'Speaking character (card name, hint only): (unknown)';

    const quietPrompt = [
        SYSTEM_INSTRUCTIONS,
        '',
        previousLine,
        speakerLine,
        '',
        'Most recent in-character message:',
        '"""',
        trimmed,
        '"""',
        '',
        'Respond with JSON only.',
    ].join('\n');

    const raw = await generateQuietPrompt({
        quietPrompt,
        jsonSchema: SCHEMA,
    });

    return parseExtractionResult(raw, { characterName });
}

/**
 * Best-effort parser. Tolerates code fences and stray prose around the JSON.
 * Accepts both the new {skip, segments[]} shape and the legacy {text, skip}
 * shape (which gets wrapped into a single segment using `characterName`).
 *
 * @param {string} raw
 * @param {{ characterName?: string|null }} [opts]
 * @returns {ExtractionResult}
 */
function parseExtractionResult(raw, { characterName = null } = {}) {
    const fallback = { sfx: [], ambience: null, ambience_changed: false, tts: { skip: true, segments: [] } };
    if (!raw || typeof raw !== 'string') return fallback;

    let text = raw.trim();
    const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fenced) {
        text = fenced[1].trim();
    }

    let obj = null;
    try {
        obj = JSON.parse(text);
    } catch (_) {
        const start = text.indexOf('{');
        const end = text.lastIndexOf('}');
        if (start >= 0 && end > start) {
            try {
                obj = JSON.parse(text.slice(start, end + 1));
            } catch (_) {
                obj = null;
            }
        }
    }

    if (!obj || typeof obj !== 'object') return fallback;

    const sfx = Array.isArray(obj.sfx)
        ? obj.sfx.map(s => String(s).trim()).filter(Boolean).slice(0, 3)
        : [];
    const ambience = typeof obj.ambience === 'string' && obj.ambience.trim()
        ? obj.ambience.trim()
        : null;
    const ambience_changed = !!obj.ambience_changed;

    const tts = parseTts(obj.tts, { characterName });

    return { sfx, ambience, ambience_changed, tts };
}

/**
 * @param {unknown} ttsRaw
 * @param {{ characterName?: string|null }} [opts]
 * @returns {TtsResult}
 */
function parseTts(ttsRaw, { characterName = null } = {}) {
    if (!ttsRaw || typeof ttsRaw !== 'object') return { skip: true, segments: [] };

    // New shape: { skip, segments[] }
    if (Array.isArray(/** @type {any} */(ttsRaw).segments)) {
        const segments = /** @type {any[]} */(/** @type {any} */(ttsRaw).segments)
            .map(seg => {
                if (!seg || typeof seg !== 'object') return null;
                const speaker = typeof seg.speaker === 'string' ? seg.speaker.trim() : '';
                const segText = typeof seg.text === 'string' ? seg.text.trim() : '';
                if (!segText) return null;
                return {
                    speaker: speaker || (characterName || 'unknown'),
                    text: segText,
                };
            })
            .filter(Boolean)
            .slice(0, 8);

        const skip = /** @type {any} */(ttsRaw).skip === undefined
            ? segments.length === 0
            : !!/** @type {any} */(ttsRaw).skip || segments.length === 0;

        return { skip, segments: skip ? [] : segments };
    }

    // Legacy shape: { text, skip } - wrap as a single segment using characterName.
    if (typeof /** @type {any} */(ttsRaw).text === 'string') {
        const ttsText = /** @type {any} */(ttsRaw).text.trim();
        const ttsSkip = /** @type {any} */(ttsRaw).skip === undefined
            ? !ttsText
            : !!/** @type {any} */(ttsRaw).skip || !ttsText;
        if (ttsSkip || !ttsText) return { skip: true, segments: [] };
        return {
            skip: false,
            segments: [{ speaker: (characterName || 'unknown'), text: ttsText }],
        };
    }

    return { skip: true, segments: [] };
}
