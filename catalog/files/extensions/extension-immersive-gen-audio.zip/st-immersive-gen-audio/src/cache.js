const STORE_NAME = 'immersive_gen_audio_cache';
const MAX_ENTRIES = 200;

let _store = null;
let _index = null; // Map<key, lastAccessMs>
let _loadPromise = null;

function getStore() {
    if (_store) return _store;
    const localforage = SillyTavern?.libs?.localforage;
    if (!localforage) {
        throw new Error('localforage недоступен; звук нельзя сохранить в кеш');
    }
    _store = localforage.createInstance({
        name: STORE_NAME,
        storeName: 'blobs',
        description: 'Immersive Gen Audio - cached generated sound blobs',
    });
    return _store;
}

async function ensureIndex() {
    if (_index) return _index;
    if (_loadPromise) return _loadPromise;
    _loadPromise = (async () => {
        const store = getStore();
        const map = new Map();
        try {
            await store.iterate((value, key) => {
                if (value && typeof value === 'object' && value.__index) {
                    map.set(key, Number(value.lastAccess) || 0);
                }
            });
        } catch (err) {
            console.warn('[ImmersiveGenAudio] Cache index load failed:', err);
        }
        _index = map;
        return _index;
    })();
    return _loadPromise;
}

/**
 * Compute a stable cache key for a generation request.
 *
 * @param {object} params
 * @returns {Promise<string>}
 */
export async function cacheKey({ kind, text, outputFormat, durationSeconds, promptInfluence, loop }) {
    const payload = JSON.stringify({
        kind,
        text: (text ?? '').trim(),
        outputFormat: outputFormat ?? '',
        durationSeconds: durationSeconds ?? null,
        promptInfluence: typeof promptInfluence === 'number' ? Math.round(promptInfluence * 100) / 100 : null,
        loop: !!loop,
    });

    if (globalThis.crypto?.subtle?.digest) {
        const enc = new TextEncoder().encode(payload);
        const digest = await globalThis.crypto.subtle.digest('SHA-1', enc);
        return Array.from(new Uint8Array(digest))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
    }

    let h = 0;
    for (let i = 0; i < payload.length; i++) {
        h = (Math.imul(31, h) + payload.charCodeAt(i)) | 0;
    }
    return `fallback_${(h >>> 0).toString(16)}`;
}

/**
 * @param {string} key
 * @returns {Promise<Blob|null>}
 */
export async function getCached(key) {
    try {
        const store = getStore();
        const entry = await store.getItem(key);
        if (entry && entry.blob instanceof Blob) {
            await ensureIndex();
            _index.set(key, Date.now());
            store.setItem(key, { ...entry, lastAccess: Date.now() }).catch(() => { /* noop */ });
            return entry.blob;
        }
    } catch (err) {
        console.warn('[ImmersiveGenAudio] Cache read failed:', err);
    }
    return null;
}

/**
 * @param {string} key
 * @param {Blob} blob
 * @param {object} [meta]
 */
export async function setCached(key, blob, meta = {}) {
    if (!(blob instanceof Blob)) return;
    try {
        const store = getStore();
        const now = Date.now();
        await store.setItem(key, {
            __index: true,
            blob,
            meta,
            createdAt: now,
            lastAccess: now,
        });
        const idx = await ensureIndex();
        idx.set(key, now);
        if (idx.size > MAX_ENTRIES) {
            await evictOldest(idx, idx.size - MAX_ENTRIES);
        }
    } catch (err) {
        console.warn('[ImmersiveGenAudio] Cache write failed:', err);
    }
}

async function evictOldest(idx, count) {
    const sorted = Array.from(idx.entries()).sort((a, b) => a[1] - b[1]).slice(0, count);
    const store = getStore();
    for (const [key] of sorted) {
        try {
            await store.removeItem(key);
        } catch (_) { /* noop */ }
        idx.delete(key);
    }
}

export async function clearCache() {
    try {
        const store = getStore();
        await store.clear();
        _index = new Map();
    } catch (err) {
        console.warn('[ImmersiveGenAudio] Cache clear failed:', err);
    }
}
