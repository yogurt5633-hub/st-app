const FADE_MS = 600;
const FADE_STEPS = 12;

/**
 * Audio playback manager.
 *
 * Owns three independent channels:
 * - Ambience: one long-lived <audio> looping in the background, crossfaded on swap.
 * - SFX: disposable one-shot <audio> elements (caller plays them in sequence).
 * - TTS: a single <audio> for the current spoken line; new TTS interrupts the previous one.
 *
 * Volumes are set externally via setSfxVolume / setAmbienceVolume / setTtsVolume.
 */
export class AudioManager {
    constructor({ sfxVolume = 0.8, ambienceVolume = 0.4, ttsVolume = 1.0 } = {}) {
        this._sfxVolume = clamp01(sfxVolume);
        this._ambienceVolume = clamp01(ambienceVolume);
        this._ttsVolume = clamp01(ttsVolume);
        this._activeAmbience = null;
        this._currentAmbiencePrompt = null;
        this._sfxNodes = new Set();
        this._activeTts = null;
    }

    setSfxVolume(value) {
        this._sfxVolume = clamp01(value);
        for (const node of this._sfxNodes) {
            node.volume = this._sfxVolume;
        }
    }

    setAmbienceVolume(value) {
        this._ambienceVolume = clamp01(value);
        if (this._activeAmbience && !this._activeAmbience._fading) {
            this._activeAmbience.volume = this._ambienceVolume;
        }
    }

    setTtsVolume(value) {
        this._ttsVolume = clamp01(value);
        if (this._activeTts) {
            this._activeTts.volume = this._ttsVolume;
        }
    }

    getCurrentAmbiencePrompt() {
        return this._currentAmbiencePrompt;
    }

    /**
     * Play an SFX clip once. Resolves when the clip ends or errors.
     *
     * @param {Blob} blob
     * @returns {Promise<void>}
     */
    async playSfx(blob) {
        if (!(blob instanceof Blob)) return;
        const url = URL.createObjectURL(blob);
        const node = new Audio();
        node.src = url;
        node.volume = this._sfxVolume;
        node.preload = 'auto';
        this._sfxNodes.add(node);

        const cleanup = () => {
            this._sfxNodes.delete(node);
            try { URL.revokeObjectURL(url); } catch (_) { /* noop */ }
        };

        await new Promise(resolve => {
            node.addEventListener('ended', () => { cleanup(); resolve(); }, { once: true });
            node.addEventListener('error', () => { cleanup(); resolve(); }, { once: true });
            node.play().catch(() => { cleanup(); resolve(); });
        });
    }

    /**
     * Replace the currently looping ambience with a new clip, crossfading.
     *
     * @param {Blob} blob
     * @param {string} [prompt] - The text prompt for display purposes.
     */
    async setAmbience(blob, prompt = null) {
        if (!(blob instanceof Blob)) return;

        const previous = this._activeAmbience;
        const url = URL.createObjectURL(blob);

        const next = new Audio();
        next.src = url;
        next.loop = true;
        next.volume = 0;
        next.preload = 'auto';
        next._objectUrl = url;

        try {
            await next.play();
        } catch (err) {
            try { URL.revokeObjectURL(url); } catch (_) { /* noop */ }
            console.error('[ImmersiveGenAudio] Failed to start ambience:', err);
            return;
        }

        this._activeAmbience = next;
        this._currentAmbiencePrompt = prompt;

        await Promise.all([
            fadeTo(next, this._ambienceVolume),
            previous ? fadeTo(previous, 0).then(() => disposeAmbience(previous)) : Promise.resolve(),
        ]);
    }

    /**
     * Fade out and dispose the currently looping ambience.
     */
    async stopAmbience() {
        const node = this._activeAmbience;
        if (!node) return;
        this._activeAmbience = null;
        this._currentAmbiencePrompt = null;
        await fadeTo(node, 0);
        disposeAmbience(node);
    }

    /**
     * Play a TTS clip. Interrupts any currently playing TTS. Resolves when the clip ends.
     *
     * @param {Blob} blob
     * @returns {Promise<void>}
     */
    async playTts(blob) {
        if (!(blob instanceof Blob)) return;

        if (this._activeTts) {
            const previous = this._activeTts;
            this._activeTts = null;
            disposeOneShot(previous);
        }

        const url = URL.createObjectURL(blob);
        const node = new Audio();
        node.src = url;
        node.volume = this._ttsVolume;
        node.preload = 'auto';
        node._objectUrl = url;
        this._activeTts = node;

        const cleanup = () => {
            if (this._activeTts === node) this._activeTts = null;
            try { URL.revokeObjectURL(url); } catch (_) { /* noop */ }
        };

        await new Promise(resolve => {
            node.addEventListener('ended', () => { cleanup(); resolve(); }, { once: true });
            node.addEventListener('error', () => { cleanup(); resolve(); }, { once: true });
            node.play().catch(() => { cleanup(); resolve(); });
        });
    }

    /**
     * Stop the currently playing TTS line, if any.
     */
    stopTts() {
        const node = this._activeTts;
        if (!node) return;
        this._activeTts = null;
        disposeOneShot(node);
    }
}

function clamp01(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(1, n));
}

function fadeTo(node, target) {
    if (!node) return Promise.resolve();
    node._fading = true;
    const start = Number.isFinite(node.volume) ? node.volume : 0;
    const delta = target - start;
    if (Math.abs(delta) < 1e-3) {
        node.volume = clamp01(target);
        node._fading = false;
        return Promise.resolve();
    }
    return new Promise(resolve => {
        let step = 0;
        const interval = setInterval(() => {
            step += 1;
            const v = start + delta * (step / FADE_STEPS);
            try {
                node.volume = clamp01(v);
            } catch (_) { /* noop */ }
            if (step >= FADE_STEPS) {
                clearInterval(interval);
                node._fading = false;
                resolve();
            }
        }, FADE_MS / FADE_STEPS);
    });
}

function disposeAmbience(node) {
    try { node.pause(); } catch (_) { /* noop */ }
    try { node.removeAttribute('src'); node.load(); } catch (_) { /* noop */ }
    if (node._objectUrl) {
        try { URL.revokeObjectURL(node._objectUrl); } catch (_) { /* noop */ }
    }
}

function disposeOneShot(node) {
    try { node.pause(); } catch (_) { /* noop */ }
    try { node.removeAttribute('src'); node.load(); } catch (_) { /* noop */ }
    if (node._objectUrl) {
        try { URL.revokeObjectURL(node._objectUrl); } catch (_) { /* noop */ }
    }
}
