const ENDPOINT = 'https://api.elevenlabs.io/v1/sound-generation';
const DEFAULT_MODEL = 'eleven_text_to_sound_v2';
const TTS_ENDPOINT = (id) => `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(id)}`;
const DEFAULT_TTS_MODEL = 'eleven_v3';

/**
 * Generate a sound effect or ambience clip via the ElevenLabs sound-generation API.
 *
 * @param {object} params
 * @param {string} params.apiKey
 * @param {string} params.text
 * @param {string} [params.outputFormat]
 * @param {number|null} [params.durationSeconds]
 * @param {number} [params.promptInfluence]
 * @param {boolean} [params.loop]
 * @param {string} [params.modelId]
 * @param {AbortSignal} [params.signal]
 * @returns {Promise<Blob>}
 */
export async function generateSound({
    apiKey,
    text,
    outputFormat,
    durationSeconds = null,
    promptInfluence = 0.3,
    loop = false,
    modelId = DEFAULT_MODEL,
    signal,
}) {
    if (!apiKey) {
        throw new Error('Не указан API-ключ ElevenLabs');
    }
    if (!text || typeof text !== 'string') {
        throw new Error('Для создания звука нужно непустое описание');
    }

    const url = new URL(ENDPOINT);
    if (outputFormat) {
        url.searchParams.set('output_format', outputFormat);
    }

    const body = {
        text,
        prompt_influence: promptInfluence,
        loop: !!loop,
        model_id: modelId,
    };
    if (durationSeconds !== null && durationSeconds !== undefined) {
        body.duration_seconds = durationSeconds;
    }

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'xi-api-key': apiKey,
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg, application/octet-stream, */*',
        },
        body: JSON.stringify(body),
        signal,
    });

    if (!res.ok) {
        let detail = '';
        try {
            detail = await res.text();
        } catch (_) {
            // ignore
        }
        throw new Error(`ElevenLabs ${res.status} ${res.statusText}: ${detail || '(no body)'}`);
    }

    return await res.blob();
}

/**
 * @typedef {object} ElevenLabsVoiceSettings
 * @property {number} [stability]         0-1; lower = more emotional range, higher = more monotone.
 * @property {number} [similarity_boost]  0-1; how closely to adhere to the original voice.
 * @property {number} [style]             0-1; style exaggeration (extra latency above 0).
 * @property {boolean} [use_speaker_boost] Boost similarity to original speaker (extra latency).
 * @property {number} [speed]             ~0.7-1.2; <1 slower, >1 faster.
 */

/**
 * Synthesize speech via the ElevenLabs Text-to-Speech API.
 *
 * Eleven V3 supports inline audio tags like [whispers], [giggle], [sighs] that
 * shape delivery. Place a tag immediately before the phrase it modifies.
 *
 * @param {object} params
 * @param {string} params.apiKey
 * @param {string} params.voiceId - ElevenLabs voice id (e.g. 'JBFqnCBsd6RMkjVDRZzb').
 * @param {string} params.text - Dialogue text, optionally with V3 audio tags inline.
 * @param {string} [params.modelId] - Defaults to 'eleven_v3'.
 * @param {string} [params.outputFormat]
 * @param {string} [params.languageCode] - ISO-639-1 hint; some models accept this.
 * @param {ElevenLabsVoiceSettings} [params.voiceSettings] - Per-request override of the voice's stored settings.
 * @param {AbortSignal} [params.signal]
 * @returns {Promise<Blob>}
 */
export async function synthesizeSpeech({
    apiKey,
    voiceId,
    text,
    modelId = DEFAULT_TTS_MODEL,
    outputFormat,
    languageCode,
    voiceSettings,
    signal,
}) {
    if (!apiKey) {
        throw new Error('Не указан API-ключ ElevenLabs');
    }
    if (!voiceId) {
        throw new Error('Не указан voice_id для озвучки');
    }
    if (!text || typeof text !== 'string') {
        throw new Error('Для озвучки нужен непустой текст');
    }

    const url = new URL(TTS_ENDPOINT(voiceId));
    if (outputFormat) {
        url.searchParams.set('output_format', outputFormat);
    }

    const body = {
        text,
        model_id: modelId,
    };
    if (languageCode) {
        body.language_code = languageCode;
    }
    const sanitized = sanitizeVoiceSettings(voiceSettings);
    if (sanitized) {
        body.voice_settings = sanitized;
    }

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'xi-api-key': apiKey,
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg, application/octet-stream, */*',
        },
        body: JSON.stringify(body),
        signal,
    });

    if (!res.ok) {
        let detail = '';
        try {
            detail = await res.text();
        } catch (_) {
            // ignore
        }
        throw new Error(`ElevenLabs TTS ${res.status} ${res.statusText}: ${detail || '(no body)'}`);
    }

    return await res.blob();
}

/**
 * Coerce and clamp a voice_settings-shaped object to the ranges accepted by the
 * ElevenLabs API. Returns null when nothing usable was provided so the caller
 * can omit `voice_settings` entirely (and fall back to the voice's stored settings).
 *
 * @param {ElevenLabsVoiceSettings | null | undefined} input
 * @returns {ElevenLabsVoiceSettings | null}
 */
function sanitizeVoiceSettings(input) {
    if (!input || typeof input !== 'object') return null;
    const out = {};
    const clamp01 = (v) => Math.min(1, Math.max(0, Number(v)));
    if (Number.isFinite(Number(input.stability))) out.stability = clamp01(input.stability);
    if (Number.isFinite(Number(input.similarity_boost))) out.similarity_boost = clamp01(input.similarity_boost);
    if (Number.isFinite(Number(input.style))) out.style = clamp01(input.style);
    if (typeof input.use_speaker_boost === 'boolean') out.use_speaker_boost = input.use_speaker_boost;
    if (Number.isFinite(Number(input.speed))) {
        out.speed = Math.min(1.2, Math.max(0.7, Number(input.speed)));
    }
    return Object.keys(out).length ? out : null;
}
