# Immersive Gen Audio - Developer docs

> Audience: contributors / hackers. End-user docs: [English](README.md) · [ภาษาไทย](README_TH.md).

Generates **TTS dialogue, diegetic SFX, and looping ambience** for the latest character message in your SillyTavern chat,
using your currently selected LLM to extract sound design + dialogue cues and ElevenLabs to render audio:

- [Sound Effects API](https://elevenlabs.io/docs/api-reference/text-to-sound-effects/convert) for SFX and ambience
- [Text-to-Speech API](https://elevenlabs.io/docs/api-reference/text-to-speech/convert) (Eleven V3 by default) for dialogue

> Only ElevenLabs is supported as a provider for now.

## Features

- Auto-generate audio whenever a new character message is rendered (toggleable).
- Per-message audio button (in the message action row) and `/genaudio` slash command.
- **TTS via Eleven V3** with inline audio tags (`[whispers]`, `[giggle]`, `[sighs]`, `[shouts]`, etc.) inserted by the LLM based on emotion in the surrounding narration.
- Per-character voice mapping (`characterName -> voiceId`) plus a default voice fallback. Group chats use `chat[messageId].name` for lookup.
- Original-language dialogue preservation (Thai stays Thai, JP stays JP - prompt explicitly forbids translation).
- Up to 3 short SFX prompts per scene, played as **sequential one-shots** after the dialogue.
- Single ambience prompt per scene; loops continuously and **only re-renders when the location actually changes** (the LLM is asked to flag scene changes).
- Crossfaded ambience swaps so transitions don't feel jarring.
- Local audio cache (IndexedDB via `localforage`) keyed by `kind + prompt + format (+ voice/model for TTS)` so swipes and re-runs don't double-bill your ElevenLabs account.
- Independent SFX / ambience / TTS volume sliders.

## Installation

This extension is intended to be installed through SillyTavern's built-in extension installer
("Extensions" → "Install extension" → paste the repo URL).

For local development, place this folder under either:

- `public/scripts/extensions/third-party/st-immersive-gen-audio/` (recommended - "install for all users"), or
- `public/scripts/extensions/st-immersive-gen-audio/` (works too, this is the system-extensions folder).

After dropping the folder in, restart SillyTavern and enable **Immersive Gen Audio** in **Extensions**.

## Setup

1. Open **Extensions** → expand **Immersive Gen Audio**.
2. Paste your **ElevenLabs API key**.
3. Pick an output format. `mp3_44100_128` is a sensible default;
   `mp3_44100_192` requires Creator tier or above on ElevenLabs.
4. (Optional) Toggle **Auto-generate on every new character message**.
5. Make sure SillyTavern is connected to an LLM that supports tool/JSON output well -
   extraction uses `generateQuietPrompt` with a JSON schema. OpenAI / Anthropic / OpenRouter
   chat-completion models work well; pure text-completion models will still work but with
   slightly less reliable JSON.

## Usage

- **Auto mode**: enable the toggle in the settings drawer. Every new character message will
  trigger extraction + audio generation after a short debounce.
- **Manual per-message**: click the speaker icon in the message's action row.
- **From the chatbar**: type `/genaudio` (or `/genaudio target=last`) to regenerate audio
  for the most recent character message.
- **Stop ambience**: click **Stop ambience** in the settings drawer.

## How extraction works

For each requested message, the extension calls `generateQuietPrompt` with a strict JSON schema:

```jsonc
{
  "sfx": ["wooden door slamming shut, close mic"],
  "ambience": "quiet rainy forest at dusk, distant thunder",
  "ambience_changed": true,
  "tts": {
    "text": "[whispers] I'm right here. [pause] Don't be afraid.",
    "skip": false
  }
}
```

- `sfx` is rendered with `loop: false`, default duration auto-detected by ElevenLabs.
- `ambience` is rendered with `loop: true` and the duration set in the settings panel
  (default 22 s, which loops smoothly for ambient beds).
- `ambience_changed: false` means we keep the current ambience playing instead of regenerating it.
- `tts.skip: true` means the message had no spoken dialogue (pure narration / actions only).
- `tts.segments[]` is the ordered list of dialogue lines, one per attributed quoted line:
  ```ts
  type TtsSegment = { speaker: string; text: string };
  ```
  Each segment's `text` is the quoted line with V3 audio tags injected; `speaker` is the
  name of the speaker as it appears in the surrounding narration (or `"unknown"` for
  ambiguous attributions). RPG narrator messages with multiple speakers produce one
  segment per speaker change. Single-character messages collapse to a 1-segment array,
  so the pipeline shape doesn't fork on chat type. Capped at `maxItems: 8`.

`parseExtractionResult` accepts both the new `{skip, segments[]}` shape and the legacy
`{text, skip}` shape — the latter gets wrapped into a single segment using the supplied
`characterName` so any cached extractions keep working.

The system prompt restricts audio tags to a fixed allow-list:
`[whispers] [shouts] [laughs] [giggle] [sighs] [crying] [sad] [excited] [angry] [nervous] [soft] [breathy] [pause]`.

Previous ambience text is stored in the chat metadata under `immersive_gen_audio.ambience`,
so the LLM can reason about scene changes across the conversation. The character card name
(`chat[messageId].name`) is passed only as a *hint* to the LLM — when the narration clearly
attributes a line to someone else, the LLM is instructed to use that name instead.

## Playback orchestration

Inside `runPipeline` ([index.js](index.js)), every dialogue segment, every SFX prompt, and
the ambience clip kick off in parallel. The foreground playback chain then awaits them
sequentially:

1. **TTS queue** — `for (const item of ttsQueue) { if (_ttsCancelled) break; await audio.playTts(item.blob); }`. Each segment plays end-to-end before the next, so multi-speaker exchanges don't overlap.
2. **SFX queue** — `playSfxSequence(blobs)` awaits each one-shot in order.
3. **Ambience promise** — already looping in the background (it crossfaded in the moment the blob arrived). The final await just ensures chat-metadata writes complete before the pipeline returns.

### TTS concurrency limiter

Generation of TTS segments goes through `runWithConcurrencyLimit(items, limit, fn)` —
a tiny worker-pool helper (no library) that keeps at most `limit` calls in flight, in
input order. The cap is `settings.maxConcurrentTts` (default `4`, clamped 1-20).

Why a worker pool rather than fixed batches (e.g. `[3,3,4]`)? Fixed batches block on
the *slowest* call in each batch, leaving slots idle. The worker pool dispatches the
next pending item the moment any worker frees up, so total wall-clock latency for N
items with cap C is roughly `ceil(N/C) * avg_call_time`, not `ceil(N/C) * max_call_time`.

Cache hits also flow through the limiter, but they resolve in microseconds and free
their slot immediately, so cached items don't meaningfully block uncached neighbours.

Errors in the per-item async fn are caught **inside** `fn` (returns `null` and shows a
toastr.warning); the limiter itself doesn't trap errors and lets the whole call reject
if the fn throws — that way the pipeline still surfaces unexpected failures.

The same prompt-side optimisation that helps here lives in `extractor.js`'s system
instructions: consecutive same-speaker lines MUST be merged into one segment, which
collapses the request count for chatty narrator bots before the limiter even sees it.

`_lastTtsQueue: Array<{speaker, text, voiceId, source, blob}>` stores the last successful
queue for the **Replay last audio** button, which iterates it the same way.

`_ttsCancelled: boolean` is the cooperative cancel flag. **Stop TTS** sets it true AND calls
`audio.stopTts()` to cut off the in-flight blob, so the playback loop bails on the next
iteration. The flag is reset before each pipeline run / replay.

The TTS channel is interrupt-on-new: each `playTts` cancels and disposes the previous one,
which is why sequential `await playTts(...)` calls work cleanly. The ambience channel is
crossfade-on-swap. The SFX channel is a disposable pool of one-shots.

## Voice resolution (3-tier)

```js
function resolveVoiceForSpeaker(name) {
    const s = getSettings();
    const trimmed = (name || '').trim();

    // 1. Explicit mapping wins
    if (trimmed && s.characterVoiceMap[trimmed]) {
        return { voiceId: s.characterVoiceMap[trimmed], source: 'mapped', speaker: trimmed };
    }

    // 2. Hash-stable pool (skips "unknown" and empty pools)
    const pool = (Array.isArray(s.voicePool) ? s.voicePool : [])
        .filter(p => p && typeof p.id === 'string' && p.id.trim());
    if (pool.length && trimmed && trimmed !== 'unknown') {
        const idx = stableHash(trimmed) % pool.length;
        return { voiceId: pool[idx].id.trim(), source: 'pool', speaker: trimmed, poolIndex: idx };
    }

    // 3. Default fallback
    return { voiceId: (s.defaultVoiceId || '').trim(), source: 'default', speaker: trimmed };
}
```

Returns `{voiceId, source: 'mapped'|'pool'|'default', speaker}`. The pipeline uses `source`
to decide whether to track the speaker as "unmapped" (pool/default) for the recent-speakers
chip row.

`stableHash` is a hand-rolled 32-bit FNV-1a:

```js
function stableHash(str) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < str.length; i++) {
        h ^= str.charCodeAt(i);
        h = (h * 16777619) >>> 0;
    }
    return h;
}
```

Stability properties:

- Same name → same pool index, every time, across processes.
- Adding/removing pool entries shifts the modulus, so existing speakers may move slots.
  Documented; users are told to "pin" recurring NPCs by promoting them to explicit map entries.

`resolveVoiceId(name)` is preserved as a thin compat shim returning just the `voiceId` string.

If TTS is enabled but every segment fails to resolve a voice (i.e. the user has no default
voice AND no pool entries), a one-shot warning toast fires per chat.

## Recent-unmapped-speakers state machine

State (module-level in [index.js](index.js)):

```js
const _recentUnmappedSpeakers = new Map();   // speaker -> { count, firstSeen, source, voiceId }
const _toastedUnmappedSpeakers = new Set();  // toast-once-per-chat memory
```

Lifecycle:

1. After `resolveVoiceForSpeaker`, every segment whose `source !== 'mapped'` (and whose
   speaker is not `"unknown"`) is recorded with the resolved voiceId.
2. New entries that haven't been toasted yet get added to `newlyUnmapped`.
3. After playback, a single info toast lists newly-seen speakers grouped by source:
   `"New speakers detected (auto-voiced from pool: X, Y; using default voice: Z). ..."`.
4. `renderRecentSpeakers()` projects the map into a chip row in the settings panel,
   filtering out anything that's since been promoted to `characterVoiceMap`.
5. Clicking a chip calls `addOrFocusRowForName(name, voiceId)` (the prefill voice ID is
   the speaker's currently-resolved pool/default voice, so promotion preserves the sound).
6. `CHAT_CHANGED` clears both the map and the toasted set, plus `_lastTtsQueue` and
   `_ttsCancelled`.

### Speaker autocomplete (settings UX)

Free-text input was a footgun (typos break the lookup), so the panel now pulls names
straight from `SillyTavern.getContext()`:

| Source | Used for |
|---|---|
| `ctx.name1` | "User persona" quick-add button + autocomplete |
| `ctx.name2` (and `ctx.characters[ctx.characterId].name` as fallback) | "Current character" quick-add button + autocomplete |
| `ctx.groups[ctx.groupId].members` resolved against `ctx.characters[*].avatar` | Autocomplete entries for the active group |
| `ctx.characters[*].name` | Autocomplete entries for everything else |

`getKnownSpeakers()` collects those, `getAutocompleteCandidates()` dedupes/sorts them,
and `refreshSpeakerSuggestions()` rebuilds the `<datalist id="ig_audio_speaker_suggestions">`
plus the labels of the two quick-add buttons. It runs on:

- Settings panel hydration (`hydrateSettingsUI`).
- `event_types.CHAT_CHANGED`, so switching chats updates the buttons in-place.

`addOrFocusRowForName(name)` is the entry point used by the quick-add buttons. It:

1. Finds an existing row with that exact name → focuses its voice-ID field (no duplicate).
2. Otherwise reuses the empty placeholder row that `renderVoiceMap` injects for empty maps.
3. Otherwise appends a fresh row.

In all branches it commits to settings via `commitVoiceMapFromUI()` and focuses the
voice-ID input so the user can paste immediately.

The lookup itself is still strict-equality on the trimmed `message.name`. The UX
guarantees the keys match because the user typically clicks rather than types.

## Voice settings (per-request `voice_settings`)

Stored on `settings.ttsVoiceSettings` with the same field names the ElevenLabs API
expects, so the object is passed straight through:

```js
ttsVoiceSettings: {
    stability: 0.5,           // 0-1
    similarity_boost: 0.75,   // 0-1
    style: 0,                 // 0-1, ignored by eleven_v3
    use_speaker_boost: true,  // ignored by eleven_v3
    speed: 1.0,               // 0.7-1.2
}
```

`synthesizeSpeech({ ..., voiceSettings })` runs the input through `sanitizeVoiceSettings`
which clamps each numeric field to its valid range and drops anything not finite. If
the resulting object is non-empty, it's attached to the request body as
`voice_settings`; otherwise the body is sent without it and ElevenLabs falls back to
the voice's stored defaults.

`generateTtsBlob` includes `voiceSettings` in its `cacheKey()` payload, so adjusting
any slider produces fresh audio on the next run for the same line. `getSettings()`
backfills missing nested keys (e.g. `speed` for users upgrading from before this was
added) so existing settings JSON keeps working.

Eleven V3 currently ignores `style` and `use_speaker_boost`; the settings panel hints
at this and the API accepts the fields gracefully either way.

## Security note

SillyTavern's docs explicitly warn against storing API keys in `extension_settings`,
because they are kept in **plain text** and are visible to every other extension running in your browser.
There is currently **no secure way** to store secrets purely client-side in SillyTavern -
this extension does not use a server plugin.

Mitigations:

- Use an ElevenLabs key with the **minimum permissions** required (sound generation only) and a
  conservative usage cap.
- Don't share screenshots of your `settings.json` / extension settings.
- Revoke the key promptly if you suspect leakage.

If you need stronger guarantees, consider building a small server plugin that proxies
ElevenLabs requests and keeps the key server-side. PRs welcome.

## Prerequisites

- A SillyTavern build with `SillyTavern.getContext()` exposing `generateQuietPrompt`,
  `renderExtensionTemplateAsync`, `loader`, `SlashCommandParser`, and JSON schema support
  in `generateQuietPrompt({ jsonSchema })`. Recent release builds have all of this.
- An ElevenLabs account and API key.

## Roadmap (post-MVP)

- Per-message persistent audio (re-play SFX/TTS without regenerating after a chat reload).
- Voice picker fetched live from `/v1/voices` instead of paste-by-ID.
- Per-character voice settings overrides (each voice-map entry could carry its own
  stability/style/speed, currently global only).
- Narrator voice — opt-in voicing of the prose between dialogue (Flow C from the design doc).
- Group-chat metadata-driven attribution (skip the LLM speaker-detection step when SillyTavern
  already knows who's speaking).
- Provider abstraction (e.g. local Stable Audio / Riffusion endpoints, alternative TTS).
- Tag-based extraction fallback (`[SFX: ...]` / `[AMBIENCE: ...]`) for users who don't want
  to spend tokens on extraction.
- Server plugin for secure API-key storage.
- Optional ambience ducking under TTS.

## Support

File issues at <https://github.com/SICout9010/st-immersive-gen-audio>.

## License

AGPL-3.0 (recommended; see SillyTavern extension submission guidelines).
