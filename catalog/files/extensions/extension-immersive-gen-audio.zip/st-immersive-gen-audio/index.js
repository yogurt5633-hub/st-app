import { generateSound, synthesizeSpeech } from './src/elevenlabs.js';
import { extractSceneAudio } from './src/extractor.js';
import { AudioManager } from './src/audio.js';
import { cacheKey, getCached, setCached } from './src/cache.js';

const LOG_PREFIX = '[ImmersiveGenAudio]';
const MODULE_NAME = 'immersive_gen_audio';
const EXTENSION_FOLDER = 'st-immersive-gen-audio';
const AMBIENCE_META_KEY = 'immersive_gen_audio.ambience';

const defaultSettings = Object.freeze({
    apiKey: '',
    autoGenerate: false,
    enableSfx: true,
    enableAmbience: true,
    outputFormat: 'mp3_44100_128',
    promptInfluence: 0.4,
    sfxDuration: null,
    ambienceDuration: 22,
    sfxVolume: 0.8,
    ambienceVolume: 0.4,
    enableTts: false,
    ttsModelId: 'eleven_v3',
    ttsVolume: 1.0,
    /**
     * Maximum number of concurrent TTS API calls in flight at once.
     * ElevenLabs concurrency caps (May 2026): Free=4, Creator=6, Pro=8, Scale/Business=10+.
     * Set this to your tier's cap; going higher will surface as 429s from the API.
     */
    maxConcurrentTts: 4,
    defaultVoiceId: '',
    /** @type {Record<string, string>} characterName -> voiceId */
    characterVoiceMap: {},
    /**
     * Hash-stable fallback voices for unmapped speakers. The same speaker name
     * always lands on the same pool entry (FNV-1a hash mod pool length), so a
     * recurring NPC sounds consistent across the chat. `label` is purely cosmetic.
     * @type {Array<{ label: string, id: string }>}
     */
    voicePool: [],
    /**
     * Voice settings sent as ElevenLabs `voice_settings`. Keys match the API exactly
     * so we can pass the object straight through.
     */
    ttsVoiceSettings: {
        stability: 0.5,
        similarity_boost: 0.75,
        style: 0,
        use_speaker_boost: true,
        speed: 1.0,
    },
});

const audio = new AudioManager({
    sfxVolume: defaultSettings.sfxVolume,
    ambienceVolume: defaultSettings.ambienceVolume,
    ttsVolume: defaultSettings.ttsVolume,
});

let _autoTimer = null;
let _isRunning = false;
let _isReplayingSfx = false;
/** @type {Array<{ text: string, blob: Blob }>} */
let _lastSfxQueue = [];
/**
 * Multi-segment TTS playback queue from the most recent run, used by the
 * "Replay last audio" button. Each entry corresponds to one extracted dialogue
 * segment that was successfully synthesized.
 * @type {Array<{ speaker: string, text: string, voiceId: string, source: 'mapped'|'pool'|'default', blob: Blob }>}
 */
let _lastTtsQueue = [];
let _voiceMissingWarned = false;
/** Set true by Stop TTS so the sequential playback loop bails early. Reset before each run. */
let _ttsCancelled = false;
/**
 * Speakers seen in the current chat that fell back to either the voice pool
 * or the default voice (i.e. NOT explicitly mapped). Surfaced in the settings
 * panel as clickable chips so the user can promote them.
 * @type {Map<string, { count: number, firstSeen: number, source: 'pool'|'default', voiceId: string }>}
 */
const _recentUnmappedSpeakers = new Map();
/** Speakers we've already mentioned in a toast this chat so we don't spam. */
const _toastedUnmappedSpeakers = new Set();

function getCtx() {
    return SillyTavern.getContext();
}

function getSettings() {
    const ctx = getCtx();
    const all = ctx.extensionSettings;
    if (!all[MODULE_NAME]) {
        all[MODULE_NAME] = structuredClone(defaultSettings);
    }
    for (const key of Object.keys(defaultSettings)) {
        if (!Object.hasOwn(all[MODULE_NAME], key)) {
            all[MODULE_NAME][key] = structuredClone(defaultSettings[key]);
        }
    }
    if (!all[MODULE_NAME].characterVoiceMap || typeof all[MODULE_NAME].characterVoiceMap !== 'object') {
        all[MODULE_NAME].characterVoiceMap = {};
    }
    if (!Array.isArray(all[MODULE_NAME].voicePool)) {
        all[MODULE_NAME].voicePool = [];
    }
    // Clamp the concurrency limit so a stale/corrupted value can't stall the pipeline.
    const mc = Number(all[MODULE_NAME].maxConcurrentTts);
    if (!Number.isFinite(mc) || mc < 1) {
        all[MODULE_NAME].maxConcurrentTts = defaultSettings.maxConcurrentTts;
    } else {
        all[MODULE_NAME].maxConcurrentTts = Math.min(20, Math.max(1, Math.round(mc)));
    }
    // Backfill any missing keys in the nested ttsVoiceSettings (e.g. when upgrading
    // from an older version that didn't have `speed` yet).
    const vs = all[MODULE_NAME].ttsVoiceSettings;
    if (!vs || typeof vs !== 'object') {
        all[MODULE_NAME].ttsVoiceSettings = structuredClone(defaultSettings.ttsVoiceSettings);
    } else {
        for (const k of Object.keys(defaultSettings.ttsVoiceSettings)) {
            if (!Object.hasOwn(vs, k)) {
                vs[k] = defaultSettings.ttsVoiceSettings[k];
            }
        }
    }
    return all[MODULE_NAME];
}

function saveSettings() {
    getCtx().saveSettingsDebounced();
}

function applyAudioVolumes() {
    const s = getSettings();
    audio.setSfxVolume(s.sfxVolume);
    audio.setAmbienceVolume(s.ambienceVolume);
    audio.setTtsVolume(s.ttsVolume);
}

function updateAmbiencePill() {
    const prompt = audio.getCurrentAmbiencePrompt();
    const $pill = $('#ig_audio_current_ambience');
    if (!$pill.length) return;
    if (prompt) {
        $pill.text(prompt).attr('title', prompt);
    } else {
        $pill.text('нет').attr('title', '');
    }
}

async function renderSettingsPanel() {
    const ctx = getCtx();
    const html = await ctx.renderExtensionTemplateAsync('third-party/' + EXTENSION_FOLDER, 'settings');
    $('#extensions_settings').append(html);
    bindSettingsHandlers();
    hydrateSettingsUI();
}

function hydrateSettingsUI() {
    const s = getSettings();
    $('#ig_audio_api_key').val(s.apiKey || '');
    $('#ig_audio_auto').prop('checked', !!s.autoGenerate);
    $('#ig_audio_generate_sfx').prop('checked', !!s.enableSfx);
    $('#ig_audio_generate_ambience').prop('checked', !!s.enableAmbience);
    $('#ig_audio_format').val(s.outputFormat);
    $('#ig_audio_prompt_influence').val(s.promptInfluence);
    $('#ig_audio_prompt_influence_value').text(Number(s.promptInfluence).toFixed(2));
    $('#ig_audio_ambience_duration').val(s.ambienceDuration);
    $('#ig_audio_sfx_volume').val(s.sfxVolume);
    $('#ig_audio_sfx_volume_value').text(`${Math.round(s.sfxVolume * 100)}%`);
    $('#ig_audio_ambience_volume').val(s.ambienceVolume);
    $('#ig_audio_ambience_volume_value').text(`${Math.round(s.ambienceVolume * 100)}%`);

    $('#ig_audio_tts_enabled').prop('checked', !!s.enableTts);
    $('#ig_audio_tts_model').val(s.ttsModelId || 'eleven_v3');
    $('#ig_audio_default_voice').val(s.defaultVoiceId || '');
    $('#ig_audio_tts_volume').val(s.ttsVolume);
    $('#ig_audio_tts_volume_value').text(`${Math.round(s.ttsVolume * 100)}%`);
    $('#ig_audio_max_concurrent_tts').val(s.maxConcurrentTts);
    hydrateVoiceSettingsUI();
    renderVoicePool();
    renderVoiceMap();
    refreshSpeakerSuggestions();
    renderRecentSpeakers();

    updateAmbiencePill();
    refreshReplayButton();
}

function bindSettingsHandlers() {
    $(document).on('input', '#ig_audio_api_key', (e) => {
        getSettings().apiKey = String($(e.target).val() || '').trim();
        saveSettings();
    });

    $(document).on('change', '#ig_audio_auto', (e) => {
        getSettings().autoGenerate = !!$(e.target).prop('checked');
        saveSettings();
    });

    $(document).on('change', '#ig_audio_generate_sfx', (e) => {
        getSettings().enableSfx = !!$(e.target).prop('checked');
        saveSettings();
    });

    $(document).on('change', '#ig_audio_generate_ambience', (e) => {
        getSettings().enableAmbience = !!$(e.target).prop('checked');
        saveSettings();
    });

    $(document).on('change', '#ig_audio_format', (e) => {
        getSettings().outputFormat = String($(e.target).val() || 'mp3_44100_128');
        saveSettings();
    });

    $(document).on('input', '#ig_audio_prompt_influence', (e) => {
        const value = Number($(e.target).val());
        getSettings().promptInfluence = value;
        $('#ig_audio_prompt_influence_value').text(value.toFixed(2));
        saveSettings();
    });

    $(document).on('change', '#ig_audio_ambience_duration', (e) => {
        const value = Math.max(5, Math.min(30, Math.round(Number($(e.target).val()) || 22)));
        getSettings().ambienceDuration = value;
        $(e.target).val(value);
        saveSettings();
    });

    $(document).on('input', '#ig_audio_sfx_volume', (e) => {
        const value = Number($(e.target).val());
        getSettings().sfxVolume = value;
        $('#ig_audio_sfx_volume_value').text(`${Math.round(value * 100)}%`);
        audio.setSfxVolume(value);
        saveSettings();
    });

    $(document).on('input', '#ig_audio_ambience_volume', (e) => {
        const value = Number($(e.target).val());
        getSettings().ambienceVolume = value;
        $('#ig_audio_ambience_volume_value').text(`${Math.round(value * 100)}%`);
        audio.setAmbienceVolume(value);
        saveSettings();
    });

    $(document).on('click', '#ig_audio_generate_now', () => {
        const id = lastCharacterMessageId();
        if (id == null) {
            toastr.warning('В чате пока нет сообщений персонажей.', 'Immersive Gen Audio');
            return;
        }
        runPipeline(id, { source: 'manual' }).catch(err => {
            console.error(LOG_PREFIX, 'Manual generation failed:', err);
            toastr.error(String(err?.message || err), 'Immersive Gen Audio');
        });
    });

    $(document).on('click', '#ig_audio_replay_sfx', async () => {
        if (!_lastTtsQueue.length && !_lastSfxQueue.length) {
            toastr.info('Пока нечего воспроизводить. Сначала создайте звук для сообщения.', 'Immersive Gen Audio');
            return;
        }
        if (_isReplayingSfx) return;
        _isReplayingSfx = true;
        _ttsCancelled = false;
        refreshReplayButton();
        try {
            for (const item of _lastTtsQueue) {
                if (_ttsCancelled) break;
                await audio.playTts(item.blob);
            }
            if (_lastSfxQueue.length) {
                await playSfxSequence(_lastSfxQueue.map(item => item.blob));
            }
        } catch (err) {
            console.error(LOG_PREFIX, 'Replay failed:', err);
        } finally {
            _isReplayingSfx = false;
            refreshReplayButton();
        }
    });

    $(document).on('click', '#ig_audio_stop_ambience', async () => {
        await audio.stopAmbience();
        const ctx = getCtx();
        if (ctx.chatMetadata) {
            delete ctx.chatMetadata[AMBIENCE_META_KEY];
            try { await ctx.saveMetadata?.(); } catch (_) { /* noop */ }
        }
        updateAmbiencePill();
        $(`.mes .mes_button.ig_audio_btn`).removeClass('ig_audio_btn_active');
    });

    $(document).on('click', '#ig_audio_stop_tts', () => {
        _ttsCancelled = true;
        audio.stopTts();
    });

    $(document).on('change', '#ig_audio_tts_enabled', (e) => {
        getSettings().enableTts = !!$(e.target).prop('checked');
        _voiceMissingWarned = false;
        saveSettings();
    });

    $(document).on('change', '#ig_audio_tts_model', (e) => {
        getSettings().ttsModelId = String($(e.target).val() || 'eleven_v3');
        saveSettings();
    });

    $(document).on('input', '#ig_audio_default_voice', (e) => {
        getSettings().defaultVoiceId = String($(e.target).val() || '').trim();
        saveSettings();
    });

    $(document).on('input', '#ig_audio_tts_volume', (e) => {
        const value = Number($(e.target).val());
        getSettings().ttsVolume = value;
        $('#ig_audio_tts_volume_value').text(`${Math.round(value * 100)}%`);
        audio.setTtsVolume(value);
        saveSettings();
    });

    $(document).on('change', '#ig_audio_max_concurrent_tts', (e) => {
        const raw = Number($(e.target).val());
        const clamped = Number.isFinite(raw)
            ? Math.min(20, Math.max(1, Math.round(raw)))
            : defaultSettings.maxConcurrentTts;
        getSettings().maxConcurrentTts = clamped;
        $(e.target).val(clamped);
        saveSettings();
    });

    for (const field of VOICE_SETTING_FIELDS) {
        $(document).on('input', field.input, (e) => {
            const value = Number($(e.target).val());
            getSettings().ttsVoiceSettings[field.id] = value;
            $(field.readout).text(field.format(value));
            saveSettings();
        });
    }

    $(document).on('change', '#ig_audio_vs_speaker_boost', (e) => {
        getSettings().ttsVoiceSettings.use_speaker_boost = !!$(e.target).prop('checked');
        saveSettings();
    });

    $(document).on('click', '#ig_audio_vs_reset', () => {
        getSettings().ttsVoiceSettings = structuredClone(defaultSettings.ttsVoiceSettings);
        saveSettings();
        hydrateVoiceSettingsUI();
        toastr.info('Настройки голоса сброшены.', 'Immersive Gen Audio');
    });

    $(document).on('click', '#ig_audio_voice_map_add', () => {
        appendVoiceRow('', '', { focus: true });
    });

    $(document).on('click', '#ig_audio_voice_map_add_current', () => {
        const { currentCharacter } = getKnownSpeakers();
        if (!currentCharacter) {
            toastr.info('В чате нет активного персонажа. Откройте чат персонажа или группы.', 'Immersive Gen Audio');
            return;
        }
        addOrFocusRowForName(currentCharacter);
    });

    $(document).on('click', '#ig_audio_voice_map_add_user', () => {
        const { userPersona } = getKnownSpeakers();
        if (!userPersona) {
            toastr.info('Имя персоны пользователя не найдено. Укажите его в настройках пользователя.', 'Immersive Gen Audio');
            return;
        }
        addOrFocusRowForName(userPersona);
    });

    $(document).on('input change', '.ig_audio_voice_row .ig_audio_voice_name, .ig_audio_voice_row .ig_audio_voice_id', () => {
        commitVoiceMapFromUI();
    });

    $(document).on('click', '.ig_audio_voice_remove', (e) => {
        const $row = $(e.currentTarget).closest('.ig_audio_voice_row');
        $row.remove();
        commitVoiceMapFromUI();
    });

    // --- Voice pool handlers ---
    $(document).on('click', '#ig_audio_voice_pool_add', () => {
        appendPoolRow('', '', { focus: true });
    });

    $(document).on('input change', '.ig_audio_pool_row .ig_audio_pool_label, .ig_audio_pool_row .ig_audio_pool_id', () => {
        commitPoolFromUI();
    });

    $(document).on('click', '.ig_audio_pool_remove', (e) => {
        const $row = $(e.currentTarget).closest('.ig_audio_pool_row');
        $row.remove();
        commitPoolFromUI();
    });

    // --- Recent unmapped-speaker chip click ---
    $(document).on('click', '.ig_audio_recent_speaker_chip', (e) => {
        const $chip = $(e.currentTarget);
        const name = String($chip.data('name') || '').trim();
        const voiceId = String($chip.data('voiceid') || '').trim();
        if (!name) return;
        addOrFocusRowForName(name, voiceId);
        _recentUnmappedSpeakers.delete(name);
        renderRecentSpeakers();
    });
}

function lastCharacterMessageId() {
    const ctx = getCtx();
    const chat = ctx.chat || [];
    for (let i = chat.length - 1; i >= 0; i--) {
        const m = chat[i];
        if (m && !m.is_user && !m.is_system) {
            return i;
        }
    }
    return null;
}

function injectButtonForMessage(messageId) {
    if (messageId == null) return;
    const $mes = $(`.mes[mesid="${messageId}"]`);
    if (!$mes.length) return;
    const $extra = $mes.find('.extraMesButtons').first();
    if (!$extra.length) return;
    if ($extra.find('.ig_audio_btn').length) return;

    const $btn = $('<div></div>')
        .attr('title', 'Создать звуковые эффекты и атмосферу')
        .addClass('mes_button ig_audio_btn fa-solid fa-volume-high interactable')
        .attr('data-mes-id', String(messageId));

    $extra.prepend($btn);
}

function injectButtonsForAllMessages() {
    $('.mes').each((_, el) => {
        const id = el.getAttribute('mesid');
        if (id != null) injectButtonForMessage(Number(id));
    });
}

function bindMessageButtonHandler() {
    $(document).on('click', '.mes_button.ig_audio_btn', async function (event) {
        event.preventDefault();
        event.stopPropagation();
        const $btn = $(this);
        if ($btn.hasClass('ig_audio_btn_busy')) return;
        const id = Number($btn.attr('data-mes-id') ?? $btn.closest('.mes').attr('mesid'));
        if (!Number.isFinite(id)) return;
        $btn.addClass('ig_audio_btn_busy');
        try {
            await runPipeline(id, { source: 'message-button' });
        } catch (err) {
            console.error(LOG_PREFIX, 'Per-message generation failed:', err);
            toastr.error(String(err?.message || err), 'Immersive Gen Audio');
        } finally {
            $btn.removeClass('ig_audio_btn_busy');
        }
    });
}

function scheduleAutoRun(messageId) {
    const s = getSettings();
    if (!s.autoGenerate) return;
    if (!s.apiKey) return;
    if (_autoTimer) clearTimeout(_autoTimer);
    _autoTimer = setTimeout(() => {
        const id = messageId ?? lastCharacterMessageId();
        if (id == null) return;
        runPipeline(id, { source: 'auto' }).catch(err => {
            console.error(LOG_PREFIX, 'Auto generation failed:', err);
        });
    }, 750);
}

async function runPipeline(messageId, { source = 'manual' } = {}) {
    if (_isRunning) {
        toastr.info('Звук уже создаётся. Подождите…', 'Immersive Gen Audio');
        return;
    }
    const ctx = getCtx();
    const settings = getSettings();
    if (!settings.apiKey) {
        toastr.error('Укажите API-ключ ElevenLabs в Расширения → Immersive Gen Audio.', 'Immersive Gen Audio');
        return;
    }

    const message = ctx.chat?.[messageId];
    if (!message || message.is_user || message.is_system) {
        toastr.warning('Выбранное сообщение не принадлежит персонажу.', 'Immersive Gen Audio');
        return;
    }
    const text = (message.mes || '').toString().trim();
    if (!text) {
        toastr.warning('Выбранное сообщение пусто.', 'Immersive Gen Audio');
        return;
    }

    if (!settings.enableTts && !settings.enableSfx && !settings.enableAmbience) {
        toastr.info('Все типы звука отключены. Включите хотя бы озвучку, эффекты или атмосферу в настройках.', 'Immersive Gen Audio');
        return;
    }

    _isRunning = true;
    const $btn = $(`.mes[mesid="${messageId}"] .mes_button.ig_audio_btn`).addClass('ig_audio_btn_busy');
    const handle = ctx.loader?.show?.({
        blocking: false,
        message: `Создаём звук (${source})…`,
        title: 'Immersive Gen Audio',
        toastMode: 'static',
    });

    try {
        const previousAmbience = ctx.chatMetadata?.[AMBIENCE_META_KEY] ?? null;
        const characterName = (message.name || '').toString().trim();

        const extraction = await extractSceneAudio({
            messageText: text,
            previousAmbience,
            characterName,
        });

        console.debug(LOG_PREFIX, 'Extraction:', extraction);

        // --- Build the per-segment TTS plan (one entry per dialogue line) ---
        const segments = (settings.enableTts && extraction.tts && !extraction.tts.skip && Array.isArray(extraction.tts.segments))
            ? extraction.tts.segments
            : [];
        /** @type {Array<{ speaker: string, text: string, voiceId: string, source: 'mapped'|'pool'|'default' }>} */
        const ttsPlans = [];
        for (const seg of segments) {
            if (!seg || !seg.text) continue;
            const resolved = resolveVoiceForSpeaker(seg.speaker);
            if (!resolved.voiceId) continue; // no default voice configured at all
            ttsPlans.push({
                speaker: resolved.speaker || seg.speaker,
                text: seg.text,
                voiceId: resolved.voiceId,
                source: resolved.source,
            });
        }

        // Track unmapped speakers (BOTH pool and default) so the user can promote
        // them to explicit voice-map entries via the recent-speakers chip row.
        /** @type {Array<{ name: string, source: 'pool'|'default' }>} */
        const newlyUnmapped = [];
        for (const p of ttsPlans) {
            if (p.source === 'mapped') continue;
            if (!p.speaker || p.speaker === 'unknown') continue;
            const existing = _recentUnmappedSpeakers.get(p.speaker);
            if (existing) {
                existing.count += 1;
            } else {
                _recentUnmappedSpeakers.set(p.speaker, {
                    count: 1,
                    firstSeen: Date.now(),
                    source: p.source,
                    voiceId: p.voiceId,
                });
                if (!_toastedUnmappedSpeakers.has(p.speaker)) {
                    newlyUnmapped.push({ name: p.speaker, source: p.source });
                }
            }
        }

        // One-shot legacy warning when TTS is enabled but no voice can be resolved
        // for ANY segment (e.g. defaultVoiceId empty AND voicePool empty).
        if (settings.enableTts && segments.length && !ttsPlans.length && !_voiceMissingWarned) {
            _voiceMissingWarned = true;
            toastr.warning(
                'Озвучка включена, но голос не найден: голос по умолчанию и набор пусты. Настройте их в Расширения → Immersive Gen Audio.',
                'Immersive Gen Audio',
            );
        }

        // --- Kick off all generations in parallel ---
        // TTS goes through a concurrency limiter so we don't blow past ElevenLabs'
        // per-tier concurrent-request cap (free=4). Cache hits also flow through the
        // limiter but resolve in microseconds, freeing the slot immediately.
        const ttsConcurrency = Math.max(1, Number(settings.maxConcurrentTts) || 4);
        const ttsBlobsPromise = ttsPlans.length
            ? runWithConcurrencyLimit(ttsPlans, ttsConcurrency, async (plan) => {
                try {
                    const blob = await generateTtsBlob({
                        apiKey: settings.apiKey,
                        voiceId: plan.voiceId,
                        text: plan.text,
                        modelId: settings.ttsModelId,
                        outputFormat: settings.outputFormat,
                        voiceSettings: settings.ttsVoiceSettings,
                    });
                    return { ...plan, blob };
                } catch (err) {
                    console.error(LOG_PREFIX, 'TTS segment failed:', plan.speaker, err);
                    toastr.warning(`Не удалось озвучить «${plan.speaker}»: ${err.message || err}`, 'Immersive Gen Audio');
                    return null;
                }
            })
            : Promise.resolve([]);

        const sfxBlobsPromise = (settings.enableSfx && Array.isArray(extraction.sfx) && extraction.sfx.length)
            ? Promise.all(extraction.sfx.map(async (sfxText) => {
                try {
                    const blob = await generateSfxBlob(sfxText, settings);
                    return { text: sfxText, blob };
                } catch (err) {
                    console.error(LOG_PREFIX, 'SFX failed:', sfxText, err);
                    toastr.warning(`Не удалось создать эффект: ${err.message || err}`, 'Immersive Gen Audio');
                    return null;
                }
            }))
            : Promise.resolve([]);

        const ambiencePromise = (settings.enableAmbience && extraction.ambience && extraction.ambience_changed)
            ? handleAmbience(extraction.ambience, settings).then(async () => {
                if (ctx.chatMetadata) {
                    ctx.chatMetadata[AMBIENCE_META_KEY] = extraction.ambience;
                    try { await ctx.saveMetadata?.(); } catch (_) { /* noop */ }
                }
                updateAmbiencePill();
                $(`.mes .mes_button.ig_audio_btn`).removeClass('ig_audio_btn_active');
                $btn.addClass('ig_audio_btn_active');
            }).catch(err => {
                console.error(LOG_PREFIX, 'Ambience failed:', err);
                toastr.warning(`Не удалось создать атмосферу: ${err.message || err}`, 'Immersive Gen Audio');
            })
            : Promise.resolve();

        const ttsScheduled = ttsPlans.length > 0;
        const sfxScheduled = !!(settings.enableSfx && extraction.sfx && extraction.sfx.length);
        const ambienceScheduled = !!(settings.enableAmbience && extraction.ambience && extraction.ambience_changed);
        if (!ttsScheduled && !sfxScheduled && !ambienceScheduled) {
            const llmSuggested = (
                (extraction.tts && !extraction.tts.skip && segments.length) ||
                (extraction.sfx && extraction.sfx.length) ||
                (extraction.ambience && extraction.ambience_changed)
            );
            if (llmSuggested) {
                toastr.info('Нечего воспроизводить: модель предложила только отключённые типы звука.', 'Immersive Gen Audio');
            } else if (settings.enableTts && (!extraction.tts || extraction.tts.skip || !segments.length)) {
                toastr.info('В сообщении нет диалога, эффектов или новой атмосферы.', 'Immersive Gen Audio');
            } else {
                toastr.info('Для сообщения не предложены озвучка, эффекты или атмосфера.', 'Immersive Gen Audio');
            }
        }

        // --- Sequential foreground chain: TTS queue first, then SFX queue. Ambience streams underneath. ---
        const ttsResults = (await ttsBlobsPromise) || [];
        const ttsQueue = ttsResults.filter(item => item && item.blob instanceof Blob);
        if (ttsQueue.length) {
            _lastTtsQueue = ttsQueue;
            _ttsCancelled = false;
            refreshReplayButton();
            for (const item of ttsQueue) {
                if (_ttsCancelled) break;
                await audio.playTts(item.blob);
            }
        }

        const sfxResults = (await sfxBlobsPromise) || [];
        const sfxQueue = sfxResults.filter(item => item && item.blob instanceof Blob);
        if (sfxQueue.length) {
            _lastSfxQueue = sfxQueue;
            refreshReplayButton();
            await playSfxSequence(sfxQueue.map(item => item.blob));
        }

        await ambiencePromise;

        // --- One-time toast for newly seen unmapped speakers ---
        if (newlyUnmapped.length) {
            for (const n of newlyUnmapped) _toastedUnmappedSpeakers.add(n.name);
            const pooled = newlyUnmapped.filter(n => n.source === 'pool').map(n => n.name);
            const defaulted = newlyUnmapped.filter(n => n.source === 'default').map(n => n.name);
            const parts = [];
            if (pooled.length) parts.push(`автоматически из набора: ${pooled.join(', ')}`);
            if (defaulted.length) parts.push(`голос по умолчанию: ${defaulted.join(', ')}`);
            toastr.info(
                `Новые говорящие (${parts.join('; ')}). Назначьте им голоса в настройках.`,
                'Immersive Gen Audio',
            );
        }
        renderRecentSpeakers();
    } finally {
        _isRunning = false;
        $btn.removeClass('ig_audio_btn_busy');
        try { await handle?.hide?.(); } catch (_) { /* noop */ }
    }
}

async function generateSfxBlob(text, settings) {
    return await getOrGenerate({
        kind: 'sfx',
        text,
        outputFormat: settings.outputFormat,
        durationSeconds: settings.sfxDuration ?? null,
        promptInfluence: settings.promptInfluence,
        loop: false,
        apiKey: settings.apiKey,
    });
}

async function playSfxSequence(blobs) {
    for (const blob of blobs) {
        if (!(blob instanceof Blob)) continue;
        await audio.playSfx(blob);
    }
}

function refreshReplayButton() {
    const hasContent = _lastTtsQueue.length > 0 || _lastSfxQueue.length > 0;
    $('#ig_audio_replay_sfx').prop('disabled', !hasContent || _isReplayingSfx);
}

const VOICE_SETTING_FIELDS = /** @type {const} */ ([
    { id: 'stability',         input: '#ig_audio_vs_stability',     readout: '#ig_audio_vs_stability_value',     format: (v) => v.toFixed(2) },
    { id: 'similarity_boost',  input: '#ig_audio_vs_similarity',    readout: '#ig_audio_vs_similarity_value',    format: (v) => v.toFixed(2) },
    { id: 'style',             input: '#ig_audio_vs_style',         readout: '#ig_audio_vs_style_value',         format: (v) => v.toFixed(2) },
    { id: 'speed',             input: '#ig_audio_vs_speed',         readout: '#ig_audio_vs_speed_value',         format: (v) => `${v.toFixed(2)}\u00d7` },
]);

function hydrateVoiceSettingsUI() {
    const vs = getSettings().ttsVoiceSettings;
    for (const field of VOICE_SETTING_FIELDS) {
        const value = Number(vs[field.id]);
        $(field.input).val(value);
        $(field.readout).text(field.format(value));
    }
    $('#ig_audio_vs_speaker_boost').prop('checked', !!vs.use_speaker_boost);
}

function renderVoiceMap() {
    const $list = $('#ig_audio_voice_map');
    if (!$list.length) return;
    $list.empty();
    const map = getSettings().characterVoiceMap || {};
    const entries = Object.entries(map);
    if (!entries.length) {
        appendVoiceRow('', '');
        return;
    }
    for (const [name, voiceId] of entries) {
        appendVoiceRow(name, voiceId);
    }
}

function appendVoiceRow(name, voiceId, { focus = false } = {}) {
    const $list = $('#ig_audio_voice_map');
    if (!$list.length) return;
    const $row = $(`
        <div class="ig_audio_voice_row flex-container alignItemsCenter">
            <input class="text_pole flex1 ig_audio_voice_name" type="text" placeholder="Имя персонажа" list="ig_audio_speaker_suggestions" autocomplete="off" />
            <input class="text_pole flex2 ig_audio_voice_id" type="text" placeholder="voice_id" autocomplete="off" />
            <div class="menu_button fa-solid fa-trash ig_audio_voice_remove" title="Удалить"></div>
        </div>
    `);
    $row.find('.ig_audio_voice_name').val(name || '');
    $row.find('.ig_audio_voice_id').val(voiceId || '');
    $list.append($row);
    if (focus) {
        $row.find('.ig_audio_voice_name').trigger('focus');
    }
}

/**
 * Pull speaker names from SillyTavern's context so the user doesn't have to type them.
 *
 * @returns {{
 *   currentCharacter: string,
 *   userPersona: string,
 *   groupMembers: string[],
 *   allCharacters: string[],
 * }}
 */
function getKnownSpeakers() {
    const ctx = getCtx();
    const out = { currentCharacter: '', userPersona: '', groupMembers: [], allCharacters: [] };

    if (typeof ctx.name1 === 'string' && ctx.name1.trim()) {
        out.userPersona = ctx.name1.trim();
    }
    if (typeof ctx.name2 === 'string' && ctx.name2.trim()) {
        out.currentCharacter = ctx.name2.trim();
    }

    const charByAvatar = new Map();
    if (Array.isArray(ctx.characters)) {
        for (const c of ctx.characters) {
            if (!c || typeof c.name !== 'string' || !c.name.trim()) continue;
            out.allCharacters.push(c.name.trim());
            if (c.avatar) charByAvatar.set(c.avatar, c.name.trim());
        }
    }

    // Resolve current group members (by avatar) into character names
    if (ctx.groupId && Array.isArray(ctx.groups)) {
        const group = ctx.groups.find(g => g && g.id === ctx.groupId);
        if (group && Array.isArray(group.members)) {
            for (const member of group.members) {
                const name = charByAvatar.get(member);
                if (name) out.groupMembers.push(name);
            }
        }
    }

    return out;
}

function getAutocompleteCandidates() {
    const known = getKnownSpeakers();
    const set = new Set();
    if (known.userPersona) set.add(known.userPersona);
    if (known.currentCharacter) set.add(known.currentCharacter);
    for (const m of known.groupMembers) set.add(m);
    for (const c of known.allCharacters) set.add(c);
    return Array.from(set).sort((a, b) => a.localeCompare(b));
}

function refreshSpeakerSuggestions() {
    const $datalist = $('#ig_audio_speaker_suggestions');
    if (!$datalist.length) return;
    const candidates = getAutocompleteCandidates();
    $datalist.empty();
    for (const name of candidates) {
        $datalist.append($('<option>').attr('value', name));
    }

    const known = getKnownSpeakers();
    const $current = $('#ig_audio_voice_map_add_current');
    if (known.currentCharacter) {
        $current.val(`+ ${known.currentCharacter}`).prop('disabled', false);
    } else {
        $current.val('+ Current character').prop('disabled', true);
    }
    const $persona = $('#ig_audio_voice_map_add_user');
    if (known.userPersona) {
        $persona.val(`+ ${known.userPersona} (you)`).prop('disabled', false);
    } else {
        $persona.val('+ User persona').prop('disabled', true);
    }
}

/**
 * Add a row for `name`, but if a row with that name already exists just focus it.
 * Reuses the empty placeholder row if one exists, so the panel never grows
 * unnecessarily on first use.
 */
/**
 * Add or focus a voice-map row for the given speaker. If `prefillVoiceId` is
 * provided AND the row doesn't already have a voice ID, it gets pre-populated
 * (used by recent-speaker chips so clicking "+ Brock (pool)" locks in the same
 * voice the user has been hearing).
 *
 * @param {string} name
 * @param {string} [prefillVoiceId]
 */
function addOrFocusRowForName(name, prefillVoiceId = '') {
    const trimmed = (name || '').trim();
    if (!trimmed) return;
    const prefill = (prefillVoiceId || '').trim();

    let $existing = null;
    let $emptyPlaceholder = null;
    $('#ig_audio_voice_map .ig_audio_voice_row').each((_, el) => {
        const $el = $(el);
        const n = String($el.find('.ig_audio_voice_name').val() || '').trim();
        const v = String($el.find('.ig_audio_voice_id').val() || '').trim();
        if (n === trimmed) {
            $existing = $el;
        } else if (!n && !v && !$emptyPlaceholder) {
            $emptyPlaceholder = $el;
        }
    });

    if ($existing) {
        const $idInput = $existing.find('.ig_audio_voice_id');
        if (prefill && !String($idInput.val() || '').trim()) {
            $idInput.val(prefill);
            commitVoiceMapFromUI();
        }
        $idInput.trigger('focus');
        return;
    }
    if ($emptyPlaceholder) {
        $emptyPlaceholder.find('.ig_audio_voice_name').val(trimmed);
        if (prefill) $emptyPlaceholder.find('.ig_audio_voice_id').val(prefill);
        commitVoiceMapFromUI();
        $emptyPlaceholder.find('.ig_audio_voice_id').trigger('focus');
        return;
    }
    appendVoiceRow(trimmed, prefill);
    commitVoiceMapFromUI();
    $('#ig_audio_voice_map .ig_audio_voice_row').last().find('.ig_audio_voice_id').trigger('focus');
}

function commitVoiceMapFromUI() {
    const map = {};
    $('#ig_audio_voice_map .ig_audio_voice_row').each((_, el) => {
        const $el = $(el);
        const name = String($el.find('.ig_audio_voice_name').val() || '').trim();
        const voiceId = String($el.find('.ig_audio_voice_id').val() || '').trim();
        if (name && voiceId) {
            map[name] = voiceId;
        }
    });
    getSettings().characterVoiceMap = map;
    saveSettings();
    renderRecentSpeakers();
}

// --- Voice pool ---

function renderVoicePool() {
    const $list = $('#ig_audio_voice_pool');
    if (!$list.length) return;
    $list.empty();
    const pool = Array.isArray(getSettings().voicePool) ? getSettings().voicePool : [];
    if (!pool.length) {
        appendPoolRow('', '');
        return;
    }
    for (const entry of pool) {
        appendPoolRow(entry?.label || '', entry?.id || '');
    }
}

function appendPoolRow(label, id, { focus = false } = {}) {
    const $list = $('#ig_audio_voice_pool');
    if (!$list.length) return;
    const $row = $(`
        <div class="ig_audio_pool_row flex-container alignItemsCenter">
            <input class="text_pole flex1 ig_audio_pool_label" type="text" placeholder="Подпись (необязательно)" autocomplete="off" />
            <input class="text_pole flex2 ig_audio_pool_id" type="text" placeholder="voice_id" autocomplete="off" />
            <div class="menu_button fa-solid fa-trash ig_audio_pool_remove" title="Удалить"></div>
        </div>
    `);
    $row.find('.ig_audio_pool_label').val(label || '');
    $row.find('.ig_audio_pool_id').val(id || '');
    $list.append($row);
    if (focus) {
        $row.find('.ig_audio_pool_id').trigger('focus');
    }
}

function commitPoolFromUI() {
    const pool = [];
    $('#ig_audio_voice_pool .ig_audio_pool_row').each((_, el) => {
        const $el = $(el);
        const label = String($el.find('.ig_audio_pool_label').val() || '').trim();
        const id = String($el.find('.ig_audio_pool_id').val() || '').trim();
        if (id) pool.push({ label, id });
    });
    getSettings().voicePool = pool;
    saveSettings();
}

// --- Recent unmapped speakers (Flow E #3) ---

function renderRecentSpeakers() {
    const $list = $('#ig_audio_recent_speakers');
    const $hint = $('#ig_audio_recent_speakers_hint');
    if (!$list.length) return;

    const map = getSettings().characterVoiceMap || {};
    /** @type {Array<[string, { count: number, source: 'pool'|'default', voiceId: string }]>} */
    const entries = [];
    for (const [name, info] of _recentUnmappedSpeakers.entries()) {
        if (map[name]) continue; // already mapped explicitly, drop the chip
        entries.push([name, info]);
    }
    entries.sort((a, b) => b[1].count - a[1].count);

    $list.empty();
    if (!entries.length) {
        $hint.hide();
        return;
    }
    $hint.show();
    for (const [name, info] of entries) {
        const $chip = $('<div class="menu_button ig_audio_recent_speaker_chip"></div>')
            .text(`+ ${name} (${info.source})`)
            .attr('title', `В этом чате: ${info.count} раз${info.count === 1 ? '' : ''}. Нажмите, чтобы назначить голос.`)
            .data('name', name)
            .data('voiceid', info.voiceId);
        $list.append($chip);
    }
}

/**
 * Run `fn(item, index)` for each item with at most `limit` calls in flight at once.
 * Results are returned in the same order as the input. Errors thrown by `fn` propagate
 * (the whole call rejects); callers that want graceful per-item failure should catch
 * inside `fn` and return null/sentinel.
 *
 * Used to keep ElevenLabs concurrency under provider-side limits (free tier = 4).
 * Cache hits don't actually hit the API but go through the limiter anyway - they
 * resolve so fast the slot is freed in microseconds.
 *
 * @template T, R
 * @param {readonly T[]} items
 * @param {number} limit
 * @param {(item: T, index: number) => Promise<R>} fn
 * @returns {Promise<R[]>}
 */
async function runWithConcurrencyLimit(items, limit, fn) {
    if (!items.length) return [];
    /** @type {R[]} */
    const results = new Array(items.length);
    const cap = Math.max(1, Math.min(limit | 0, items.length));
    let cursor = 0;

    async function worker() {
        while (true) {
            const i = cursor++;
            if (i >= items.length) return;
            results[i] = await fn(items[i], i);
        }
    }

    const workers = [];
    for (let i = 0; i < cap; i++) workers.push(worker());
    await Promise.all(workers);
    return results;
}

/**
 * FNV-1a 32-bit hash. Stable across runs/processes, no library required.
 * Used to deterministically pick a voice from `voicePool` for unmapped speakers.
 *
 * @param {string} str
 * @returns {number} unsigned 32-bit integer
 */
function stableHash(str) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < str.length; i++) {
        h ^= str.charCodeAt(i);
        h = (h * 16777619) >>> 0;
    }
    return h;
}

/**
 * @typedef {object} ResolvedVoice
 * @property {string} voiceId
 * @property {'mapped'|'pool'|'default'} source
 * @property {string} speaker - The trimmed speaker name we resolved against.
 * @property {number} [poolIndex] - Set only when source === 'pool'.
 */

/**
 * Resolve a voice ID for a speaker using a 3-tier priority:
 *   1. characterVoiceMap[name]    -> source: 'mapped'
 *   2. voicePool[hash(name) % len] -> source: 'pool' (skipped for "unknown" / empty pool)
 *   3. defaultVoiceId              -> source: 'default'
 *
 * @param {string} name
 * @returns {ResolvedVoice}
 */
function resolveVoiceForSpeaker(name) {
    const s = getSettings();
    const trimmed = (name || '').trim();

    if (trimmed && s.characterVoiceMap && s.characterVoiceMap[trimmed]) {
        return { voiceId: s.characterVoiceMap[trimmed], source: 'mapped', speaker: trimmed };
    }

    const pool = (Array.isArray(s.voicePool) ? s.voicePool : [])
        .filter(p => p && typeof p.id === 'string' && p.id.trim());
    if (pool.length && trimmed && trimmed !== 'unknown') {
        const idx = stableHash(trimmed) % pool.length;
        return {
            voiceId: pool[idx].id.trim(),
            source: 'pool',
            speaker: trimmed,
            poolIndex: idx,
        };
    }

    return { voiceId: (s.defaultVoiceId || '').trim(), source: 'default', speaker: trimmed };
}

/**
 * Backwards-compat shim. New callers should use {@link resolveVoiceForSpeaker}.
 * @param {string} characterName
 * @returns {string}
 */
function resolveVoiceId(characterName) {
    return resolveVoiceForSpeaker(characterName).voiceId;
}

async function generateTtsBlob({ apiKey, voiceId, text, modelId, outputFormat, voiceSettings }) {
    // voiceSettings is part of the cache key so changing any slider invalidates
    // previously cached audio for the same line.
    const params = { kind: 'tts', voiceId, modelId, text, outputFormat, voiceSettings };
    const key = await cacheKey(params);
    const cached = await getCached(key);
    if (cached) {
        console.debug(LOG_PREFIX, 'Cache hit (tts):', text.slice(0, 60));
        return cached;
    }
    const blob = await synthesizeSpeech({ apiKey, voiceId, text, modelId, outputFormat, voiceSettings });
    await setCached(key, blob, { kind: 'tts', text, voiceId, modelId });
    return blob;
}

async function handleAmbience(text, settings) {
    const blob = await getOrGenerate({
        kind: 'ambience',
        text,
        outputFormat: settings.outputFormat,
        durationSeconds: settings.ambienceDuration,
        promptInfluence: settings.promptInfluence,
        loop: true,
        apiKey: settings.apiKey,
    });
    await audio.setAmbience(blob, text);
}

async function getOrGenerate(params) {
    const key = await cacheKey(params);
    const cached = await getCached(key);
    if (cached) {
        console.debug(LOG_PREFIX, 'Cache hit:', params.kind, params.text);
        return cached;
    }
    const blob = await generateSound(params);
    await setCached(key, blob, { kind: params.kind, text: params.text });
    return blob;
}

function registerSlashCommand() {
    const ctx = getCtx();
    const SlashCommandParser = ctx.SlashCommandParser;
    const SlashCommand = ctx.SlashCommand;
    const SlashCommandNamedArgument = ctx.SlashCommandNamedArgument;
    const ARGUMENT_TYPE = ctx.ARGUMENT_TYPE;

    if (!SlashCommandParser?.addCommandObject || !SlashCommand?.fromProps) {
        console.warn(LOG_PREFIX, 'SlashCommandParser unavailable; skipping /genaudio registration.');
        return;
    }

    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'genaudio',
        aliases: ['immersive-audio'],
        callback: async (namedArgs) => {
            const target = (namedArgs?.target ?? 'last').toString();
            let messageId = null;
            if (target === 'last' || target === '') {
                messageId = lastCharacterMessageId();
            } else {
                const n = Number(target);
                messageId = Number.isFinite(n) ? n : lastCharacterMessageId();
            }
            if (messageId == null) return '';
            await runPipeline(messageId, { source: 'slash' });
            return '';
        },
        helpString: '<div>Создать озвучку, эффекты и атмосферу для сообщения чата через ElevenLabs.</div>',
        namedArgumentList: SlashCommandNamedArgument && ARGUMENT_TYPE
            ? [
                SlashCommandNamedArgument.fromProps({
                    name: 'target',
                    description: 'Идентификатор сообщения или "last" для последнего сообщения персонажа.',
                    typeList: ARGUMENT_TYPE.STRING,
                    defaultValue: 'last',
                }),
            ]
            : [],
        unnamedArgumentList: [],
    }));
}

function registerEventListeners() {
    const ctx = getCtx();
    const { eventSource, event_types } = ctx;

    eventSource.on(event_types.CHARACTER_MESSAGE_RENDERED, (messageId) => {
        const id = Number(messageId);
        if (Number.isFinite(id)) {
            injectButtonForMessage(id);
            scheduleAutoRun(id);
        }
    });

    eventSource.on(event_types.MESSAGE_SWIPED, (messageId) => {
        const id = Number(messageId);
        if (Number.isFinite(id)) {
            scheduleAutoRun(id);
        }
    });

    eventSource.on(event_types.USER_MESSAGE_RENDERED, (messageId) => {
        const id = Number(messageId);
        if (Number.isFinite(id)) {
            injectButtonForMessage(id);
        }
    });

    eventSource.on(event_types.CHAT_CHANGED, () => {
        if (_autoTimer) {
            clearTimeout(_autoTimer);
            _autoTimer = null;
        }
        audio.stopAmbience().catch(() => { /* noop */ });
        audio.stopTts();
        _lastSfxQueue = [];
        _lastTtsQueue = [];
        _ttsCancelled = false;
        _voiceMissingWarned = false;
        _recentUnmappedSpeakers.clear();
        _toastedUnmappedSpeakers.clear();
        refreshReplayButton();
        updateAmbiencePill();
        refreshSpeakerSuggestions();
        renderRecentSpeakers();
        setTimeout(injectButtonsForAllMessages, 100);
    });

    eventSource.on(event_types.SETTINGS_UPDATED, applyAudioVolumes);
}

jQuery(async () => {
    const ctx = getCtx();
    getSettings();
    applyAudioVolumes();

    await renderSettingsPanel();

    bindMessageButtonHandler();
    registerEventListeners();
    registerSlashCommand();

    ctx.eventSource.on(ctx.event_types.APP_READY, () => {
        injectButtonsForAllMessages();
    });

    setTimeout(injectButtonsForAllMessages, 250);

    console.log(LOG_PREFIX, 'Extension loaded.');
});
