export {};

// 1. Import for user-scoped extensions
import '../../../../public/global';
// 2. Import for server-scoped extensions
import '../../../../global';

// Define additional types if needed...
declare global {
    interface ToastrLike {
        info(message: string, title?: string, options?: object): unknown;
        success(message: string, title?: string, options?: object): unknown;
        warning(message: string, title?: string, options?: object): unknown;
        error(message: string, title?: string, options?: object): unknown;
    }
    // toastr is bundled globally by SillyTavern; relax its typing for extension use.
    const toastr: ToastrLike;
}