/*
 * Error Companion — what Tawan knows about
 *
 * Rules are tried in order; the first whose `match` hits the toast text
 * (title + message, tags stripped) wins, so put the specific ones first:
 * "blocked" before "empty" (a blocked prompt also says "no candidate"),
 * "quota" before "credits" (Google's 429 mentions billing), "overloaded"
 * before "server" (both can carry a 5xx code).
 *
 * lines: tiers by how many times this error was seen today; the highest tier
 * whose `from` ≤ count is used and one line is picked at random. {n} = count.
 * sample: a real-looking toast for the settings preview and /ec-test.
 * followup: a vague message SillyTavern shows next to a more specific one; it
 *   never replaces an explanation that is already on screen.
 */

/** @typedef {'neutral'|'tired'|'pious'|'exhausted'|'shocked'|'confused'} Mood */

/**
 * @typedef {object} ErrorRule
 * @property {string} id
 * @property {string} name      short label for the settings list
 * @property {Mood} mood
 * @property {RegExp[]} match
 * @property {{ from: number, text: string[] }[]} lines
 * @property {string} title     heading above the explanation
 * @property {string} what      what it means
 * @property {string[]} fixes   what to try
 * @property {{ message: string, title?: string }} sample
 * @property {boolean} [followup]
 */

/** @type {ErrorRule[]} */
export const RULES = [
    {
        id: 'stserver',
        name: "Нет связи с сервером ST / не удаётся сохранить",
        mood: 'shocked',
        match: [
            /(settings|chat) could not be saved|check the server connection|csrf token|st server cannot be reached|server is running and accessible/i,
        ],
        lines: [
            { from: 1, text: ["Подождите! Не получается сохранить.", "Наш большой дом — сервер ST — не отвечает.", "Спокойно: сначала сохраните копию набранного текста."] },
            { from: 3, text: ["Сервер не отвечает уже {n} раз… Проверьте окно терминала."] },
        ],
        title: "Страница не может связаться с сервером SillyTavern",
        what: "SillyTavern состоит из страницы браузера и сервера, работающего в терминале, Termux или на хостинге. Страница не смогла отправить данные серверу; последние настройки или чат могли не сохраниться. CSRF token означает рассогласование страницы и сервера, например после перезапуска или долгого простоя.",
        fixes: [
            "Скопируйте набранный текст на случай потери.",
            "Убедитесь, что сервер ST работает и окно терминала или Termux не закрыто.",
            "Обновите страницу; это часто устраняет ошибку CSRF token.",
            "При удалённом подключении проверьте интернет и адрес ST.",
            "Проверьте свободное место на устройстве, где работает ST.",
        ],
        sample: { message: 'Check the server connection and reload the page to prevent data loss.', title: 'Settings could not be saved' },
    },
    {
        id: 'import',
        name: "Не удаётся импортировать карточку",
        mood: 'confused',
        match: [
            /could not import character|file is likely invalid or corrupted/i,
        ],
        lines: [
            { from: 1, text: ["Эту карточку я прочитать не могу…", "Конверт пустой: персонажа внутри нет.", "Картинка красивая, а куда делся персонаж?"] },
        ],
        title: "ST не может прочитать этот файл как карточку персонажа",
        what: "Карточка PNG хранит данные персонажа внутри изображения. Сжатие или повторное сохранение могут удалить эти данные, оставив обычную картинку. Возможно, вместо карточки скачана веб-страница или неподдерживаемый файл.",
        fixes: [
            "Заново скачайте оригинал. Скриншот и картинка, пересланная через соцсеть, могут не содержать данных карточки.",
            "Если есть JSON карточки, попробуйте импортировать его.",
            "Для карточки с сайта попробуйте импорт по ссылке в списке персонажей.",
        ],
        sample: { message: 'The file is likely invalid or corrupted.', title: 'Could not import character' },
    },
    {
        id: 'blocked',
        name: "Сработал фильтр содержимого",
        mood: 'pious',
        match: [
            /PROHIBITED_CONTENT|\bSAFETY\b|BLOCKLIST|\bSPII\b/, // Google's block reasons, upper case only
            /blocked due to|block_?reason|requires moderation|content (filter|policy|management)|flagged|safety (system|filter)|violat(es|ed|ion)/i,
            /^Reasons:/,
        ],
        lines: [
            { from: 1, text: ["Есть в чём исповедаться?", "Дитя моё… система это не пропускает.", "Не буду спрашивать, что вы написали, но система всё увидела."] },
            { from: 3, text: ["За сегодня уже {n} исповедей… немало грехов.", "Да смилуется Господь… то есть фильтр."] },
            { from: 8, text: ["Уже {n} раз… Может, сегодня сначала сделаем доброе дело?"] },
        ],
        title: "Провайдер отказался отвечать из-за фильтра",
        what: "Провайдер проверил запрос или ответ и счёл его нарушающим правила содержимого. В исходной справке Google различаются PROHIBITED_CONTENT (не отключается настройками Safety в ST) и SAFETY (настраиваемый фильтр).",
        fixes: [
            "Измените или удалите последнее сообщение и отправьте снова: иногда влияет одно слово.",
            "Проверьте формулировки в карточке, лорбуке и пресете.",
            "В длинном чате фильтр может сработать на старый текст, который ещё находится в контексте.",
            "У разных моделей и провайдеров фильтры отличаются; можно выбрать другую модель или провайдера.",
        ],
        sample: { message: 'Google AI Studio API returned no candidate\nPrompt was blocked due to : PROHIBITED_CONTENT', title: 'Chat Completion API' },
    },
    {
        id: 'prefill',
        name: "Последнее сообщение — от бота (prefill)",
        mood: 'confused',
        match: [
            /end(s|ing)? with an? (model|assistant) (turn|message)|must end with a user (turn|message)|(assistant|model) (message )?prefill/i,
        ],
        lines: [
            { from: 1, text: ["Предлагаете мне продолжить собственную фразу? Эта модель так не умеет.", "Последняя очередь говорить должна быть у пользователя, а не у бота.", "Последнее отправленное сообщение принадлежит боту, поэтому модель не продолжает."] },
            { from: 3, text: ["Уже {n} попыток. Может, сначала отключим prefill?"] },
        ],
        title: "Модель не принимает завершающее сообщение ассистента",
        what: "Запрос заканчивается сообщением assistant/model: это prefill, предлагающий продолжить заранее заданный текст. Некоторые версии Gemini и Claude этого не поддерживают и требуют последним сообщение пользователя.",
        fixes: [
            "При ошибке во время Continue отключите Continue prefill в AI Response Configuration.",
            "Если последний промпт пресета имеет роль AI/Assistant (часто называется prefill), отключите его или измените роль на User/System.",
            "Очистите Assistant Prefill для Claude или Start Reply With в Advanced Formatting.",
        ],
        sample: { message: 'Requests ending with a model turn are not supported.', title: 'Chat Completion API' },
    },
    {
        id: 'param',
        name: "Неподдерживаемый параметр модели",
        mood: 'confused',
        match: [
            /thinking (level|budget|config)|reasoning[ _]?effort|unsupported (parameter|value)|(parameter|argument|value).{0,60}not supported|not supported (for|with|by) (this|the) model|invalid value for|unknown (parameter|field)|unrecognized (request )?(argument|parameter)|extra inputs are not permitted/i,
        ],
        lines: [
            { from: 1, text: ["Модель не принимает эту настройку. Немного поправим — и готово.", "Настройки немного вышли за пределы возможностей модели.", "У этой модели такой кнопки нет: нажимать бесполезно."] },
        ],
        title: "Передан параметр, который модель не поддерживает",
        what: "Некоторые настройки AI Response Configuration не подходят этой модели: например Reasoning Effort/thinking level, temperature, top_k или penalty. Обычно сообщение ошибки указывает проблемный параметр.",
        fixes: [
            "Для thinking/reasoning выберите Auto или другой уровень Reasoning Effort.",
            "Найдите названный параметр в AI Response Configuration и измените или сбросьте его.",
            "Пресет для другой модели может содержать несовместимые настройки; попробуйте другой.",
        ],
        sample: { message: 'Thinking level MINIMAL is not supported for this model. Please retry with other thinking level.', title: 'Chat Completion API' },
    },
    {
        id: 'overloaded',
        name: "Сервер перегружен (503)",
        mood: 'tired',
        match: [
            /overloaded|high demand|spikes? in demand|currently unavailable|UNAVAILABLE|over capacity|\b(503|529)\b/i,
        ],
        lines: [
            { from: 1, text: ["Ох… сервер снова переполнен. Подождём немного.", "Все места заняты, придётся постоять в очереди.", "Сейчас весь мир пытается пользоваться им одновременно. Спокойно."] },
            { from: 3, text: ["Может, выйдем потрогать траву?", "Попейте воды и разомнитесь, потом попробуем снова.", "Уже {n}-я попытка… Заварим чай и подождём вместе?"] },
            { from: 8, text: ["Я уже потрогал траву за вас… Она тоже не отвечает.", "Сегодня уже {n} попыток. Трава снаружи по вам скучает."] },
        ],
        title: "Сервер провайдера временно перегружен",
        what: "Одновременно слишком много запросов к модели. Это часто случается у популярных моделей и бесплатного API Google AI Studio. Такая ошибка сама по себе не означает неправильный ключ или настройки.",
        fixes: [
            "Подождите от нескольких секунд до нескольких минут и повторите генерацию или свайп.",
            "Временно выберите другую модель, например Flash или менее загруженную.",
            "Новый API-ключ не исправит перегрузку сервера.",
        ],
        sample: { message: 'The model is overloaded. Please try again later.', title: 'Chat Completion API' },
    },
    {
        id: 'quota',
        name: "Исчерпана квота / слишком частые запросы (429)",
        mood: 'exhausted',
        match: [
            /quota|rate.?limit|RESOURCE_EXHAUSTED|resource has been exhausted|too many requests|\b429\b|free-models-per/i,
        ],
        lines: [
            { from: 1, text: ["Сегодня мы уже много поговорили. Давайте передохнём…", "Силы закончились… Квота дальше не пускает.", "Помедленнее, я не успеваю!"] },
            { from: 3, text: ["Уже {n} раз… Я больше не могу.", "Квота не бесконечна: она тоже заканчивается."] },
        ],
        title: "Запросы превысили выделенную квоту",
        what: "Провайдер ограничивает число запросов в минуту или за день. В исходной справке бесплатная квота Google разделяется по моделям, а бесплатные модели OpenRouter имеют дневной лимит.",
        fixes: [
            "Если отправляли запросы подряд, подождите около минуты.",
            "Если закончилась дневная квота, дождитесь сброса. В справке Google указан сброс в полночь по тихоокеанскому времени.",
            "Попробуйте другую модель: квоты моделей могут различаться.",
            "Фоновые запросы расширений — сводки, изображения, перевод — тоже расходуют квоту. Их отключение помогает экономить.",
        ],
        sample: { message: 'You exceeded your current quota, please check your plan and billing details.', title: 'Chat Completion API' },
    },
    {
        id: 'credits',
        name: "Недостаточно средств (402)",
        mood: 'exhausted',
        match: [
            /insufficient (credits|balance|funds)|credit balance|more credits|can only afford|payment required|\b402\b/i,
        ],
        lines: [
            { from: 1, text: ["Кошелёк уже плачет.", "На счёте не хватает денег…", "Я бы заплатил за вас, если бы у меня были деньги."] },
            { from: 3, text: ["Кошелёк всё ещё плачет: уже {n} попыток."] },
        ],
        title: "На счёте недостаточно средств",
        what: "На платном API, например OpenRouter, Anthropic или OpenAI, не хватает средств для этого запроса. Иногда баланс ещё положительный, но не покрывает заданную максимальную длину ответа: провайдер резервирует сумму под неё.",
        fixes: [
            "Пополните баланс на сайте провайдера.",
            "Уменьшите Max Response Length.",
            "Временно выберите бесплатную модель; в OpenRouter такие имена могут оканчиваться на :free.",
        ],
        sample: { message: 'This request requires more credits, or fewer max_tokens. You requested up to 8192 tokens, but can only afford 1200.', title: 'Chat Completion API' },
    },
    {
        id: 'denied',
        name: "Аккаунт или проект заблокирован",
        mood: 'shocked',
        match: [
            /denied access|has been (suspended|banned|disabled|terminated)|account (is |was |has been )?(suspended|disabled|deactivated|banned)|organization (has been )?disabled/i,
        ],
        lines: [
            { from: 1, text: ["Эм… говорят, этот проект заблокирован.", "Дверь не просто заперта — её наглухо закрыли."] },
        ],
        title: "Провайдер отключил доступ аккаунту или проекту",
        what: "Это не опечатка в ключе: провайдер отключил аккаунт либо проект, к которому относится ключ, например в Google AI Studio/Cloud. Причиной могут быть правила сервиса, оплата или другое решение провайдера. В ST это не исправить.",
        fixes: [
            "Откройте сайт провайдера, Google AI Studio или Cloud Console и прочитайте уведомления и письма о причине.",
            "Если считаете блокировку ошибкой, обратитесь в поддержку или подайте апелляцию по указанному каналу.",
            "Пока ждёте, можно пользоваться другим провайдером.",
        ],
        sample: { message: 'Your project has been denied access. Please contact support.', title: 'Chat Completion API' },
    },
    {
        id: 'forbidden',
        name: "Доступ запрещён (403 Forbidden)",
        mood: 'confused',
        match: [
            /\bforbidden\b|\b403\b/i,
        ],
        lines: [
            { from: 1, text: ["Охранник у двери нас не пускает.", "Постучали… а нам говорят: вход запрещён.", "Наш пропуск к этой двери не подходит."] },
            { from: 3, text: ["Нас вернули уже {n} раз. Проверим пароль прокси?"] },
        ],
        title: "Сервис не разрешает доступ",
        what: "В отличие от Unauthorized, ошибка 403 означает запрет доступа. У reverse proxy причиной могут быть пароль, закрытый доступ или регистрация IP, блокировка региона/IP либо недействующий ключ владельца прокси.",
        fixes: [
            "Проверьте Proxy Password в API Connections; уберите случайные пробелы.",
            "Проверьте Reverse Proxy и необходимое окончание адреса, например /v1.",
            "Прочитайте объявления владельца прокси: возможны перерыв, новый пароль или обязательная регистрация.",
            "Если используете VPN, попробуйте отключить его; уточните у владельца, поддерживается ли ваш регион.",
            "Если ошибка reverse proxy остаётся, обратитесь к его владельцу: сообщите текст ошибки и время. Не публикуйте API-ключи и пароли в общем чате.",
            "Без прокси: проверьте права ключа на модель или сервис; при необходимости создайте новый ключ.",
        ],
        sample: { message: 'Forbidden', title: 'API returned an error' },
    },
    {
        id: 'key',
        name: "Неверный API-ключ",
        mood: 'confused',
        match: [
            /api.?key (is )?(not valid|invalid|expired)|invalid.{0,20}(api.?key|x-api-key|authentication)|incorrect api key|API_KEY_INVALID/i,
            /no auth credentials|unauthori[sz]ed|\b401\b|permission.denied|PERMISSION_DENIED|user not found/i,
        ],
        lines: [
            { from: 1, text: ["Ключ не от этого замка.", "Хм… этот ключ не принимают.", "Дверь заперта, а выданный ключ не подходит."] },
            { from: 3, text: ["Пробуем один и тот же ключ уже {n} раз…"] },
        ],
        title: "Провайдер не принимает API-ключ",
        what: "Ключ мог быть неверно введён или скопирован, удалён, просрочен, не иметь доступа к модели либо относиться к другому провайдеру — например ключ OpenRouter в поле Google.",
        fixes: [
            "Проверьте выбранного провайдера в API Connections.",
            "Заново скопируйте ключ с сайта провайдера без пробелов по краям и нажмите Connect.",
            "Скрывайте API-ключ на скриншотах для обсуждения.",
        ],
        sample: { message: 'API key not valid. Please pass a valid API key.', title: 'Chat Completion API' },
    },
    {
        id: 'location',
        name: "Регион не поддерживается",
        mood: 'confused',
        match: [
            /location is not supported|unsupported.(country|region|location)|not available in your (country|region)|FAILED_PRECONDITION/i,
        ],
        lines: [
            { from: 1, text: ["Говорят, у нас этот сервис ещё не работает.", "Хм… в какой стране мы сейчас оказались?"] },
        ],
        title: "Сервис недоступен из этой страны",
        what: "Провайдер определил неподдерживаемую страну или регион. Такое возможно при VPN либо запуске ST на сервере в неподдерживаемой стране.",
        fixes: [
            "Проверьте VPN: отключите его или выберите поддерживаемую страну.",
            "Для облачного или арендованного сервера проверьте страну его размещения.",
        ],
        sample: { message: 'User location is not supported for the API use.', title: 'Chat Completion API' },
    },
    {
        id: 'context',
        name: "Запрос превышает контекст",
        mood: 'exhausted',
        match: [
            /exceed(s)? the context|context (size|length|window)|maximum context|exceeds the maximum number of tokens|prompt is too long|too many (input )?tokens|input token count/i,
        ],
        lines: [
            { from: 1, text: ["Слишком много! У меня сейчас голова взорвётся.", "Память заполнена, больше не помещается.", "Я столько не прочитаю — длиннее романа!"] },
        ],
        title: "Запрос длиннее допустимого контекста",
        what: "Карточка, пресет, лорбук и история вместе превышают лимит модели или выбранный Context Size. Mandatory prompts exceed означает, что обязательные части — системный промпт, карточка и закреплённые блоки — уже не оставляют места истории.",
        fixes: [
            "Увеличьте Context Size в AI Response Configuration в пределах возможностей модели.",
            "Уменьшите Max Response Length: ST резервирует место для ответа.",
            "Сократите длинную карточку, постоянные записи лорбука, заметку автора или пресет.",
        ],
        sample: { message: 'Mandatory prompts exceed the context size.' },
    },
    {
        id: 'empty',
        name: "Пустой ответ",
        mood: 'confused',
        match: [
            /candidate text empty|returned no candidate|empty (response|reply|message)|response was empty|no (response|content) (was )?returned/i,
        ],
        lines: [
            { from: 1, text: ["Ответ пришёл… пустой.", "Тишина… будто прочитали и не ответили.", "Получили пустую коробку: внутри ничего."] },
            { from: 3, text: ["Пусто уже {n} раз… Они на нас обиделись?"] },
        ],
        title: "Провайдер ответил без текста",
        what: "Запрос дошёл до сервиса, но текста в ответе нет. Возможны обрыв ответа фильтром без ясного уведомления либо расход всех выходных токенов на рассуждение thinking-модели.",
        fixes: [
            "Повторите свайп: ошибка может быть разовой.",
            "Для thinking-модели попробуйте увеличить Max Response Length.",
            "Если ошибка повторяется в одной сцене, возможен фильтр: измените последнее сообщение.",
        ],
        sample: { message: 'Google AI Studio Candidate text empty', title: 'Chat Completion API' },
    },
    {
        id: 'model',
        name: "Модель недоступна или не найдена",
        mood: 'confused',
        match: [
            /not found for API version|no endpoints found|model.{0,60}(not found|does not exist|not supported|is not available)|model_not_found|(invalid|unknown) model/i,
            /multi-?turn chat is not enabled|is not enabled for models?\//i,
        ],
        lines: [
            { from: 1, text: ["Этой модели… не существует. Или когда-то существовала.", "Модель не найдена. Наверное, переехала."] },
        ],
        title: "Выбранную модель нельзя использовать",
        what: "Имя модели может не существовать, модель снята с обслуживания, ключ не имеет доступа либо модель не предназначена для многоходового чата. Preview/experimental-версии нередко отключают после выпуска основной.",
        fixes: [
            "Выберите модель из списка API Connections.",
            "Multiturn chat is not enabled означает, что модель не поддерживает продолжительный диалог; выберите чат-модель.",
            "Если вводили имя вручную, проверьте написание.",
        ],
        sample: { message: 'models/gemini-1.0-pro is not found for API version v1beta, or is not supported for generateContent.', title: 'Chat Completion API' },
    },
    {
        id: 'network',
        name: "Нет соединения",
        mood: 'shocked',
        match: [
            /failed to fetch|fetch failed|network ?error|ECONNREFUSED|ECONNRESET|ENOTFOUND|ETIMEDOUT|EAI_AGAIN|socket hang up|connection (refused|error|reset)|load failed/i,
        ],
        lines: [
            { from: 1, text: ["Связь оборвалась! Не удаётся соединиться.", "Алло? Алло?! Никто не берёт трубку.", "Подождите, куда пропал интернет?!"] },
            { from: 3, text: ["Снова нет связи, уже {n} раз… Мне становится тревожно."] },
        ],
        title: "Запрос не дошёл до сервиса",
        what: "ST не смог связаться с адресатом. Возможны потеря интернета, закрытый терминал ST, неверный адрес API или прокси, незапущенный локальный KoboldCpp/Ollama.",
        fixes: [
            "Проверьте интернет.",
            "Убедитесь, что терминал ST открыт; не закрывайте Termux на телефоне.",
            "Проверьте URL в API Connections и reverse proxy, затем нажмите Connect.",
            "Если ошибка reverse proxy остаётся, обратитесь к его владельцу: сообщите текст ошибки и время. Не публикуйте API-ключи и пароли в общем чате.",
        ],
        sample: { message: 'Failed to fetch', title: 'Chat Completion API' },
    },
    {
        id: 'noreply',
        name: "API не вернул ответ",
        mood: 'confused',
        followup: true,
        match: [
            /could not get a reply/i,
        ],
        lines: [
            { from: 1, text: ["Они ничего не ответили.", "Отправили… но в ответ тишина."] },
        ],
        title: "ST не получил пригодного ответа API",
        what: "Это общее предупреждение ST о неудаче подключения или генерации. Часто рядом появляется более точная ошибка, например Unauthorized, 503 или project denied. Ориентируйтесь на неё.",
        fixes: [
            "Посмотрите другую ошибку, появившуюся одновременно: она обычно точнее.",
            "Проверьте ключ и провайдера в API Connections, затем нажмите Connect.",
            "Проверьте интернет и адрес reverse proxy, если используете его.",
            "Если ошибка reverse proxy остаётся, обратитесь к его владельцу: сообщите текст ошибки и время. Не публикуйте API-ключи и пароли в общем чате.",
        ],
        sample: { message: 'Could not get a reply from API. Check your connection settings / API key and try again.' },
    },
    {
        id: 'server',
        name: "Ошибка сервера (500/502/504)",
        mood: 'shocked',
        match: [
            /internal (server )?error|bad gateway|gateway time-?out|deadline.(exceeded|expired)|timed? ?out|\b50[024]\b|provider returned error/i,
            /upstream (error|request|connect)|do request failed|bad response from upstream/i,
        ],
        lines: [
            { from: 1, text: ["Это у них всё сломалось! Мы не виноваты.", "Что там вообще происходит?..", "Сервер упал! Кто-нибудь, помогите!"] },
            { from: 3, text: ["Уже {n} сбоев… Может, передохнём?"] },
        ],
        title: "На стороне провайдера возникла ошибка",
        what: "Сервер провайдера или промежуточный прокси столкнулся с внутренней ошибкой либо не успел ответить до тайм-аута. Обычно это временная проблема сервиса.",
        fixes: [
            "Повторите запрос: часто проблема проходит сама.",
            "Если ошибка длится долго, проверьте страницу статуса провайдера.",
            "Если есть reverse proxy, временно проверьте соединение без него.",
            "Upstream error у посредника означает, что он не смог связаться с исходным провайдером. Повторите запрос или выберите другую модель/маршрут.",
            "Если ошибка reverse proxy остаётся, обратитесь к его владельцу: сообщите текст ошибки и время. Не публикуйте API-ключи и пароли в общем чате.",
            "Очень длинный промпт или долгое рассуждение могут приводить к 504. Попробуйте уменьшить объём запроса.",
        ],
        sample: { message: 'Internal error encountered.', title: 'Chat Completion API' },
    },
];

/** Shown for API errors no rule knows. */
export const UNKNOWN = {
    id: 'unknown',
    name: "Неизвестная ошибка",
    mood: 'neutral',
    match: [],
    lines: [
        { from: 1, text: ["Такую я тоже не знаю…", "Новая ошибка, раньше не встречалась.", "Хм… придётся читать исходное сообщение."] },
    ],
    title: "Error Companion пока не знает эту ошибку",
    what: "Исходное сообщение приведено ниже и может содержать подсказки. Обычно 4xx указывает на запрос, настройки, ключ или содержимое, а 5xx — на сервер.",
    fixes: [
        "Повторите генерацию.",
        "Скопируйте ошибку и поищите её в интернете или спросите в сообществе, предварительно удалив ключи, если они попали в текст.",
    ],
    sample: { message: 'Something strange happened: [object Object]', title: 'API returned an error' },
};

/** Toast titles that mean "the model / API call failed" — only these get the unknown fallback. */
export const API_TITLE = /API|generation|completion|connection/i;
