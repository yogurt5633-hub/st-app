/*
 * Memory Hub — SillyTavern UI extension
 *
 * One place for long-chat memory, built to spend as few tokens as possible:
 *   1. Every N messages, the oldest un-summarized chunk is turned into one
 *      "memory" (title, keys, bullet summary). The same call also refreshes a
 *      short "story so far". One model call per chunk, never per turn.
 *   2. Messages that are already summarized are dropped from the prompt (the
 *      chat file is untouched), so the raw history sent stays small.
 *   3. Each turn, only the memories that matter now are recalled: the newest
 *      one (continuity), pinned ones, and the best BM25 matches for the last
 *      few messages, all under a token budget. No vector setup; Thai text is
 *      split with the browser's word breaker (see lib.js).
 *
 * Everything lives in the chat's metadata. SillyTavern copies metadata into
 * branches; reconcile() then drops the memories past the branch point and
 * restores the story-so-far that was current there. "Continue in a new chat"
 * carries the memories over and opens the new chat with the last reply.
 *
 * Summaries go to an ordered list of APIs (main API and/or Connection
 * Profiles); when one fails, times out or answers empty, the next is tried.
 */

import { blockKind, cleanKeys, cleanText, findGaps, hasSegmenter, isComplete, nextChunk, parseMany, parseSummary, rankMemories } from './lib.js';
import { allModules, BUILTIN_MODULES, buildOverviewRule, buildPrompt, extraWords, modulesFromTags } from './modules.js';

const MODULE = 'memory_hub';
const LOG = '[MemoryHub]';
const VERSION = '1.9.3'; // keep in sync with manifest.json
const KEY_OVERVIEW = 'memory_hub_overview';
const KEY_RECALL = 'memory_hub_recall';

// ---------------------------------------------------------------- prompts

const FORMAT = `Answer in exactly this format and nothing else:
<memory>
title: <short title>
keys: <comma separated>
summary:
- ...
</memory>{{overview_format}}`;

const OVERVIEW_FORMAT = '\n<overview>\n<updated overview>\n</overview>';

// v1.0.0 shipped one prompt; if a user edited it, keep theirs as "custom".
const PROMPT_V1 = `You are the memory keeper of an ongoing roleplay between {{user}} and {{char}}.
Read NEW MESSAGES and write one compact memory of them.

Rules:
- Write in the same language the story is written in.
- Keep only what will matter later: events, decisions, promises, secrets revealed, changes in relationships, feelings that shifted, injuries, items, places, unresolved threads. Skip flavour text, repeated description and status panels.
- Be concrete: names, places, objects, numbers. No commentary, no guessing.
- summary: short bullet points, at most {{memory_words}} words in total.
- keys: 3-8 distinctive words someone would say when this memory becomes relevant again (places, objects, events, nicknames). Never use a main character's name alone as a key.
{{overview_rule}}
Answer in exactly this format and nothing else:
<memory>
title: <short title>
keys: <comma separated>
summary:
- ...
</memory>{{overview_format}}`;

const PROMPT_OPTIMIZE = `You tidy up the long-term memories of an ongoing roleplay between {{user}} and {{char}}.
Each MEMORY below is one past event. Rewrite each one so it is compact but keeps every fact that could matter later (who, what, where, outcome, feelings, promises, items, numbers).

Rules:
- Write in the same language as the memory.
- summary: bullet points, at most {{memory_words}} words per memory. Remove repetition, flowery prose and meta text (like "Memory #12", dates of the summary, formatting notes).
- Always write names in full instead of "he/she".
- title: short and specific.
- keys: 3-8 distinctive words for when this memory becomes relevant again (places, objects, events, secondary characters). Never {{user}} or {{char}} alone.
- Keep the same id. Do not merge or drop memories.

Answer with one block per memory and nothing else:
<memory id="ID">
title: ...
keys: ...
summary:
- ...
</memory>`;

const PROMPT_REBUILD = `You keep the "story so far" of an ongoing roleplay between {{user}} and {{char}}.
Update PREVIOUS OVERVIEW with the MEMORIES below (they are in story order).
Write in the same language as the story.
{{overview_rule}}
Answer in exactly this format and nothing else:
<overview>
...
</overview>`;

const DEFAULTS = Object.freeze({
    enabled: true,
    mode: 'auto',           // auto | semi (ask first) | manual
    chunkSize: 20,          // messages per memory
    semiSnooze: 10,         // semi: ask again after this many more messages
    quotaBoost: 1,          // multiplies memory length and recall budget
    keepRaw: 12,            // newest messages that are never summarized yet
    trimSummarized: true,   // drop summarized messages from the prompt
    overviewEnabled: true,
    overviewWords: 250,
    memoryWords: 120,
    responseLength: 800,
    topK: 3,
    recallBudget: 800,      // tokens for recalled memories (overview not counted)
    queryDepth: 4,          // last N messages used to decide what to recall
    includeLatest: true,
    style: 'modules',       // modules | custom
    defaultModules: null,   // module ids for bots without a choice; null = relationship (solo) / ensemble+story (group)
    botModules: {},         // 'group:<id>' -> module ids (characters keep theirs as tags on the card)
    customModules: [],      // user-made modules (same shape as BUILTIN_MODULES)
    autoWords: true,        // add the modules' extra words to the lengths below
    sources: null,          // ordered list: 'main' or Connection Profile ids
    timeoutSec: 120,
    overviewPosition: 'prompt', // 'prompt' | 'chat'
    overviewDepth: 4,
    recallPosition: 'chat',
    recallDepth: 2,
    maxMessageChars: 3000,  // per message, in the summarizer's input
    prompt: '',             // used when style = custom
    overviewTemplate: '[Story so far]\n{{overview}}',
    recallTemplate: '[Memories from earlier in the story that matter now]\n{{memories}}',
    notify: true,
    carrySummarizeRest: true,
    topbar: true,           // button + panel in the chat top bar (Top Info Bar extension)
    topbarFallback: true,   // our own slim bar when Top Info Bar is not installed
    icon: 'svg:heart',      // see ICONS
    badgeStyle: 'badge',    // badge | pill (no border) | replace (number instead of the icon) | replace-badge (badge instead of the icon) | none
    badgePos: 'br',         // br | tr | bl | center
    badgeColor: 'theme',    // theme | quote | em | underline | custom
    badgeFg: '#ffffff',     // custom colors
    badgeBg: '#444444',
    badgeBd: '#888888',
    badgeSize: 9,           // px
});

// ---------------------------------------------------------------- icons

const SVG_ICONS = {
    heart: ['закладка сердца', `<svg class="mh_svg" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.2 2h11.6c.7 0 1.2.5 1.2 1.2v17.9c0 .5-.6.8-1 .5L12 17.4l-6 4.2c-.4.3-1-.0-1-.5V3.2C5 2.5 5.5 2 6.2 2z"/><path fill="var(--mh-accent, #ff8fab)" d="M12 13.2l-.55-.5C9.5 10.95 8.2 9.8 8.2 8.4c0-1.15.9-2.05 2.05-2.05.65 0 1.27.3 1.67.78.4-.48 1.02-.78 1.67-.78 1.15 0 2.05.9 2.05 2.05 0 1.4-1.3 2.55-3.25 4.3z"/></svg>`],
    star: ['звездная закладка', `<svg class="mh_svg" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.2 2h11.6c.7 0 1.2.5 1.2 1.2v17.9c0 .5-.6.8-1 .5L12 17.4l-6 4.2c-.4.3-1-.0-1-.5V3.2C5 2.5 5.5 2 6.2 2z"/><path fill="var(--mh-accent-star, #ffd166)" d="M12 5.6l1.25 2.55 2.8.4-2.03 1.98.48 2.8L12 12l-2.5 1.33.48-2.8-2.03-1.98 2.8-.4z"/></svg>`],
    moon: ['закладка понедельника', `<svg class="mh_svg" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.2 2h11.6c.7 0 1.2.5 1.2 1.2v17.9c0 .5-.6.8-1 .5L12 17.4l-6 4.2c-.4.3-1-.0-1-.5V3.2C5 2.5 5.5 2 6.2 2z"/><path fill="var(--mh-accent-moon, #cdb4ff)" d="M13.6 5.8a3.9 3.9 0 1 0 1.9 6.3 3.2 3.2 0 0 1-1.9-6.3z"/></svg>`],
};
const ICONS = [
    'svg:heart', 'svg:star', 'svg:moon',
    'fa-solid fa-bookmark', 'fa-solid fa-book-bookmark', 'fa-solid fa-book-open', 'fa-solid fa-feather', 'fa-solid fa-scroll', 'fa-solid fa-brain',
    '🔖', '📖', '🌙', '✨', '🌸', '🍀',
];

/** Inner HTML for an icon choice (Font Awesome class, built-in SVG, or an emoji). */
function iconHtml(spec) {
    if (String(spec).startsWith('svg:')) return (SVG_ICONS[spec.slice(4)] ?? SVG_ICONS.heart)[1];
    if (String(spec).startsWith('fa-')) return `<i class="${esc(spec)}"></i>`;
    return `<span class="mh_emoji">${esc(spec)}</span>`;
}
/** Draws the chosen icon into every slot (settings, manager, top bar) and marks it in the picker. */
function applyIcon(scope = document) {
    const spec = settings().icon;
    const html = iconHtml(spec);
    for (const el of scope.querySelectorAll('.mh_icon_slot')) if (el.dataset.icon !== spec) { el.innerHTML = html; el.dataset.icon = spec; }
    for (const el of scope.querySelectorAll('.mh_iconpick')) el.classList.toggle('mh_on', el.dataset.icon === spec);
}
const iconLabel = spec => String(spec).startsWith('svg:') ? (SVG_ICONS[spec.slice(4)]?.[0] ?? spec) : spec;

// ---------------------------------------------------------------- helpers

const ctx = () => SillyTavern.getContext();
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clampInt = (v, lo, hi, def) => { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : def; };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const wait = ms => new Promise(r => setTimeout(r, ms));
const errText = e => [e?.message || String(e), e?.cause?.message].filter(Boolean).join(' — ');

const toast = {
    ok: m => globalThis.toastr?.success(m, 'Memory Hub'),
    info: (m, o) => globalThis.toastr?.info(m, 'Memory Hub', o),
    warn: (m, o) => globalThis.toastr?.warning(m, 'Memory Hub', o),
    err: (m, o) => globalThis.toastr?.error(m, 'Memory Hub', o),
};

function settings() {
    const ext = ctx().extensionSettings;
    ext[MODULE] ??= {};
    const s = ext[MODULE];
    // migrate 1.0.0
    if (s.sources == null) s.sources = s.source === 'profile' && s.profileId ? [s.profileId, 'main'] : ['main'];
    if (s.style == null && s.prompt != null) s.style = s.prompt.trim() === PROMPT_V1.trim() ? 'modules' : 'custom';
    if (s.prompt != null && s.prompt.trim() === PROMPT_V1.trim()) s.prompt = '';
    // migrate 1.1.0 styles to modules (1.1 raised the lengths for RPG by hand; modules now add them)
    if (s.style === 'single') { s.style = 'modules'; s.defaultModules = ['relationship']; }
    if (s.style === 'rpg') {
        s.style = 'modules'; s.defaultModules = ['ensemble', 'rpg'];
        if (s.memoryWords === 180) s.memoryWords = 120;
        if (s.overviewWords === 400) s.overviewWords = 250;
        if (s.responseLength === 1200) s.responseLength = 800;
    }
    if (s.style === 'auto') s.style = 'modules';
    // migrate 1.7.0: the plain-number badge was hard to read
    if (s.badgeStyle === 'plain') s.badgeStyle = 'badge';
    // migrate 1.5.x: the on/off switch became a mode
    if (s.mode == null && s.autoSummarize === false) s.mode = 'manual';
    delete s.autoSummarize;
    for (const [k, v] of Object.entries(DEFAULTS)) if (s[k] === undefined || (k === 'sources' && s[k] == null)) s[k] = v ?? ['main'];
    if (!Array.isArray(s.sources) || !s.sources.length) s.sources = ['main'];
    return s;
}
const saveSettings = () => ctx().saveSettingsDebounced();

/** @returns {{v:number, memories:any[], overview:string, lastEnd:number, skips?:Array<[number, number]>, baseOverview?:string, chain?:string[]}|null} */
function state() {
    const c = ctx();
    if (!c.chatId) return null;
    const meta = c.chatMetadata;
    if (!meta) return null;
    meta[MODULE] ??= { v: 1, memories: [], overview: '', lastEnd: -1 };
    const st = meta[MODULE];
    st.memories ??= [];
    st.overview ??= '';
    if (!Number.isInteger(st.lastEnd)) st.lastEnd = -1;
    return st;
}
const saveState = () => ctx().saveMetadataDebounced();

const tokenCache = new Map();
async function countTokens(text) {
    const s = String(text ?? '');
    if (!s) return 0;
    if (tokenCache.has(s)) return tokenCache.get(s);
    let n;
    try { n = await ctx().getTokenCountAsync(s); } catch { n = Math.ceil(s.length / 3); }
    if (tokenCache.size > 500) tokenCache.clear();
    tokenCache.set(s, n);
    return n;
}

const memoryBlock = m => `• ${m.title ? m.title + ': ' : ''}${String(m.text ?? '').trim()}`;
const isGroup = () => !!ctx().groupId;
const mainNames = () => {
    const c = ctx();
    const names = [c.name1, c.name2];
    if (c.groupId) {
        const g = c.groups?.find(x => x.id === c.groupId);
        for (const av of g?.members ?? []) names.push(c.characters?.find(ch => ch.avatar === av)?.name);
    }
    return names.filter(Boolean);
};

/** Newest memory: the last summarized chunk of this chat, else the last carried-over one. */
function latestOf(pool) {
    const autos = pool.filter(m => m.source === 'auto' && m.end >= 0).sort((a, b) => b.end - a.end);
    if (autos.length) return autos[0];
    return [...pool].reverse().find(m => m.source === 'carry') ?? null;
}

// ---------------------------------------------------------------- prompt modules

/** Identity of the bot the open chat belongs to (per character, or per group). */
function botKey() {
    const c = ctx();
    if (c.groupId) return `group:${c.groupId}`;
    const ch = c.characters?.[c.characterId];
    return ch ? `char:${ch.avatar}` : null;
}
function botName() {
    const c = ctx();
    if (c.groupId) return c.groups?.find(g => g.id === c.groupId)?.name ?? 'группа';
    return c.characters?.[c.characterId]?.name ?? '';
}
const lc = t => String(t ?? '').trim().toLowerCase();
/** Marks a card whose owner chose no modules at all (otherwise no module tags = the default set). */
const BASIC_TAG = 'memhub-basic';
const currentChar = () => { const c = ctx(); return c.groupId ? null : (c.characters?.[c.characterId] ?? null); };
/** Tags saved inside the card file itself. */
const cardTags = ch => [...new Set([...(Array.isArray(ch?.tags) ? ch.tags : []), ...(Array.isArray(ch?.data?.tags) ? ch.data.tags : [])].map(String))];
/** SillyTavern's tags for this bot (this install only) plus the card's own tags (travel with the card file). */
function botTagNames() {
    const c = ctx();
    const key = c.groupId ?? c.characters?.[c.characterId]?.avatar;
    const mapped = (key ? (c.tagMap?.[key] ?? []) : []).map(id => c.tags?.find(t => t.id === id)?.name);
    const seen = new Set();
    return [...mapped, ...cardTags(currentChar())].filter(t => t && !seen.has(lc(t)) && seen.add(lc(t)));
}
const moduleList = () => allModules(settings().customModules);
const isModuleTag = (t, mods = moduleList()) => lc(t) === BASIC_TAG || mods.some(m => (m.tags ?? []).some(x => lc(x) === lc(t)));

/** @returns {{ids:string[], from:'bot'|'tags'|'default', tags?:string[]}} */
function resolveModules() {
    const s = settings();
    const mods = moduleList();
    const known = new Set(mods.map(m => m.id));
    const key = botKey();
    const own = key ? s.botModules?.[key] : null;
    if (Array.isArray(own)) return { ids: own.filter(id => known.has(id)), from: 'bot' };
    const tags = botTagNames().filter(t => isModuleTag(t, mods));
    const byTag = modulesFromTags(tags, mods);
    if (byTag.length || tags.length) return { ids: byTag, from: 'tags', tags };
    const def = Array.isArray(s.defaultModules) ? s.defaultModules : (isGroup() ? ['ensemble', 'story'] : ['relationship']);
    return { ids: def.filter(id => known.has(id)), from: 'default' };
}
/**
 * Sets this bot's modules. A character gets them as tags on its card, so the
 * same modules apply on every device and app that opens the card; a group
 * (no card) keeps them in this install's settings.
 */
function setBotModules(ids) {
    const key = botKey();
    if (!key) { toast.warn('Сначала откройте чат.'); return false; }
    const want = new Set(ids);
    const list = moduleList().map(m => m.id).filter(id => want.has(id));
    const ch = currentChar();
    if (ch) {
        tagCard(ch, list);
        delete settings().botModules[key];
    } else {
        settings().botModules[key] = list;
    }
    saveSettings();
    return true;
}

/**
 * Makes the card's module tags match `ids` (null = remove them all, back to the default).
 * Updates SillyTavern's tag list right away and writes the card file in the background.
 */
function tagCard(ch, ids, { quiet = false } = {}) {
    const s = settings();
    const c = ctx();
    const mods = moduleList();
    const wanted = ids ? mods.filter(m => ids.includes(m.id)) : [];
    const current = botTagNames();
    const keep = t => (ids && !wanted.length && lc(t) === BASIC_TAG) || wanted.some(m => (m.tags ?? []).some(x => lc(x) === lc(t)));
    const remove = current.filter(t => isModuleTag(t, mods) && !keep(t));
    const add = [];
    for (const m of wanted) {
        if (current.some(t => (m.tags ?? []).some(x => lc(x) === lc(t)))) continue;
        if (m.tags?.length) { add.push(m.tags[0]); continue; }
        // one of our own modules without tags: its name becomes its tag
        const own = s.customModules.find(x => x.id === m.id);
        if (own) own.tags = [m.name];
        add.push(m.name);
    }
    if (ids && !wanted.length && !current.some(t => lc(t) === BASIC_TAG)) add.push(BASIC_TAG);
    if (!add.length && !remove.length) return;

    // SillyTavern's tags (this install)
    const gone = new Set(remove.map(lc));
    const map = c.tagMap;
    const tags = c.tags;
    if (map && tags) {
        map[ch.avatar] = (map[ch.avatar] ?? []).filter(id => !gone.has(lc(tags.find(t => t.id === id)?.name)));
        for (const name of add) {
            let tag = tags.find(t => lc(t.name) === lc(name));
            if (!tag) {
                tag = {
                    id: globalThis.crypto?.randomUUID?.() ?? uid(), name,
                    folder_type: 'NONE', filter_state: 'UNDEFINED',
                    sort_order: Math.max(0, ...tags.map(t => t.sort_order ?? 0)) + 1,
                    is_hidden_on_character_card: false, color: '', color2: '', create_date: Date.now(),
                };
                tags.push(tag);
            }
            if (!map[ch.avatar].includes(tag.id)) map[ch.avatar].push(tag.id);
        }
        saveSettings();
    }

    // the card file (goes wherever the card goes)
    const before = cardTags(ch);
    const names = [...before.filter(t => !gone.has(lc(t))), ...add.filter(t => !before.some(x => lc(x) === lc(t)))];
    writeCardTags(ch, names).catch(e => toast.err(`Не удалось сохранить тег в файл карты.: ${errText(e)}\nЭтикетка все еще находится на этой машине. Но карта не будет привязана к другому устройству.`));
    if (!quiet) {
        const parts = [add.length ? `увеличивать ${add.join(', ')}` : '', remove.length ? `удалять ${remove.join(', ')}` : ''].filter(Boolean);
        toast.info(`Тег карты ${ch.name}: ${parts.join(' · ')}`);
    }
}

async function writeCardTags(ch, names) {
    ch.tags = names;
    if (ch.data) ch.data.tags = names;
    if (ch.json_data) {
        try {
            const j = JSON.parse(ch.json_data);
            j.tags = names;
            if (j.data) j.data.tags = names;
            ch.json_data = JSON.stringify(j);
        } catch { /* keep what ST has */ }
    }
    const res = await fetch('/api/characters/merge-attributes', {
        method: 'POST',
        headers: ctx().getRequestHeaders(),
        body: JSON.stringify({ avatar: ch.avatar, tags: names, data: { tags: names } }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

/** 1.7.x kept a character's modules in this install's settings; move them onto the card. */
function migrateBotModules() {
    const s = settings();
    const ch = currentChar();
    const key = botKey();
    if (!ch || !key || !Array.isArray(s.botModules?.[key])) return;
    const ids = s.botModules[key];
    delete s.botModules[key];
    tagCard(ch, ids);
    saveSettings();
    toast.info(`Переместить выбранный модуль ${ch.name} Теперь это метка на карте. Другие машины с включенной этой картой используют тот же модуль.`);
}
const MOD_FROM_TH = { bot: 'Выбери себя', tags: 'из тега карты', default: 'По умолчанию' };
/** Tooltip text: what it remembers, which bots it suits, which tags switch it on. */
function moduleTip(m) {
    return [m.name, m.desc && `помнить: ${m.desc}`, m.fit && `подходит для: ${m.fit}`, m.tags?.length && `Теги, которые открываются сами: ${m.tags.join(', ')}`].filter(Boolean).join('\n');
}

function activeModules() {
    const ids = new Set(resolveModules().ids);
    return moduleList().filter(m => ids.has(m.id));
}
let rangeSize = null; // messages in a hand-picked range while it is being summarized
function wordBudget({ boost, size } = {}) {
    const s = settings();
    const extra = s.autoWords ? extraWords(activeModules()) : { memory: 0, overview: 0 };
    // more messages per memory need longer memories; the default chunk is the baseline
    const per = s.autoWords ? Math.max(1, (size ?? rangeSize ?? s.chunkSize) / DEFAULTS.chunkSize) : 1;
    const scale = per * (boost ?? (Number(s.quotaBoost) || 1));
    const memory = Math.round((s.memoryWords + extra.memory) * scale);
    const overview = s.overviewWords + extra.overview;
    // Thai runs 3-5 tokens a word and "thinking" models spend part of the budget
    // on reasoning; the limit only caps the answer, it costs nothing unused
    const response = Math.max(s.responseLength, Math.ceil((memory + (s.overviewEnabled ? overview : 0)) * 5 + 400));
    // models cannot count Thai words, so the length is also given as a number of bullets
    const bullets = Math.min(Math.round(10 * Math.max(1, scale)), Math.max(4, Math.round(memory / 22)));
    // longer memories need a bigger recall budget to fit the same number of them
    const recall = Math.round(s.recallBudget * memory / Math.max(1, s.memoryWords));
    return { memory, overview, response, bullets, recall, per };
}

// ---------------------------------------------------------------- model calls (with fallback chain)

let lastApi = null; // { ok:boolean, label:string, error?:string, at:number, fallback?:boolean }
/** What is running now, for the top bar: { label, done, total, range?, api?, attempt? } */
let job = null;
let queued = 0;       // summary runs waiting behind the current one
let lastJob = null;   // { ok:boolean, text:string, at:number }

function profiles() {
    try { return ctx().ConnectionManagerRequestService?.getSupportedProfiles?.() ?? []; } catch { return []; }
}
function sourceLabel(id) {
    if (id === 'main') return 'API основной';
    const p = profiles().find(x => x.id === id);
    return p ? p.name : '(profile это было удалено)';
}
function activeSources() {
    const known = new Set(profiles().map(p => p.id));
    const list = settings().sources.filter(id => id === 'main' || known.has(id));
    return list.length ? list : ['main'];
}

async function callOne(src, messages, maxTokens, timeoutMs) {
    const c = ctx();
    if (src === 'main') {
        let timer;
        const timeout = new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`Не ответил в течение ${timeoutMs / 1000} второй`)), timeoutMs); });
        try {
            return await Promise.race([c.generateRaw({ prompt: structuredClone(messages), responseLength: maxTokens }), timeout]);
        } finally { clearTimeout(timer); }
    }
    const svc = c.ConnectionManagerRequestService;
    if (!svc) throw new Error('Connection Manager Нет в наличии');
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);
    try {
        const res = await svc.sendRequest(src, structuredClone(messages), maxTokens, { stream: false, signal: ac.signal, extractData: true, includePreset: true });
        return typeof res === 'string' ? res : String(res?.content ?? '');
    } catch (e) {
        if (ac.signal.aborted) throw new Error(`Не ответил в течение ${timeoutMs / 1000} второй`);
        throw e;
    } finally { clearTimeout(timer); }
}

/**
 * Tries each API in order. An API "fails" when it throws, times out, or
 * answers without anything `accept` can use.
 */
/** Set by callModel: the returned answer was cut off (every retry was, too). */
let lastCallPartial = false;

/**
 * Tries each API in order. An API "fails" when it throws, times out, or
 * answers without anything `accept` can use. `complete` tells a finished
 * answer from one cut off by the token limit: a cut-off answer is retried
 * once on the same API with twice the limit before moving on, and if every
 * API only gives cut-off answers, the longest one is used (flagged).
 */
async function callModel(system, user, maxTokens, accept = out => !!String(out ?? '').trim(), complete = () => true) {
    const s = settings();
    const order = activeSources();
    const messages = [{ role: 'system', content: system }, { role: 'user', content: user }];
    const errors = [];
    let partial = null;
    lastCallPartial = false;
    for (let i = 0; i < order.length; i++) {
        const src = order[i];
        if (job) { job.api = sourceLabel(src); job.attempt = i + 1; job.attempts = order.length; renderTopbar(); }
        let limit = maxTokens;
        for (let round = 0; round < 2; round++) {
            try {
                const out = await callOne(src, messages, limit, s.timeoutSec * 1000);
                if (!String(out ?? '').trim()) throw new Error('Получил пустой ответ. (Может получить удар safety filter или квота исчерпана)');
                if (!accept(out)) throw new Error('Ответ не в нужном формате.');
                if (!complete(out)) {
                    if (!partial || out.length > partial.length) partial = out;
                    if (round === 0) { limit = Math.min(16000, limit * 2); console.warn(LOG, `answer cut off, retrying with ${limit} tokens`); continue; }
                    throw new Error(`Ответ был прерван на полпути, хотя он был расширен до ${limit} Уже токенизировано (Модели могут тратить жетоны на размышления.)`);
                }
                if (i > 0) toast.warn(`${errors.join(' · ')}\n→ использовать ${sourceLabel(src)} вместо`, { timeOut: 8000 });
                lastApi = { ok: true, label: sourceLabel(src), fallback: i > 0, at: Date.now() };
                return out;
            } catch (e) {
                console.warn(LOG, `API ${sourceLabel(src)} failed`, e);
                errors.push(`${sourceLabel(src)}: ${errText(e)}`);
                break;
            }
        }
    }
    if (partial) {
        lastCallPartial = true;
        lastApi = { ok: true, label: `${sourceLabel(order[0])} (Неполный ответ)`, at: Date.now() };
        toast.warn(`каждый API Если вы не закончили отвечать, используйте тот ответ, который дали первым. Эта память будет иметь ⚠ — Попробуйте добавить больше. Response length затем нажмите 🔄 Новое резюме\n${errors.join(' · ')}`, { timeOut: 15000 });
        return partial;
    }
    lastApi = { ok: false, label: sourceLabel(order[0]), error: errors.join(' · '), at: Date.now() };
    const err = new Error(errors.join(' · '));
    const kinds = errors.map(blockKind);
    err.blocked = kinds.includes('prohibited') ? 'prohibited' : kinds.includes('filter') ? 'filter' : null;
    throw err;
}

/** Why a summary of `range` failed, in words a user can act on. */
function failText(e, range) {
    if (e?.blocked === 'prohibited') return `Gemini блокировать содержимое диапазона ${range} (PROHIBITED_CONTENT) Этот фильтр невозможно отключить, даже если он установлен. safety является OFF — увеличивать API Резерв, которого нет Gemini (такой как DeepSeek) или отредактируйте сообщение за это время\n${errText(e)}`;
    if (e?.blocked) return `диапазон ${range} Может подвергаться контентным фильтрам поставщика услуг. — Попробуйте добавить больше. API Резервное копирование от другого поставщика услуг или редактирование сообщения в течение этого времени.\n${errText(e)}`;
    return errText(e);
}

// ---------------------------------------------------------------- summarizing

let busy = null;          // Promise of the running summarization
let cancelRequested = false;
let lastInjection = null; // what the last generation received (for the preview)
let autoPausedUntil = 0;  // chat length; auto-summary waits after a failure
let blockedChunk = null;  // { chatId, start, end }: the chunk a content filter keeps stopping

function transcript(start, end) {
    const { chat } = ctx();
    const max = settings().maxMessageChars;
    const lines = [];
    for (let i = start; i <= end && i < chat.length; i++) {
        const m = chat[i];
        if (!m || m.is_system) continue;
        const text = cleanText(m.mes, max);
        if (!text) continue;
        lines.push(`${m.name || (m.is_user ? '{{user}}' : '{{char}}')}: ${text}`);
    }
    return lines.join('\n\n');
}

function fill(template, withOverview) {
    const w = wordBudget();
    const p = String(template)
        .replaceAll('{{overview_rule}}', withOverview ? buildOverviewRule(activeModules()) : '')
        .replaceAll('{{overview_format}}', withOverview ? OVERVIEW_FORMAT : '')
        .replaceAll('{{overview_words}}', String(w.overview))
        .replaceAll('{{memory_words}}', String(w.memory))
        .replaceAll('{{memory_bullets}}', String(w.bullets));
    return ctx().substituteParams(p);
}

function summaryTemplate() {
    const s = settings();
    if (s.style === 'custom' && String(s.prompt ?? '').trim()) return s.prompt;
    return buildPrompt(activeModules(), { group: isGroup() });
}

/** Summarizes chat[start..end] into one memory (and refreshes the overview). */
async function summarizeRange(start, end, { replaceId = null, updateOverview = true } = {}) {
    const s = settings();
    const st = state();
    if (!st) throw new Error('Чат еще не открывал.');
    const chatId = ctx().chatId;

    const body = transcript(start, end);
    if (!body.trim()) return null;

    const withOverview = s.overviewEnabled && updateOverview;
    const prev = latestOf(st.memories.filter(m => (m.source !== 'auto' || m.end < start) && String(m.text ?? '').trim()));
    const parts = [];
    if (withOverview) parts.push(`PREVIOUS OVERVIEW:\n${st.overview.trim() || '(none yet — this is the start of the story)'}`);
    if (prev) parts.push(`PREVIOUS MEMORY (for continuity, do not repeat it):\n${memoryBlock(prev)}`);
    parts.push(`NEW MESSAGES (#${start}–#${end}):\n${body}`);

    const raw = await callModel(fill(summaryTemplate(), withOverview), ctx().substituteParams(parts.join("\n\n")), wordBudget().response,
        out => !!parseSummary(out).text, out => isComplete(out, { overview: withOverview }));
    // flag the memory only when the memory part itself was cut (a missing overview just keeps the old one)
    const partial = lastCallPartial && !isComplete(raw);
    if (ctx().chatId !== chatId) throw new Error('Изменить чат во время подведения итогов. Результат аннулируется.');

    const parsed = parseSummary(raw);
    const keys = cleanKeys(parsed.keys, mainNames());
    const cur = state();
    let mem;
    if (replaceId) {
        mem = cur.memories.find(m => m.id === replaceId);
        if (mem) Object.assign(mem, { title: parsed.title || mem.title, keys: keys.length ? keys : mem.keys, text: parsed.text, ts: Date.now(), truncated: partial || undefined, blocked: undefined });
    }
    if (!mem) {
        mem = { id: uid(), start, end, title: parsed.title || `#${start}–#${end}`, keys, text: parsed.text, pinned: false, source: 'auto', ts: Date.now(), ...(partial ? { truncated: true } : {}) };
        cur.memories.push(mem);
        cur.memories.sort((a, b) => (a.start - b.start) || (a.ts - b.ts));
        cur.lastEnd = Math.max(cur.lastEnd, end);
    }
    if (withOverview && parsed.overview) cur.overview = parsed.overview;
    // lets a branch restore the story-so-far of its time; a chunk filled in
    // behind newer ones takes the one of the memory before it
    if (!replaceId) mem.overviewAfter = updateOverview ? cur.overview
        : (latestOf(cur.memories.filter(m => m.source === 'auto' && m.end < start))?.overviewAfter ?? cur.baseOverview ?? '');
    saveState();
    return mem;
}

/**
 * Summarizes chunk after chunk until the chat is caught up.
 * @param {{force?:boolean, quiet?:boolean, keepRaw?:number}} opt force = also take a last partial chunk
 * @returns {Promise<{made:number, failed:boolean}>}
 */
/** How many chunks a run would take right now. */
function plannedChunks(force, keepRaw) {
    const st = state();
    if (!st) return 0;
    const s = settings();
    let n = 0;
    let end = st.lastEnd;
    for (let c = nextChunk(end, ctx().chat.length, s.chunkSize, keepRaw ?? s.keepRaw, force); c && n < 10000; c = nextChunk(end, ctx().chat.length, s.chunkSize, keepRaw ?? s.keepRaw, force)) { n++; end = c.end; }
    return n;
}

function runSummaries({ force = false, quiet = false, keepRaw = null } = {}) {
    if (busy) {
        queued++; renderTopbar();
        return busy.then(() => { queued = Math.max(0, queued - 1); return runSummaries({ force, quiet, keepRaw }); });
    }
    cancelRequested = false;
    busy = (async () => {
        let made = 0;
        let failed = false;
        let progress = null;
        let chunk = null;
        job = { label: 'Краткое изложение сообщения', done: 0, total: plannedChunks(force, keepRaw) };
        renderTopbar();
        try {
            for (;;) {
                if (cancelRequested) break;
                const st = state();
                if (!st) break;
                const s = settings();
                chunk = nextChunk(st.lastEnd, ctx().chat.length, s.chunkSize, keepRaw ?? s.keepRaw, force);
                if (!chunk) break;
                // the top bar panel already shows progress; no toast on top of it
                if ((!quiet || made > 0) && !barPanel?.classList.contains('mh_open')) {
                    if (progress) globalThis.toastr?.clear(progress);
                    progress = toast.info(`Итоговое сообщение #${chunk.start}–#${chunk.end}…`, { timeOut: 0, extendedTimeOut: 0 });
                }
                job.range = `#${chunk.start}–#${chunk.end}`;
                renderTopbar();
                const mem = await summarizeRange(chunk.start, chunk.end);
                job.done++;
                if (!mem) { state().lastEnd = chunk.end; saveState(); continue; }
                made++;
                refreshUi();
            }
        } catch (e) {
            failed = true;
            console.error(LOG, e);
            autoPausedUntil = ctx().chat.length + 4;
            const range = job?.range ?? '';
            lastJob = { ok: false, text: `подвести итог ${range} неудачный: ${failText(e, range)}`, at: Date.now() };
            if (e?.blocked && chunk) {
                blockedChunk = { chatId: ctx().chatId, start: chunk.start, end: chunk.end };
                toast.err(`В целом неудачно, все перепробовал. API уже:\n${failText(e, range)}\nНажмите здесь, чтобы пропустить этот этап. (Создайте пустую память, чтобы писать самостоятельно.)`,
                    { timeOut: 20000, extendedTimeOut: 10000, onclick: () => skipBlocked() });
            } else {
                toast.err(`В целом неудачно, все перепробовал. API уже:\n${errText(e)}`, { timeOut: 15000 });
            }
        } finally {
            if (progress) globalThis.toastr?.clear(progress);
            busy = null;
            job = null;
            if (made && !failed) lastJob = { ok: true, text: `Создавайте новые воспоминания ${made} кусок`, at: Date.now() };
            refreshUi();
        }
        if (made && (settings().notify || !quiet)) toast.ok(`Создавайте новые воспоминания ${made} кусок`);
        if (!made && !failed && !quiet && !cancelRequested) toast.info('Окончательного сообщения пока нет. (Самое последнее сообщение будет сохранено в полном объеме, как установлено.)');
        return { made, failed };
    })();
    return busy;
}

/** The chunk a content filter stopped, if it is still the next one of this chat. */
function currentBlocked() {
    const st = state();
    const b = blockedChunk;
    if (!b || !st || b.chatId !== ctx().chatId || st.lastEnd + 1 !== b.start) return null;
    return b;
}

/**
 * Gives up on a chunk the filters keep stopping: an empty memory takes its
 * place so the chunks after it can be summarized. The memory is left for the
 * user to write (or 🔄 to retry later with another API).
 */
async function skipBlocked() {
    const b = currentBlocked();
    if (!b) return toast.info('Нет менструаций, которые застряли, потому что они уже заблокированы.');
    if (busy) return toast.info('в настоящее время работаю');
    const c = ctx();
    const ok = await c.callGenericPopup(`
      <h3>Пропустить диапазон #${b.start}–#${b.end}?</h3>
      <p>Вместо этого в это время будет создана пустая память. Затем подведите итоги следующего раздела.</p>
      <p>Сообщения в течение этого времени больше не будут отправляться ботам. (Как и период, который завершился) Пока я сам не напишу это воспоминание. Бот не узнает, что происходит в эти дни.
      открыть "управление памятью" чтобы написать это самостоятельно или нажать 🔄 в этой памяти, чтобы попытаться позже сделать новые выводы (Например, после добавления API бронировать)</p>`,
    c.POPUP_TYPE.CONFIRM, '', { okButton: 'Пропустить этот период', cancelButton: 'Еще нет' });
    if (!ok || busy || currentBlocked() !== b) return;
    const st = state();
    st.memories.push({ id: uid(), start: b.start, end: b.end, title: `#${b.start}–#${b.end} (Заблокировано)`, keys: [], text: '', pinned: false, source: 'auto', blocked: true, ts: Date.now(), overviewAfter: st.overview });
    st.memories.sort((x, y) => (x.start - y.start) || (x.ts - y.ts));
    st.lastEnd = Math.max(st.lastEnd, b.end);
    saveState();
    blockedChunk = null;
    autoPausedUntil = 0;
    lastJob = { ok: true, text: `крест #${b.start}–#${b.end} уже (Пустая память, ожидающая записи)`, at: Date.now() };
    toast.info(`крест #${b.start}–#${b.end} Затем нажмите здесь, чтобы открыть управление памятью и написать вручную.`, { timeOut: 10000, onclick: () => openManager() });
    refreshUi();
    if (settings().mode === 'auto') onMessageReceived(null, 'normal');
}

function onMessageReceived(_id, type) {
    const s = settings();
    if (!s.enabled || type === 'quiet') return;
    const st = state();
    if (!st) return;
    const len = ctx().chat.length;
    if (s.mode === 'manual') return warnBacklog(st, len);
    if (len < autoPausedUntil) return;
    if (!nextChunk(st.lastEnd, len, s.chunkSize, s.keepRaw)) return;
    if (s.mode === 'semi') return askToSummarize(st, len);
    runSummaries({ quiet: true });
}

const MODE_TH = { auto: 'автоматический', semi: 'с подтверждением', manual: 'ручной' };
const pendingOf = (st, len) => Math.max(0, len - 1 - st.lastEnd);
/** Unsummarized messages worth a warning when nothing summarizes them on its own. */
const backlogAt = s => Math.max(40, s.chunkSize * 2);
function hasBacklog(s, st, len) {
    return s.enabled && s.mode !== 'auto' && pendingOf(st, len) >= backlogAt(s);
}

let backlogWarned = 0; // pending count at the last manual-mode warning
function warnBacklog(st, len) {
    const s = settings();
    const pending = pendingOf(st, len);
    if (pending < backlogWarned) backlogWarned = 0;
    if (!hasBacklog(s, st, len) || (backlogWarned && pending < backlogWarned + s.chunkSize)) return;
    backlogWarned = pending;
    toast.warn(`Не суммировано ${pending} сообщений. Они отправляются модели целиком на каждом ходе и расходуют токены. Если контекст переполнится, самые старые сообщения выпадут из запроса.\nНажмите здесь, чтобы суммировать их.`,
        { timeOut: 15000, onclick: () => summarizeNow() });
}

let asking = false;
/** Semi-auto: the chunk is due, ask before summarizing. */
async function askToSummarize(st, len) {
    if (asking || busy || len < (st.remindAt ?? 0)) return;
    asking = true;
    try {
        const s = settings();
        const c = ctx();
        const chatId = c.chatId;
        const box = document.createElement('div');
        box.className = 'mh_carry';
        box.innerHTML = `
          <h3>Пора создать сводку</h3>
          <p>Ожидают суммирования <b>${pendingOf(st, len)}</b> сообщений. Сейчас будет создано ${plannedChunks(false, null)} блоков памяти (по ${s.chunkSize} сообщений). Начать?</p>
          <label class="mh_row"><span>Если отложить, спросить снова через N сообщений</span><input type="number" class="text_pole mh_snooze_in" min="1" max="200"></label>
          <small>До суммирования сообщения передаются модели целиком.</small>`;
        const input = box.querySelector('.mh_snooze_in');
        input.value = s.semiSnooze;
        const ok = await c.callGenericPopup(box, c.POPUP_TYPE.CONFIRM, '', { okButton: 'Суммировать', cancelButton: 'Позже' });
        if (ctx().chatId !== chatId) return;
        if (ok) {
            delete st.remindAt; saveState();
            await runSummaries({});
        } else {
            s.semiSnooze = clampInt(input.value, 1, 200, DEFAULTS.semiSnooze); saveSettings();
            st.remindAt = ctx().chat.length + s.semiSnooze; saveState();
            toast.info(`Спрошу снова через ${s.semiSnooze} сообщений. Можно суммировать вручную в любой момент.`);
        }
    } finally {
        asking = false;
        refreshUi();
    }
}

/** Switching to manual: explain what piling up messages costs, offer a bigger quota. */
async function confirmManual() {
    const s = settings();
    const c = ctx();
    const opts = [1, 1.5, 2, 3].map(b => {
        const w = wordBudget({ boost: b });
        return `<label class="checkbox_label"><input type="radio" name="mh_boost_pick" value="${b}"${b === (Number(s.quotaBoost) || 1) ? ' checked' : ''}>
          ${b === 1 ? 'Без изменений' : `Увеличить ×${b}`} — до ${w.memory} слов на блок памяти · бюджет подбора ${w.recall} токенов</label>`;
    }).join('');
    const box = document.createElement('div');
    box.className = 'mh_carry';
    box.innerHTML = `
      <h3>Ручное суммирование</h3>
      <p>Memory Hub не будет суммировать сообщения автоматически. Когда понадобится, нажмите «Суммировать сейчас». При долгом ожидании:</p>
      <ul>
        <li>Необработанные сообщения отправляются модели целиком и расходуют больше токенов.</li>
        <li>Если история превысит контекст модели, старые сообщения выпадут из запроса до суммирования.</li>
        <li>Сотни сообщений потребуют нескольких вызовов API подряд (по ${s.chunkSize} сообщений на блок). Это может занять время и исчерпать квоту бесплатного API.</li>
        <li>В больших блоках памяти могут потеряться мелкие детали.</li>
      </ul>
      <p><b>Увеличить объём памяти?</b> Блоки станут подробнее, но каждый запрос модели будет длиннее.</p>
      ${opts}
      <small>После ${backlogAt(s)} несуммированных сообщений появится предупреждение. Множитель можно изменить позднее.</small>`;
    const ok = await c.callGenericPopup(box, c.POPUP_TYPE.CONFIRM, '', { okButton: 'Включить ручной режим', cancelButton: 'Отмена' });
    if (!ok) return false;
    const pick = Number(box.querySelector('input[name=mh_boost_pick]:checked')?.value);
    if (pick) s.quotaBoost = pick;
    return true;
}

/**
 * Keeps memories consistent with the chat. After a branch (or deleting
 * messages at the end), memories covering messages that no longer exist are
 * removed, the story-so-far goes back to what it was at that point, and the
 * cut part will be summarized again from the branch's own messages.
 */
function reconcile({ announce = false } = {}) {
    const st = state();
    if (!st) return;
    const len = ctx().chat.length;
    let changed = false;
    const before = st.memories.length;
    st.memories = st.memories.filter(m => m.source !== 'auto' || m.end <= len - 1);
    const dropped = before - st.memories.length;
    if (dropped) {
        const last = latestOf(st.memories.filter(m => m.source === 'auto'));
        st.lastEnd = last ? last.end : -1;
        st.overview = last ? (last.overviewAfter ?? st.overview) : (st.baseOverview ?? '');
        changed = true;
        if (announce) toast.info(`Этот разговор был короче, чем моя память. (например, ветвление) — Удалите память после этого момента. ${dropped} Лампи и вернёмся к этому моменту.`, { timeOut: 8000 });
    }
    if (st.lastEnd > len - 1) { st.lastEnd = len - 1; changed = true; }
    if (st.skips?.length) {
        const kept = st.skips.filter(([, b]) => b <= len - 1);
        if (kept.length !== st.skips.length) { st.skips = kept; changed = true; }
    }
    // The newest memory was deleted: step back, so those messages are sent in
    // full again and the next summary picks them up.
    const tail = gapsOf(st).at(-1);
    if (tail && !coveredRanges(st).some(([a, b]) => b >= tail[0] && a <= st.lastEnd)) {
        const was = st.lastEnd;
        st.lastEnd = tail[0] - 1;
        const prev = latestOf(st.memories.filter(m => m.source === 'auto' && m.end >= 0 && m.end <= st.lastEnd));
        st.overview = prev ? (prev.overviewAfter ?? st.overview) : (st.baseOverview ?? '');
        changed = true;
        if (announce) toast.info(`Памяти сообщения нет. #${tail[0]}–#${was} Затем сделайте шаг назад, чтобы подвести итоги. #${st.lastEnd} и соответственно перемотать синопсис. Этот диапазон сообщений будет отправлен полностью до тех пор, пока не будет повторно суммирован.`, { timeOut: 8000 });
    }
    if (changed) { saveState(); refreshUi(); }
}

/** Message ranges a memory of this chat (or a deliberate skip) stands in for. */
function coveredRanges(st) {
    return [
        ...st.memories.filter(m => m.source === 'auto' && m.end >= 0).map(m => [m.start, m.end]),
        ...(st.skips ?? []),
    ];
}

/** Summarized-over messages that no memory covers any more (a memory was deleted). */
function gapsOf(st) {
    const chat = ctx().chat ?? [];
    const empty = i => { const m = chat[i]; return !m || m.is_system || !cleanText(m.mes); };
    return findGaps(coveredRanges(st), Math.min(st.lastEnd, chat.length - 1), empty);
}
const gapLabel = ([a, b]) => a === b ? `#${a}` : `#${a}–#${b}`;

// ---------------------------------------------------------------- per-generation: trim + recall

function clearPrompts() {
    const c = ctx();
    c.setExtensionPrompt(KEY_OVERVIEW, '', 0, 0);
    c.setExtensionPrompt(KEY_RECALL, '', 0, 0);
}

function place(key, value, where, depth) {
    // 0 = IN_PROMPT (after the story string), 1 = IN_CHAT at depth
    if (where === 'chat') ctx().setExtensionPrompt(key, value, 1, depth, false, 0);
    else ctx().setExtensionPrompt(key, value, 0, 0, false, 0);
}

async function selectRecall(st, queryText) {
    const s = settings();
    const pool = st.memories.filter(m => String(m.text ?? '').trim());
    const why = new Map();
    if (!pool.length) return { picked: [], tokens: 0, why };

    const latest = latestOf(pool);
    const chosen = new Map();
    for (const m of pool) if (m.pinned) { chosen.set(m.id, m); why.set(m.id, ['📌']); }
    if (s.includeLatest && latest && !chosen.has(latest.id)) { chosen.set(latest.id, latest); why.set(latest.id, ['🕘 последний']); }

    // Words shared by every memory (main characters' names) only add a little
    // score each; the floor keeps small talk from pulling in random memories.
    const all = rankMemories(pool, queryText);
    const floor = Math.max(1, (all[0]?.score ?? 0) * 0.35);
    let extra = 0;
    for (const r of all) {
        if (extra >= s.topK || r.score < floor) break;
        if (chosen.has(r.memory.id)) continue;
        chosen.set(r.memory.id, r.memory);
        why.set(r.memory.id, r.hits.slice(0, 6));
        extra++;
    }

    // budget: pinned first, then the latest, then by relevance;
    // pinned and the latest always go in, even over the budget
    const budget = wordBudget().recall;
    const picked = [];
    let tokens = 0;
    for (const m of chosen.values()) {
        const t = await countTokens(memoryBlock(m));
        const must = m.pinned || (s.includeLatest && m.id === latest?.id);
        if (!must && tokens + t > budget) continue;
        picked.push(m);
        tokens += t;
    }
    const order = new Map(st.memories.map((m, i) => [m.id, i]));
    picked.sort((a, b) => order.get(a.id) - order.get(b.id));
    return { picked, tokens, why };
}

let savedCache = { chatId: null, key: '', tokens: 0 };
/** Rough size of the messages we stopped sending (counted once per summary). */
async function savedTokens(lastEnd, gaps = []) {
    const c = ctx();
    const key = `${lastEnd}|${gaps.join(';')}`;
    if (savedCache.chatId === c.chatId && savedCache.key === key) return savedCache.tokens;
    const inGap = i => gaps.some(([a, b]) => i >= a && i <= b);
    const text = c.chat.slice(0, lastEnd + 1).filter((m, i) => !m.is_system && !inGap(i)).map(m => m.mes).join('\n');
    let tokens;
    try { tokens = await c.getTokenCountAsync(text); } catch { tokens = Math.ceil(text.length / 3); }
    savedCache = { chatId: c.chatId, key, tokens };
    return tokens;
}

async function intercept(chat, _contextSize, _abort, type) {
    const s = settings();
    clearPrompts();
    if (!s.enabled) { lastInjection = null; return; }

    // A chunk may be summarizing right now: let it land first, so this prompt
    // already benefits from it.
    if (busy) await Promise.race([busy, wait(s.timeoutSec * 1000 * Math.max(1, activeSources().length))]);

    const st = state();
    if (!st) return;
    reconcile();

    const full = ctx().chat;

    // 1. drop messages already covered by memories (prompt only; the chat is untouched)
    let trimmed = 0;
    const gaps = gapsOf(st);
    if (s.trimSummarized && st.lastEnd >= 0 && st.memories.some(m => m.source === 'auto')) {
        // positions in the prompt chat (system messages are not in it); messages
        // whose memory was deleted stay, so nothing is lost until it is redone
        const inGap = i => gaps.some(([a, b]) => i >= a && i <= b);
        const drop = [];
        for (let i = 0, p = 0; i <= st.lastEnd && i < full.length; i++) {
            if (full[i].is_system) continue;
            if (!inGap(i)) drop.push(p);
            p++;
        }
        // always leave the newest keepRaw messages, even if messages were deleted
        // in the middle and the summarized range no longer lines up
        const cap = Math.max(0, chat.length - Math.max(2, s.keepRaw));
        for (let k = drop.length - 1; k >= 0; k--) if (drop[k] < cap) { chat.splice(drop[k], 1); trimmed++; }
    }

    // 2. overview
    let overviewText = '';
    if (s.overviewEnabled && st.overview.trim()) {
        overviewText = String(s.overviewTemplate || '{{overview}}').replaceAll('{{overview}}', st.overview.trim());
        place(KEY_OVERVIEW, overviewText, s.overviewPosition, s.overviewDepth);
    }

    // 3. recall
    const recent = full.filter(m => !m.is_system).slice(-Math.max(1, s.queryDepth));
    const query = recent.map(m => cleanText(m.mes, 4000)).join('\n');
    const { picked, tokens, why } = await selectRecall(st, query);
    let recallText = '';
    if (picked.length) {
        recallText = String(s.recallTemplate || '{{memories}}').replaceAll('{{memories}}', picked.map(memoryBlock).join('\n'));
        place(KEY_RECALL, recallText, s.recallPosition, s.recallDepth);
    }

    lastInjection = {
        at: Date.now(),
        type,
        trimmed,
        trimmedTokens: trimmed ? await savedTokens(st.lastEnd, gaps) : 0,
        overviewText,
        overviewTokens: await countTokens(overviewText),
        recallText,
        recallTokens: tokens,
        picked: picked.map(m => ({ id: m.id, title: m.title, why: why.get(m.id) ?? [] })),
    };
    refreshUi();
}
globalThis.memoryHub_intercept = intercept;

// ---------------------------------------------------------------- continue in a new chat

async function continueInNewChat() {
    const c = ctx();
    const st = state();
    if (!st) return toast.warn('Сначала откройте чат.');
    const s = settings();

    const box = document.createElement('div');
    box.className = 'mh_carry';
    box.innerHTML = `
      <h3>Начните новый чат на ту же тему.</h3>
      <p>Создайте новый чат с этим персонажем. Неся все воспоминания (${st.memories.length} кусок) и синопсис тоже
      затем используйте <b>Последнее сообщение бота</b> В этом чате это первое сообщение нового чата.</p>
      <label class="checkbox_label"><input type="checkbox" class="mh_carry_rest"> Обобщите все сообщения, которые еще не были обобщены в первую очередь. (Рекомендуется в противном случае сообщение ${Math.max(0, c.chat.length - 1 - st.lastEnd)} Последнее сообщение не запомнится.)</label>
      <small>Исходный чат не редактировался. Откройте обратно в нормальное состояние.</small>`;
    const restBox = box.querySelector('.mh_carry_rest');
    restBox.checked = !!s.carrySummarizeRest;
    const ok = await c.callGenericPopup(box, c.POPUP_TYPE.CONFIRM, '', { okButton: 'Начать новый чат', cancelButton: 'отмена' });
    if (!ok) return;
    s.carrySummarizeRest = restBox.checked; saveSettings();

    if (restBox.checked) {
        const res = await runSummaries({ force: true, keepRaw: 0 });
        if (res?.failed) {
            const go = await c.callGenericPopup('Не удалось суммировать остальные сообщения. Вы все равно начнете снова общаться?? (Сообщения, которые не были завершены, не будут переданы.)', c.POPUP_TYPE.CONFIRM);
            if (!go) return;
        }
    }

    const oldId = c.getCurrentChatId();
    const old = structuredClone(state());
    const lastBot = [...c.chat].reverse().find(m => !m.is_user && !m.is_system && String(m.mes ?? '').trim());

    await c.executeSlashCommandsWithOptions('/newchat');
    for (let i = 0; i < 50 && ctx().getCurrentChatId() === oldId; i++) await wait(200);
    if (ctx().getCurrentChatId() === oldId) return toast.err('Не удалось создать новый чат.');
    await wait(600); // let the greeting land

    const n = ctx();
    n.chatMetadata[MODULE] = {
        v: 1,
        overview: old.overview,
        baseOverview: old.overview,
        lastEnd: -1,
        chain: [...(old.chain ?? []), oldId],
        memories: old.memories.map(m => {
            const { overviewAfter: _drop, ...rest } = m;
            return {
                ...rest,
                source: m.source === 'auto' ? 'carry' : m.source,
                origin: m.origin ?? (m.end >= 0 ? { chat: oldId, start: m.start, end: m.end } : undefined),
                start: -1,
                end: -1,
            };
        }),
    };

    if (lastBot) {
        const base = n.chat[0] && !n.chat[0].is_user ? n.chat[0] : { is_user: false, is_system: false };
        const msg = {
            ...base,
            name: lastBot.name,
            is_user: false,
            is_system: false,
            mes: lastBot.mes,
            swipes: [lastBot.mes],
            swipe_id: 0,
            send_date: n.humanizedDateTime?.() ?? base.send_date,
            extra: {},
        };
        delete msg.swipe_info;
        if (lastBot.original_avatar) msg.original_avatar = lastBot.original_avatar;
        if (lastBot.force_avatar) msg.force_avatar = lastBot.force_avatar;
        n.chat.splice(0, n.chat.length, msg);
    }
    await n.saveChat();
    await n.reloadCurrentChat();
    toast.ok(`Начал новый чат. Принеси свою память. ${old.memories.length} кусок`);
}

// ---------------------------------------------------------------- import + optimize

async function listOtherChats() {
    const c = ctx();
    if (c.groupId) {
        const g = c.groups?.find(x => x.id === c.groupId);
        return (g?.chats ?? []).filter(id => id !== c.getCurrentChatId()).map(id => ({ id, label: id }));
    }
    const ch = c.characters?.[c.characterId];
    if (!ch) return [];
    const res = await fetch('/api/characters/chats', { method: 'POST', headers: c.getRequestHeaders(), body: JSON.stringify({ avatar_url: ch.avatar, simple: true }) });
    if (!res.ok) return [];
    const data = await res.json();
    if (!Array.isArray(data)) return [];
    return data.map(x => String(x.file_id ?? x.file_name ?? '').replace(/\.jsonl$/, ''))
        .filter(id => id && id !== c.getCurrentChatId())
        .sort().reverse()
        .map(id => ({ id, label: id }));
}

async function readChatState(id) {
    const c = ctx();
    let res;
    if (c.groupId) {
        res = await fetch('/api/chats/group/get', { method: 'POST', headers: c.getRequestHeaders(), body: JSON.stringify({ id }) });
    } else {
        const ch = c.characters?.[c.characterId];
        res = await fetch('/api/chats/get', { method: 'POST', headers: c.getRequestHeaders(), body: JSON.stringify({ ch_name: ch.name, file_name: id, avatar_url: ch.avatar }) });
    }
    if (!res.ok) throw new Error(`Не могу загрузить чат (${res.status})`);
    const data = await res.json();
    const head = Array.isArray(data) ? data[0] : null;
    return head?.chat_metadata?.[MODULE] ?? null;
}

async function importFromChat(id) {
    const other = await readChatState(id);
    if (!other?.memories?.length && !other?.overview) return toast.warn('Чат не запоминает Memory Hub');
    mergeForeign(other, id);
}

/** Adds another chat's (or an export file's) memories before this chat's own ones. */
function mergeForeign(other, id) {
    const st = state();
    const seen = new Set(st.memories.map(m => m.text));
    let n = 0;
    const incoming = (other.memories ?? []).filter(m => m?.text && !seen.has(m.text)).map(m => {
        const { overviewAfter: _drop, stats: _stats, sourceMessages: _src, ...rest } = m;
        n++;
        return { ...rest, id: uid(), source: m.source === 'auto' ? 'carry' : m.source, origin: m.origin ?? (m.end >= 0 ? { chat: id, start: m.start, end: m.end } : undefined), start: -1, end: -1 };
    });
    // carried memories come before this chat's own ones
    const firstOwn = st.memories.findIndex(m => m.source === 'auto');
    st.memories.splice(firstOwn < 0 ? st.memories.length : firstOwn, 0, ...incoming);
    if (!st.overview.trim() && other.overview) { st.overview = other.overview; st.baseOverview = other.overview; }
    st.chain = [...new Set([...(other.chain ?? []), id, ...(st.chain ?? [])])];
    saveState();
    toast.ok(`импортировать ${n} комок из ${id}`);
    refreshUi();
}

async function importFromBook(name, skipOff) {
    const c = ctx();
    const data = await c.loadWorldInfo(name);
    const entries = Object.values(data?.entries ?? {}).filter(x => String(x.content ?? '').trim() && !(skipOff && x.disable));
    const st = state();
    const seen = new Set(st.memories.map(m => m.text));
    const names = mainNames();
    let n = 0;
    const incoming = [];
    for (const x of entries.sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || (a.uid - b.uid))) {
        const text = cleanText(x.content);
        if (!text || seen.has(text)) continue;
        seen.add(text);
        const title = String(x.comment || (x.key ?? []).join(', ') || `#${x.uid}`).replace(/\s+/g, ' ').trim().slice(0, 120);
        incoming.push({ id: uid(), start: -1, end: -1, title, keys: cleanKeys((x.key ?? []).map(String), names), text, pinned: !!x.constant, source: 'import', ts: Date.now() + n });
        n++;
    }
    const firstOwn = st.memories.findIndex(m => m.source === 'auto');
    st.memories.splice(firstOwn < 0 ? st.memories.length : firstOwn, 0, ...incoming);
    saveState();
    refreshUi();
    return { n, skipped: entries.length - n };
}

/** Rewrites long imported memories into the compact format, a few per call. */
async function optimizeImported({ onlyLong = true } = {}) {
    const s = settings();
    const st = state();
    if (!st) return;
    const limit = wordBudget().memory * 3; // tokens; Thai runs ~2-3 tokens per word
    const targets = [];
    for (const m of st.memories.filter(x => x.source === 'import' && !x.optimized)) {
        if (!onlyLong || await countTokens(m.text) > limit) targets.push(m);
        else m.optimized = true;
    }
    if (!targets.length) { saveState(); return toast.info('Никакая импортированная память не является слишком длинной.'); }

    const batches = [];
    let cur = [];
    let size = 0;
    for (const m of targets) {
        const t = await countTokens(m.text);
        if (cur.length && (cur.length >= 6 || size + t > 5000)) { batches.push(cur); cur = []; size = 0; }
        cur.push(m); size += t;
    }
    if (cur.length) batches.push(cur);

    const system = fill(PROMPT_OPTIMIZE, false);
    let done = 0;
    let progress = null;
    cancelRequested = false;
    job = { label: 'Организовать импорт', done: 0, total: batches.length };
    busy = (async () => {
        try {
            for (const [bi, batch] of batches.entries()) {
                if (cancelRequested) break;
                job.done = bi; job.range = `набор ${bi + 1}`; renderTopbar();
                if (progress) globalThis.toastr?.clear(progress);
                progress = toast.info(`Организация импортированных наборов памяти ${bi + 1}/${batches.length}…`, { timeOut: 0, extendedTimeOut: 0 });
                const user = batch.map((m, i) => `MEMORY id="${i}":\ntitle: ${m.title}\nkeys: ${(m.keys ?? []).join(', ')}\n${cleanText(m.text, 12000)}`).join('\n\n');
                const raw = await callModel(system, ctx().substituteParams(user), Math.min(4000, 350 * batch.length + 200), out => parseMany(out).size > 0, out => parseMany(out).size >= batch.length);
                const got = parseMany(raw);
                batch.forEach((m, i) => {
                    const r = got.get(String(i));
                    if (!r) return;
                    m.title = r.title || m.title;
                    m.keys = cleanKeys(r.keys.length ? r.keys : m.keys, mainNames());
                    m.text = r.text;
                    m.optimized = true;
                    done++;
                });
                saveState();
            }
        } catch (e) {
            toast.err(`Не удалось организовать: ${errText(e)}`, { timeOut: 15000 });
            lastJob = { ok: false, text: `Не удалось организовать: ${errText(e)}`, at: Date.now() };
        } finally {
            if (progress) globalThis.toastr?.clear(progress);
            busy = null;
            job = null;
            renderTopbar();
        }
    })();
    await busy;
    refreshUi();
    if (done) toast.ok(`Уменьшите импортированную память. ${done}/${targets.length} кусок`);
    if (done && !state()?.overview.trim()) await rebuildOverview();
}

/** Writes the story-so-far from all memories, folding a batch at a time. */
async function rebuildOverview() {
    const s = settings();
    const st = state();
    if (!st?.memories.length) return toast.info('Все еще нет памяти');
    const batches = [];
    let cur = [];
    let size = 0;
    for (const m of st.memories) {
        const t = await countTokens(memoryBlock(m));
        if (cur.length && size + t > 6000) { batches.push(cur); cur = []; size = 0; }
        cur.push(m); size += t;
    }
    if (cur.length) batches.push(cur);
    let overview = '';
    let progress = null;
    job = { label: 'Создать новый синопсис', done: 0, total: batches.length };
    busy = (async () => {
        try {
            for (const [bi, batch] of batches.entries()) {
                job.done = bi; job.range = `набор ${bi + 1}`; renderTopbar();
                if (progress) globalThis.toastr?.clear(progress);
                progress = toast.info(`Создать новый синопсис ${bi + 1}/${batches.length}…`, { timeOut: 0, extendedTimeOut: 0 });
                const user = `PREVIOUS OVERVIEW:\n${overview || '(none yet)'}\n\nMEMORIES:\n${batch.map(memoryBlock).join('\n')}`;
                const raw = await callModel(fill(PROMPT_REBUILD, true), ctx().substituteParams(user), wordBudget().response, out => !!parseSummary(out).overview, out => isComplete(out, { memory: false, overview: true }));
                overview = parseSummary(raw).overview || overview;
            }
            const now = state();
            now.overview = overview;
            if (!now.memories.some(m => m.source === 'auto')) now.baseOverview = overview;
            saveState();
            toast.ok('Создан новый синопсис.');
        } catch (e) {
            toast.err(`Не удалось создать синопсис.: ${errText(e)}`, { timeOut: 15000 });
            lastJob = { ok: false, text: `Не удалось создать синопсис.: ${errText(e)}`, at: Date.now() };
        } finally {
            if (progress) globalThis.toastr?.clear(progress);
            busy = null;
            job = null;
            renderTopbar();
        }
    })();
    await busy;
    refreshUi();
}

// ---------------------------------------------------------------- export

function download(name, text, type) {
    const blob = new Blob([text], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
const fileSafe = s => String(s ?? '').replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, ' ').trim().slice(0, 80) || 'chat';

/**
 * Everything needed to judge the summary prompt: the memories with how many
 * tokens of chat each one replaced, the prompt and settings that made them,
 * and (optionally) the original messages next to each memory.
 */
async function buildExport({ withSource = false } = {}) {
    const c = ctx();
    const s = settings();
    const st = state();
    const r = resolveModules();
    const w = wordBudget();
    const memories = [];
    let srcTotal = 0;
    let memTotal = 0;
    for (const m of st.memories) {
        const memTokens = await countTokens(memoryBlock(m));
        let srcTokens = null;
        let sourceMessages;
        if (m.source === 'auto' && m.end >= 0) {
            const msgs = c.chat.slice(m.start, m.end + 1).filter(x => x && !x.is_system);
            srcTokens = await countTokens(msgs.map(x => cleanText(x.mes, s.maxMessageChars)).join('\n'));
            srcTotal += srcTokens;
            memTotal += memTokens;
            if (withSource) sourceMessages = msgs.map(x => ({ name: x.name, is_user: !!x.is_user, mes: cleanText(x.mes, s.maxMessageChars) }));
        }
        const { overviewAfter: _o, ...rest } = m;
        memories.push({ ...rest, stats: { memTokens, srcTokens, ratio: srcTokens ? +(memTokens / srcTokens).toFixed(3) : null }, ...(sourceMessages ? { sourceMessages } : {}) });
    }
    return {
        format: 'memory-hub-export',
        version: VERSION,
        exportedAt: new Date().toISOString(),
        chat: c.getCurrentChatId(),
        bot: botName(),
        messages: c.chat.length,
        summarizedUpTo: st.lastEnd,
        chain: st.chain ?? [],
        prompt: {
            style: s.style,
            modules: activeModules().map(m => ({ id: m.id, name: m.name })),
            modulesFrom: r.from,
            memoryWords: w.memory,
            overviewWords: w.overview,
            responseLength: w.response,
            chunkSize: s.chunkSize,
            keepRaw: s.keepRaw,
            mode: s.mode,
            quotaBoost: s.quotaBoost,
            text: fill(summaryTemplate(), s.overviewEnabled),
        },
        recall: { topK: s.topK, budget: wordBudget().recall, queryDepth: s.queryDepth, lastInjection },
        stats: {
            memories: st.memories.length,
            summarizedSourceTokens: srcTotal,
            summarizedMemoryTokens: memTotal,
            compression: srcTotal ? +(memTotal / srcTotal).toFixed(3) : null,
            overviewTokens: await countTokens(st.overview),
        },
        overview: st.overview,
        memories,
    };
}

function exportMarkdown(x) {
    const pct = v => (v == null ? '—' : `${Math.round(v * 100)}%`);
    const lines = [
        `# Memory Hub — ${x.bot}`,
        '',
        `- Чат: ${x.chat}`,
        `- Отправлено, когда: ${new Date(x.exportedAt).toLocaleString()} · Memory Hub v${x.version}`,
        `- Все сообщения ${x.messages} · В итоге, #${x.summarizedUpTo} · память ${x.stats.memories} кусок`,
        `- prompt: ${x.prompt.style === 'custom' ? 'Написал все сам' : `Модуль ${x.prompt.modules.map(m => m.name).join(', ') || '(базовый)'} (${{ bot: 'Выбери себя', tags: 'из тега', default: 'По умолчанию' }[x.prompt.modulesFrom] ?? x.prompt.modulesFrom})`} · память ≤ ${x.prompt.memoryWords} слово · Краткое содержание ≤ ${x.prompt.overviewWords} слово · Резюме одно за другим ${x.prompt.chunkSize} сообщение`,
        `- Сократить текст ${x.stats.summarizedSourceTokens} Токенов осталось ${x.stats.summarizedMemoryTokens} Токен (${pct(x.stats.compression)}) · Краткое содержание ${x.stats.overviewTokens} Токен`,
        '',
        '## Резюме на данный момент',
        '',
        x.overview || '_(еще нет)_',
        '',
        `## память (${x.memories.length})`,
        '',
    ];
    x.memories.forEach((m, i) => {
        const where = m.end >= 0 ? `#${m.start}–#${m.end}` : m.source === 'carry' ? 'Сначала из чата' : m.source === 'import' ? 'импортировать' : 'Добавьте это сами';
        const st = m.stats.srcTokens ? ` · рукопись ${m.stats.srcTokens} → ${m.stats.memTokens} Токен (${pct(m.stats.ratio)})` : ` · ${m.stats.memTokens} Токен`;
        lines.push(`### ${i + 1}. ${m.title || '(без имени)'}${m.pinned ? ' 📌' : ''}${m.truncated ? ' ⚠ Ответ обрезан' : ''}${m.blocked && !String(m.text ?? '').trim() ? ' ⛔ Заблокировано (еще не написал)' : ''}`, '', `_${where}${st}_  `, `ключ: ${(m.keys ?? []).join(', ') || '—'}`, '', String(m.text ?? '').trim(), '');
        if (m.sourceMessages?.length) {
            lines.push('<details><summary>Исходное сообщение</summary>', '');
            for (const s of m.sourceMessages) lines.push(`> **${s.name}:** ${s.mes.replace(/\n+/g, ' ')}`, '>');
            lines.push('', '</details>', '');
        }
    });
    lines.push('## Prompt Краткое описание, используемое в настоящее время', '', '```', x.prompt.text, '```', '');
    return lines.join('\n');
}

async function exportDialog() {
    if (!state()) return toast.warn('Сначала откройте чат.');
    const c = ctx();
    const box = document.createElement('div');
    box.className = 'mh_export';
    box.innerHTML = `
      <h3>Экспортный банк памяти</h3>
      <p>Получил и память, и конспект. prompt Используемая сводка и статистика о том, сколько токенов уменьшается по сравнению с тем, сколько токенов осталось в каждом сообщении. Используйте, чтобы проверить это prompt Насколько хорошо ты работаешь?</p>
      <label class="checkbox_label"><input type="checkbox" class="mh_ex_src"> Прикрепите исходное сообщение под каждым воспоминанием. (Файл больше, но его можно сравнить с тем, что не было в аннотации.)</label>
      <div class="mh_btns">
        <div class="menu_button mh_ex_md"><i class="fa-brands fa-markdown"></i> Markdown (Легко читать)</div>
        <div class="menu_button mh_ex_json"><i class="fa-solid fa-file-code"></i> JSON (Можно импортировать обратно)</div>
      </div>`;
    box.addEventListener('click', async e => {
        const t = e.target;
        if (!(t instanceof Element)) return;
        const md = t.closest('.mh_ex_md');
        const js = t.closest('.mh_ex_json');
        if (!md && !js) return;
        const x = await buildExport({ withSource: box.querySelector('.mh_ex_src').checked });
        const base = `memory-hub - ${fileSafe(x.chat)}`;
        if (md) download(`${base}.md`, exportMarkdown(x), 'text/markdown;charset=utf-8');
        else download(`${base}.json`, JSON.stringify(x, null, 2), 'application/json');
        toast.ok('Уже экспортировано');
    });
    await new c.Popup(box, c.POPUP_TYPE.TEXT, '', { okButton: 'выключать' }).show();
}

// ---------------------------------------------------------------- settings panel

function numberRow(id, label, hint, min, max) {
    return `<label class="mh_row" title="${esc(hint)}"><span>${label}</span><input type="number" class="text_pole" id="${id}" min="${min}" max="${max}"></label>`;
}

function renderSettings() {
    const html = `
    <div class="memory-hub-settings">
      <div class="inline-drawer">
        <div class="inline-drawer-toggle inline-drawer-header">
          <b>Memory Hub <small class="mh_version">v${VERSION}</small></b>
          <div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div>
        </div>
        <div class="inline-drawer-content">
          <div id="mh_status" class="mh_status"></div>
          <div class="mh_btns">
            <div class="menu_button" id="mh_open"><span class="mh_icon_slot"></span> Открыть память</div>
            <div class="menu_button" id="mh_now"><i class="fa-solid fa-wand-magic-sparkles"></i> Суммировать сейчас</div>
            <div class="menu_button" id="mh_range"><i class="fa-solid fa-arrows-left-right-to-line"></i> Сводка выбранного диапазона</div>
            <div class="menu_button" id="mh_last"><i class="fa-solid fa-eye"></i> Что отправлено модели</div>
            <div class="menu_button" id="mh_carry"><i class="fa-solid fa-forward"></i> Продолжить историю в новом чате</div>
          </div>
          <div id="mh_warn" class="mh_warn"></div>

          <label class="checkbox_label"><input type="checkbox" id="mh_enabled"> Активировать</label>
          <label class="mh_row"><span>Режим суммирования</span>
            <select id="mh_mode" class="text_pole">
              <option value="auto">Автоматически</option>
              <option value="semi">С подтверждением</option>
              <option value="manual">Вручную</option>
            </select></label>
          <small id="mh_mode_hint" class="mh_hint"></small>
          <label class="checkbox_label" title="Сообщения, уже сохранённые в памяти, не отправляются модели повторно. Исходный чат остаётся на месте."><input type="checkbox" id="mh_trim"> Не отправлять уже суммированные сообщения (экономит токены)</label>
          <label class="checkbox_label"><input type="checkbox" id="mh_overview"> Добавлять краткое содержание истории</label>
          <label class="checkbox_label"><input type="checkbox" id="mh_latest"> Всегда добавлять последний блок памяти</label>
          <label class="checkbox_label"><input type="checkbox" id="mh_notify"> Уведомление при создании новой памяти</label>
          <label class="checkbox_label" title="Открывает панель памяти в верхней части чата"><input type="checkbox" id="mh_topbar"> Кнопка в верхней панели чата (совместима с Top Info Bar)</label>
          <label class="checkbox_label mh_sub" title="Если Top Info Bar не установлен, Memory Hub добавит собственную узкую панель"><input type="checkbox" id="mh_topbar_fb"> Создать свою панель, если нет Top Info Bar</label>
          <div class="mh_sub mh_iconrow"><span>Значок</span><div id="mh_icons" class="mh_icons"></div></div>
          <div class="mh_sub">
            <label class="mh_row"><span>Числовые знаки</span>
              <select id="mh_bstyle" class="text_pole">
                <option value="badge">Этикетка имеет рамку.</option>
                <option value="pill">Знак без границ</option>
                <option value="replace">Цифры вместо значков</option>
                <option value="replace-badge">Значки вместо иконок</option>
                <option value="none">Не отображается</option>
              </select></label>
            <label class="mh_row"><span>Положение знака</span>
              <select id="mh_bpos" class="text_pole">
                <option value="br">внизу справа</option>
                <option value="tr">вверху справа</option>
                <option value="bl">нижний левый</option>
                <option value="center">середина (Над значком)</option>
              </select></label>
            <label class="mh_row"><span>Цвет знака</span>
              <select id="mh_bcolor" class="text_pole">
                <option value="theme">согласно теме (Основной цвет шрифта)</option>
                <option value="quote">согласно теме: цвет слова (Quote)</option>
                <option value="em">согласно теме: Курсив (Em)</option>
                <option value="underline">согласно теме: Цвет подчеркивания</option>
                <option value="custom">Выбери себя</option>
              </select></label>
            <div class="mh_row" id="mh_bcustom"><span>Цвет цифр / фона / рамки</span>
              <span class="mh_colors"><input type="color" id="mh_bfg" title="Цвет номера"><input type="color" id="mh_bbg" title="Цвет фона знака"><input type="color" id="mh_bbd" title="Цвет границы метки"></span></div>
            <label class="mh_row"><span>Размер цифр</span>
              <select id="mh_bsize" class="text_pole"><option value="9">Маленький</option><option value="11">Средний</option><option value="13">Большой</option></select></label>
          </div>

          <h4>Промпт для суммирования</h4>
          <label class="mh_row"><span>Тип</span>
            <select id="mh_style" class="text_pole">
              <option value="modules">Собрать из модулей персонажа (рекомендуется)</option>
              <option value="custom">Свой промпт целиком</option>
            </select></label>
          <div id="mh_modbox" class="mh_modbox">
            <div class="mh_modhead"><b>Модули этого бота:</b> <span id="mh_botname"></span></div>
            <small id="mh_modsrc" class="mh_hint"></small>
            <div id="mh_mods" class="mh_mods"></div>
            <div id="mh_modinfo" class="mh_modinfo">Наведите курсор или коснитесь модуля, чтобы узнать, для каких историй он подходит.</div>
            <div class="mh_btns">
              <div class="menu_button" id="mh_mod_reset" title="Снимите метку модуля с карты. (Групповой чат: Отменить выбранное) а затем вернитесь к значениям по умолчанию."><i class="fa-solid fa-rotate-left"></i> Вернуться к настройкам по умолчанию</div>
              <div class="menu_button" id="mh_mod_setdef" title="Боты, которые еще не выбраны и не имеют соответствующих тегов, будут использовать этот набор."><i class="fa-solid fa-star"></i> Установите это по умолчанию.</div>
              <div class="menu_button" id="mh_mod_preview"><i class="fa-solid fa-eye"></i> Посмотреть готовый промпт</div>
              <div class="menu_button" id="mh_mod_manage"><i class="fa-solid fa-puzzle-piece"></i> Управлять модулями / создать свой</div>
            </div>
            <label class="checkbox_label"><input type="checkbox" id="mh_autowords"> Расширенная длина памяти, краткий обзор и инструкции по извлечению памяти. Автоматически в зависимости от модуля и количества сообщений в блоке.</label>
            <small id="mh_words_now" class="mh_hint"></small>
          </div>

          <h4>Когда и сколько суммировать</h4>
          ${numberRow('mh_chunk', 'Суммировать каждые N сообщений', 'Сколько сообщений включать в один блок памяти. Чем больше число, тем реже вызывается API.', 4, 200)}
          ${numberRow('mh_snooze', 'Повторить вопрос через N сообщений', 'Для режима с подтверждением: через сколько сообщений снова предложить суммирование.', 1, 200)}
          <label class="mh_row" title="Умножьте длину каждого фрагмента памяти на бюджет извлекаемой памяти. Используется, когда фрагмент памяти занимает много текста. или хотите получить более подробную информацию"><span>Множитель квоты памяти</span>
            <select id="mh_boost" class="text_pole"><option value="1">нормальный ×1</option><option value="1.5">×1.5</option><option value="2">×2</option><option value="3">×3</option></select></label>
          ${numberRow('mh_keep', 'Оставлять последние N сообщений целиком', 'Эти сообщения всегда передаются модели полностью и пока не суммируются.', 2, 200)}
          ${numberRow('mh_memwords', 'Длина блока памяти (слов)', 'Максимальная длина одного блока памяти.', 30, 600)}
          ${numberRow('mh_ovwords', 'Длина краткого сюжета (слов)', 'Максимальная длина краткого содержания истории.', 50, 1500)}
          ${numberRow('mh_resp', 'Длина ответа при суммировании (токенов)', 'Максимальный размер ответа модели при создании памяти.', 200, 8000)}

          <h4>Подбор воспоминаний</h4>
          ${numberRow('mh_topk', 'Подбирать не более N воспоминаний', 'Последний блок и закреплённые блоки в это число не входят.', 0, 20)}
          ${numberRow('mh_budget', 'Бюджет памяти (токенов)', 'Общий лимит для подобранных блоков памяти. Краткий сюжет не учитывается. Последний и закреплённые блоки добавляются даже сверх лимита.', 100, 8000)}
          ${numberRow('mh_qdepth', 'Учитывать последние N сообщений', 'По скольким последним сообщениям подбирать подходящие воспоминания.', 1, 20)}

          <h4>API для суммирования (при ошибке используется следующий)</h4>
          <div id="mh_sources" class="mh_sources"></div>
          <div class="mh_btns"><div class="menu_button" id="mh_src_add"><i class="fa-solid fa-plus"></i> Добавить резервный API</div></div>
          ${numberRow('mh_timeout', 'Тайм-аут ответа (секунд)', 'Если API не ответит вовремя, будет использован следующий в списке.', 15, 600)}
          <small class="mh_hint">Резервный API задаётся через Connection Profile. Создайте профили в API Connections, например для Google AI Studio и DeepSeek.</small>

          <div class="inline-drawer mh_adv">
            <div class="inline-drawer-toggle inline-drawer-header"><span>Дополнительно: расположение и текст промпта</span><div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div></div>
            <div class="inline-drawer-content">
              <label class="mh_row"><span>Позиция синопсиса</span>
                <select id="mh_ovpos" class="text_pole"><option value="prompt">После Story string / Char (рекомендовать)</option><option value="chat">В чате на depth</option></select></label>
              ${numberRow('mh_ovdepth', 'depth из синопсиса', 'Используется при выборе локации в чате.', 0, 50)}
              <label class="mh_row"><span>Полученная ячейка памяти</span>
                <select id="mh_recpos" class="text_pole"><option value="chat">В чате на depth (Рекомендуется при использовании prompt caching)</option><option value="prompt">После Story string / Char</option></select></label>
              ${numberRow('mh_recdepth', 'depth памяти получено', '0 = Последний, 2 = перед последним сообщением 2 сообщение', 0, 50)}
              ${numberRow('mh_maxchars', 'Обрезать слишком длинный текст (характер) При отправке подвести итоги', 'блокировать сообщения, содержащие status panel Займите много времени и съешьте жетоны.', 500, 50000)}
              <label>шаблон синопсиса <small>(использовать {{overview}})</small></label>
              <textarea id="mh_ovtpl" class="text_pole" rows="2"></textarea>
              <label>Получить шаблон памяти <small>(использовать {{memories}})</small></label>
              <textarea id="mh_rectpl" class="text_pole" rows="2"></textarea>
              <div id="mh_prompt_box">
                <label>Промпт для суммирования (свой промпт используется со всеми персонажами)</label>
                <textarea id="mh_prompt" class="text_pole" rows="12"></textarea>
                <div class="mh_btns">
                  <div class="menu_button" id="mh_prompt_from_mods">Перезагрузитесь из модуля этого бота.</div>
                </div>
                <small class="mh_hint">доступный: {{memory_words}} {{overview_words}} {{overview_rule}} {{overview_format}} {{char}} {{user}} — Формат ответа должен быть сохранен. &lt;memory&gt; держать</small>
              </div>
            </div>
          </div>
          <small class="mh_note">заказ <code>/memhub</code> Открыть банк памяти · <code>/memhub-now</code> Резюме немедленно · <code>/memhub-continue</code> Начните новый чат по каждой теме. — Используется для изготовления кнопок Quick Dock может</small>
        </div>
      </div>
    </div>`;
    $('#extensions_settings2').append(html);

    const s = settings();
    const bindCheck = (id, key) => $(id).prop('checked', !!s[key]).on('change', function () { s[key] = this.checked; saveSettings(); refreshUi(); });
    const bindNum = (id, key, lo, hi) => $(id).val(s[key]).on('change', function () { s[key] = clampInt(this.value, lo, hi, DEFAULTS[key]); this.value = s[key]; saveSettings(); refreshUi(); });
    const bindVal = (id, key) => $(id).val(s[key]).on('change input', function () { s[key] = this.value; saveSettings(); refreshUi(); });

    bindCheck('#mh_enabled', 'enabled');
    $('#mh_mode').val(s.mode).on('change', async function () {
        const mode = this.value;
        if (mode === 'manual' && s.mode !== 'manual' && !(await confirmManual())) { this.value = s.mode; return; }
        s.mode = mode;
        saveSettings(); refreshUi();
    });
    $('#mh_boost').val(String(s.quotaBoost)).on('change', function () { s.quotaBoost = Number(this.value) || 1; saveSettings(); refreshUi(); });
    bindCheck('#mh_trim', 'trimSummarized');
    bindCheck('#mh_overview', 'overviewEnabled');
    bindCheck('#mh_latest', 'includeLatest');
    bindCheck('#mh_notify', 'notify');
    bindCheck('#mh_topbar', 'topbar');
    bindCheck('#mh_topbar_fb', 'topbarFallback');
    $('#mh_icons').html(ICONS.map(ic => `<div class="mh_iconpick" data-icon="${esc(ic)}" title="${esc(iconLabel(ic))}" tabindex="0">${iconHtml(ic)}</div>`).join(''))
        .on('click', '.mh_iconpick', function () { s.icon = this.dataset.icon; saveSettings(); applyIcon(); });
    const bindLook = (id, key, num) => $(id).val(String(s[key])).on('change input', function () { s[key] = num ? Number(this.value) || DEFAULTS[key] : this.value; saveSettings(); refreshUi(); });
    bindLook('#mh_bstyle', 'badgeStyle');
    bindLook('#mh_bpos', 'badgePos');
    bindLook('#mh_bcolor', 'badgeColor');
    bindLook('#mh_bfg', 'badgeFg');
    bindLook('#mh_bbg', 'badgeBg');
    bindLook('#mh_bbd', 'badgeBd');
    bindLook('#mh_bsize', 'badgeSize', true);
    bindNum('#mh_chunk', 'chunkSize', 4, 200);
    bindNum('#mh_keep', 'keepRaw', 2, 200);
    bindNum('#mh_snooze', 'semiSnooze', 1, 200);
    bindNum('#mh_memwords', 'memoryWords', 30, 600);
    bindNum('#mh_ovwords', 'overviewWords', 50, 1500);
    bindNum('#mh_resp', 'responseLength', 200, 8000);
    bindNum('#mh_topk', 'topK', 0, 20);
    bindNum('#mh_budget', 'recallBudget', 100, 8000);
    bindNum('#mh_qdepth', 'queryDepth', 1, 20);
    bindNum('#mh_timeout', 'timeoutSec', 15, 600);
    bindNum('#mh_ovdepth', 'overviewDepth', 0, 50);
    bindNum('#mh_recdepth', 'recallDepth', 0, 50);
    bindNum('#mh_maxchars', 'maxMessageChars', 500, 50000);
    bindVal('#mh_ovpos', 'overviewPosition');
    bindVal('#mh_recpos', 'recallPosition');
    bindVal('#mh_ovtpl', 'overviewTemplate');
    bindVal('#mh_rectpl', 'recallTemplate');
    bindVal('#mh_prompt', 'prompt');

    $('#mh_style').val(s.style).on('change', function () {
        s.style = this.value;
        // start the custom prompt from what this bot uses now
        if (s.style === 'custom' && !String(s.prompt ?? '').trim()) { s.prompt = buildPrompt(activeModules(), { group: isGroup() }); $('#mh_prompt').val(s.prompt); }
        saveSettings(); refreshUi();
    });
    $('#mh_prompt_from_mods').on('click', () => { s.prompt = buildPrompt(activeModules(), { group: isGroup() }); $('#mh_prompt').val(s.prompt); saveSettings(); });
    bindCheck('#mh_autowords', 'autoWords');
    $('#mh_mods').on('change', 'input[type=checkbox]', function () {
        const ids = new Set(resolveModules().ids);
        if (this.checked) ids.add(this.value); else ids.delete(this.value);
        setBotModules(ids);
        showModuleInfo(this.value);
        refreshUi();
    }).on('pointerenter focusin', '.mh_mod', function () {
        showModuleInfo(this.querySelector('input')?.value);
    });
    $('#mh_mod_reset').on('click', async () => {
        const key = botKey();
        if (!key) return;
        const ch = currentChar();
        if (ch) {
            const tags = resolveModules().tags ?? [];
            if (!tags.length) return;
            const ok = await ctx().callGenericPopup(`удалить тег ${tags.join(', ')} выходная карта ${ch.name}? Этот бот вернется к модулю по умолчанию.`, ctx().POPUP_TYPE.CONFIRM);
            if (!ok) return;
            tagCard(ch, null);
        } else delete s.botModules[key];
        saveSettings(); refreshUi();
    });
    $('#mh_mod_setdef').on('click', () => { s.defaultModules = [...resolveModules().ids]; saveSettings(); refreshUi(); toast.ok('Установить по умолчанию'); });
    $('#mh_mod_preview').on('click', previewPrompt);
    $('#mh_mod_manage').on('click', manageModules);

    $('#mh_src_add').on('click', () => {
        const used = new Set(s.sources);
        const next = profiles().find(p => !used.has(p.id))?.id ?? (used.has('main') ? null : 'main');
        if (!next) return toast.info('нет Connection Profile которые еще не использовались. Создайте больше на вкладке API Connections до');
        s.sources.push(next); saveSettings(); renderSources();
    });
    $('#mh_sources').on('change', 'select', function () {
        s.sources[Number(this.dataset.i)] = this.value; saveSettings(); refreshUi();
    }).on('click', '.mh_src_up, .mh_src_del', function () {
        const i = Number(this.dataset.i);
        if (this.classList.contains('mh_src_up') && i > 0) [s.sources[i - 1], s.sources[i]] = [s.sources[i], s.sources[i - 1]];
        if (this.classList.contains('mh_src_del') && s.sources.length > 1) s.sources.splice(i, 1);
        saveSettings(); renderSources(); refreshUi();
    }).on('focus mousedown', 'select', renderSourcesOptionsOnly);

    $('#mh_open').on('click', openManager);
    $('#mh_now').on('click', summarizeNow);
    $('#mh_range').on('click', chooseRangeDialog);
    $('#mh_last').on('click', showLastInjection);
    $('#mh_carry').on('click', continueInNewChat);
    renderSources();
    refreshUi();
}

function sourceOptions(selected) {
    const opts = [['main', 'API Главное, что используется для общения'], ...profiles().map(p => [p.id, `Profile: ${p.name}`])];
    if (selected && !opts.some(o => o[0] === selected)) opts.push([selected, '(profile это было удалено — будет пропущен)']);
    return opts.map(([v, l]) => `<option value="${esc(v)}"${v === selected ? ' selected' : ''}>${esc(l)}</option>`).join('');
}
function renderSources() {
    const s = settings();
    $('#mh_sources').html(s.sources.map((id, i) => `
      <div class="mh_src">
        <span class="mh_src_n">${i + 1}.</span>
        <select class="text_pole" data-i="${i}">${sourceOptions(id)}</select>
        <i class="fa-solid fa-arrow-up mh_icon mh_src_up${i === 0 ? ' mh_off' : ''}" data-i="${i}" title="Вверх"></i>
        <i class="fa-solid fa-xmark mh_icon mh_src_del${s.sources.length < 2 ? ' mh_off' : ''}" data-i="${i}" title="удалить"></i>
      </div>`).join(''));
}
function renderSourcesOptionsOnly() {
    // profiles may have been created since the panel was drawn
    const sel = this;
    const i = Number(sel.dataset.i);
    const val = settings().sources[i];
    if (sel.options.length !== profiles().length + 1 + (val !== 'main' && !profiles().some(p => p.id === val) ? 1 : 0)) sel.innerHTML = sourceOptions(val);
}

function renderModulePicker() {
    const s = settings();
    $('#mh_modbox').toggle(s.style !== 'custom');
    const key = botKey();
    $('#mh_botname').text(key ? botName() : '(Чат еще не открывал.)');
    const r = resolveModules();
    const src = r.from === 'bot' ? 'Выбери себя в эту группу (Хранить в этой машине)'
        : r.from === 'tags' ? `из тега карты: ${r.tags.join(', ')} — Отметьте, чтобы изменить Метка на карте соответственно изменится.`
            : `По умолчанию${Array.isArray(s.defaultModules) ? '' : (isGroup() ? ' (Групповой чат)' : ' (Одиночный чат)')} — ${isGroup() ? 'Отметьте галочкой выбор этой группы.' : 'Отметьте, чтобы выбрать, затем Memory Hub Я поставлю метку на карту. Может использоваться на каждом устройстве, открывающем эту карту.'}`;
    $('#mh_modsrc').text(src);
    const on = new Set(r.ids);
    $('#mh_mods').html(moduleList().map(m => `
      <label class="mh_mod${on.has(m.id) ? ' mh_on' : ''}" title="${esc(moduleTip(m))}">
        <input type="checkbox" value="${esc(m.id)}"${on.has(m.id) ? ' checked' : ''}${key ? '' : ' disabled'}>
        <span>${esc(m.name)}${m.custom ? ' <i class="fa-solid fa-pen-nib" title="наш модуль"></i>' : ''}</span>
      </label>`).join(''));
    $('#mh_mod_reset').toggleClass('disabled', r.from === 'default');
    const w = wordBudget();
    $('#mh_words_now').text(`Этот бот (Каждый блок ${settings().chunkSize} сообщение): память ≤ ${w.memory} слово · Краткое содержание ≤ ${w.overview} слово · response ${w.response} Токен · Получить операторы памяти ${w.recall} Токен`);
}

/** The line under the module chips: works on phones, where tooltips do not. */
function showModuleInfo(id) {
    const m = moduleList().find(x => x.id === id);
    const el = document.getElementById('mh_modinfo');
    if (!el) return;
    if (!m) { el.innerHTML = 'Наведите или коснитесь модуля, чтобы увидеть, какой ориентации он соответствует.'; return; }
    el.innerHTML = `<b>${esc(m.name)}</b>${m.desc ? `<br>помнить: ${esc(m.desc)}` : ''}${m.fit ? `<br>подходит для: ${esc(m.fit)}` : ''}${m.tags?.length ? `<br><span class="mh_tp_dim">Теги, которые открываются сами: ${esc(m.tags.slice(0, 8).join(', '))}${m.tags.length > 8 ? ' …' : ''}</span>` : ''}`;
}

async function previewPrompt() {
    const s = settings();
    const { Popup, POPUP_TYPE } = ctx();
    const r = resolveModules();
    const names = activeModules().map(m => m.name).join(', ') || '(нет — Просто используйте основы.)';
    const text = fill(summaryTemplate(), s.overviewEnabled);
    const html = `<div class="mh_preview">
      <h3>Prompt Краткое изложение ${esc(botName() || 'Этот бот')}</h3>
      <p>${s.style === 'custom' ? 'Все написал сам' : `Модуль: <b>${esc(names)}</b> (${r.from === 'bot' ? 'Выбери себя' : r.from === 'tags' ? 'из тега' : 'По умолчанию'})`} · ${await countTokens(text)} Токен</p>
      <pre>${esc(text)}</pre></div>`;
    await new Popup(html, POPUP_TYPE.TEXT, '', { wide: true, allowVerticalScrolling: true }).show();
}

const linesOf = v => String(v ?? '').split('\n').map(x => x.replace(/^\s*[-•*]\s*/, '').trim()).filter(Boolean);

async function manageModules() {
    const s = settings();
    const { Popup, POPUP_TYPE } = ctx();
    const root = document.createElement('div');
    root.className = 'mh_modmgr';
    const draw = () => {
        const customIds = new Set(s.customModules.map(m => m.id));
        root.innerHTML = `
          <h3><i class="fa-solid fa-puzzle-piece"></i> Модуль prompt подвести итог</h3>
          <p class="mh_hint">Каждый модуль добавляет что-то, что стоит запомнить. prompt Резюме: Бот будет получать модули из (1) выбирается вручную на панели настроек. (2) Теги бота в SillyTavern это соответствует "Теги" модуля (3) По умолчанию
          Пишите все необходимое на английском языке для максимально стабильного результата. Но можно использовать тайский язык.</p>
          <div class="mh_btns"><div class="menu_button mh_mod_new"><i class="fa-solid fa-plus"></i> Создать новый модуль</div></div>
          ${s.customModules.map(m => moduleEditor(m, true)).join('')}
          <h4>Встроенный модуль</h4>
          ${BUILTIN_MODULES.filter(m => !customIds.has(m.id)).map(m => moduleEditor(m, false)).join('')}`;
    };
    draw();
    const findCustom = el => s.customModules.find(m => m.id === el.closest('.mh_modcard')?.dataset.id);
    root.addEventListener('input', e => {
        const t = e.target;
        const m = findCustom(t);
        if (!m || !t.dataset.f) return;
        const f = t.dataset.f;
        if (f === 'keep' || f === 'skip') m[f] = linesOf(t.value);
        else if (f === 'tags') m.tags = t.value.split(/[,，]/).map(x => x.trim()).filter(Boolean);
        else if (f === 'words' || f === 'overviewWords') m[f] = clampInt(t.value, 0, 1000, 0);
        else m[f] = t.value;
        saveSettings();
    });
    root.addEventListener('click', e => {
        const t = e.target;
        if (!(t instanceof Element)) return;
        if (t.closest('.mh_mod_new')) {
            s.customModules.unshift({ id: `c_${uid()}`, name: 'Новый модуль', desc: '', tags: [], keep: [], skip: [], keys: '', overview: '', words: 20, overviewWords: 40 });
            saveSettings(); draw(); refreshUi();
        } else if (t.closest('.mh_mod_copy')) {
            const id = t.closest('.mh_modcard').dataset.id;
            const b = moduleList().find(m => m.id === id);
            if (b) { s.customModules.unshift({ ...structuredClone(b), custom: undefined }); saveSettings(); draw(); refreshUi(); }
        } else if (t.closest('.mh_mod_del')) {
            const id = t.closest('.mh_modcard').dataset.id;
            s.customModules = s.customModules.filter(m => m.id !== id);
            saveSettings(); draw(); refreshUi();
        }
    });
    await new Popup(root, POPUP_TYPE.TEXT, '', { wide: true, large: true, allowVerticalScrolling: true, okButton: 'выключать' }).show();
    refreshUi();
}

function moduleEditor(m, editable) {
    const ro = editable ? '' : ' readonly';
    const builtinOverride = editable && !m.id.startsWith('c_');
    return `<div class="mh_modcard${editable ? ' mh_editable' : ''}" data-id="${esc(m.id)}">
      <div class="mh_card_head">
        <input class="text_pole mh_title" data-f="name" value="${esc(m.name)}"${ro}>
        ${editable
            ? `<i class="fa-solid fa-trash mh_icon mh_mod_del" title="${builtinOverride ? 'Удалите отредактированную версию и вернитесь к использованию встроенной версии.' : 'Удалить модуль'}"></i>`
            : '<div class="menu_button mh_mod_copy" title="Сделайте копию для редактирования. Наша версия будет использоваться вместо оригинала.">правильный</div>'}
      </div>
      ${builtinOverride ? '<small class="mh_hint">Доработка встроенного модуля (Удалить, чтобы вернуться к оригиналу.)</small>' : ''}
      <label>Что ты помнишь? (Краткое описание)</label><input class="text_pole" data-f="desc" value="${esc(m.desc ?? '')}"${ro}>
      <label>Какой тип бота подойдет?</label><input class="text_pole" data-f="fit" value="${esc(m.fit ?? '')}"${ro}>
      <label>Тег, открывающий этот модуль (разделены ,)</label><input class="text_pole" data-f="tags" value="${esc((m.tags ?? []).join(', '))}"${ro}>
      <label>Что следует помнить (Одна строка на вопрос)</label><textarea class="text_pole" data-f="keep" rows="3"${ro}>${esc((m.keep ?? []).join('\n'))}</textarea>
      <label>Вещи, которые вам не нужно помнить (Одна строка на вопрос)</label><textarea class="text_pole" data-f="skip" rows="1"${ro}>${esc((m.skip ?? []).join('\n'))}</textarea>
      <label>Какое слово должно быть ключевым?</label><input class="text_pole" data-f="keys" value="${esc(m.keys ?? '')}"${ro}>
      <label>Темы в синопсисе (Можно оставить пустым) такой как <code>Clues: what is known and by whom</code></label><input class="text_pole" data-f="overview" value="${esc(m.overview ?? '')}"${ro}>
      <div class="mh_row"><span>слова, которые нужно добавить в память / Краткое содержание</span>
        <input type="number" class="text_pole" data-f="words" value="${Number(m.words) || 0}"${ro}>
        <input type="number" class="text_pole" data-f="overviewWords" value="${Number(m.overviewWords) || 0}"${ro}></div>
    </div>`;
}

function refreshUi() {
    const s = settings();
    const st = state();
    $('#mh_ovdepth').closest('.mh_row').toggle(s.overviewPosition === 'chat');
    $('#mh_recdepth').closest('.mh_row').toggle(s.recallPosition === 'chat');
    $('#mh_prompt_box').toggle(s.style === 'custom');
    $('#mh_mode').val(s.mode);
    $('#mh_boost').val(String(s.quotaBoost));
    $('#mh_mode_hint').text({
        auto: `Подводите итоги каждый раз. ${s.chunkSize} сообщение`,
        semi: `каждый ${s.chunkSize} Перед завершением в окне появится сообщение с вопросом.`,
        manual: 'Если вы не пришли к выводу, нажмите "Резюме сейчас" когда это необходимо (Предупредит вас, когда будет много просроченного времени.)',
    }[s.mode] ?? '');
    $('#mh_chunk').siblings('span').text(s.mode === 'manual' ? 'Одно сообщение на память' : s.mode === 'semi' ? 'Спрашивайте каждый (сообщение)' : 'Сводка каждые (сообщение)');
    $('#mh_snooze').closest('.mh_row').toggle(s.mode === 'semi');
    $('#mh_bpos').closest('.mh_row').toggle(!['replace', 'replace-badge', 'none'].includes(s.badgeStyle));
    // a plain number has no background or border to colour
    $('#mh_bbg, #mh_bbd').toggle(s.badgeStyle !== 'replace');
    $('#mh_bcolor, #mh_bsize').closest('.mh_row').toggle(s.badgeStyle !== 'none');
    $('#mh_bcustom').toggle(s.badgeStyle !== 'none' && s.badgeColor === 'custom');
    renderModulePicker();

    let status;
    if (!st) status = 'Чат еще не открывал.';
    else {
        const len = ctx().chat.length;
        const pending = Math.max(0, len - 1 - st.lastEnd);
        status = `память <b>${st.memories.length}</b> кусок · Краткое содержание сообщения <b>#${st.lastEnd}</b> · Еще не завершено <b>${pending}</b> сообщение`;
        if (st.chain?.length) status += ` · позже из ${st.chain.length} предыдущий чат`;
        if (busy) status += ' · <i class="fa-solid fa-spinner fa-spin"></i> работающий';
        if (lastInjection) {
            status += `<br>в последний раз: Отправить краткий обзор ${lastInjection.overviewTokens} + память ${lastInjection.picked.length} кусок ${lastInjection.recallTokens} Токен`;
            if (lastInjection.trimmed) status += ` · Не отправляйте старые сообщения. ${lastInjection.trimmed} сообщение (сохранять ~${lastInjection.trimmedTokens} Токен)`;
        }
        if (lastApi) {
            status += lastApi.ok
                ? `<br><span class="mh_ok">✔ А также последнее резюме. ${esc(lastApi.label)}${lastApi.fallback ? ' (бронировать)' : ''}</span>`
                : `<br><span class="mh_bad">✖ Последняя сводка не удалась: ${esc(lastApi.error)}</span>`;
        }
    }
    $('#mh_status').html(status);
    $('#mh_now, #mh_range').toggleClass('disabled', !!busy);

    const warns = [];
    const c = ctx();
    if (c.extensionPrompts?.['1_memory']?.value?.trim()) warns.push('Summarize в SillyTavern Все еще отправляю сводку, если она используется. Memory Hub Вместо этого выключите его. (Summarize → Pause или отключите расширения) В противном случае вы потеряете свои токены двумя способами.');
    if (!hasSegmenter()) warns.push('В этом браузере нет оболочки слов. (Intl.Segmenter) Используется альтернативный метод, который менее точен.');
    const missing = s.sources.filter(id => id !== 'main' && !profiles().some(p => p.id === id));
    if (missing.length) warns.push(`иметь Connection Profile в списке API это невозможно найти ${missing.length} который (будет пропущен)`);
    const gaps = st ? gapsOf(st) : [];
    if (gaps.length) warns.push(gapWarning(gaps));
    if (st && hasBacklog(s, st, c.chat.length)) warns.push(`Еще не завершено ${pendingOf(st, c.chat.length)} сообщение (режим${MODE_TH[s.mode]}) Эти сообщения отправляются полностью каждый ход. Нажимать "Резюме сейчас" Чтобы сохранить токены и предотвратить потерю старых сообщений. context`);
    $('#mh_warn').html(warns.map(w => `<div><i class="fa-solid fa-triangle-exclamation"></i> ${esc(w)}</div>`).join(''));

    if (managerEl?.isConnected) renderManagerHeader();
    renderTopbar();
    applyIcon();
}

// ---------------------------------------------------------------- actions

const gapWarning = gaps => `сообщение ${gaps.map(gapLabel).join(', ')} нет памяти (память стерта) Это сообщение отправляется полностью каждый ход. Использовать "Резюме сессии…" подведу итог еще раз`;

/** Lets the messages of every gap go unremembered, as the user asked. */
async function skipGaps() {
    const st = state();
    const gaps = st ? gapsOf(st) : [];
    if (!gaps.length) return;
    const c = ctx();
    const ok = await c.callGenericPopup(`<h3>Не нужно запоминать. ${esc(gaps.map(gapLabel).join(', '))}?</h3>
      <p>Сообщения в течение этого времени больше не будут отправляться ботам. (Как и период, который завершился) и у него нет памяти. Бот не будет знать, что происходит в эти дни.</p>`,
    c.POPUP_TYPE.CONFIRM, '', { okButton: 'Не нужно запоминать.', cancelButton: 'отмена' });
    if (!ok) return;
    const cur = state();
    cur.skips = [...(cur.skips ?? []), ...gapsOf(cur)];
    saveState();
    refreshUi();
}

/** Checks a hand-picked range against the chat and what is summarized already. */
function checkRange(from, to) {
    const st = state();
    const len = ctx().chat.length;
    if (!st) return { error: 'Сначала откройте чат.' };
    if (!Number.isInteger(from) || !Number.isInteger(to)) return { error: 'Введите полный номер сообщения.' };
    if (from > to) return { error: 'Первое сообщение не может быть больше последнего.' };
    if (to > len - 1) return { error: `Этот чат содержит сообщения. #${len - 1}` };
    if (from <= st.lastEnd) {
        // a stretch whose memory was deleted can be summarized again on its own
        const gaps = gapsOf(st);
        if (gaps.some(([a, b]) => from >= a && to <= b)) return { n: to - from + 1, skip: null, fill: true, words: wordBudget({ size: to - from + 1 }).memory };
        const hint = gaps.length ? ` или период без памяти: ${gaps.map(gapLabel).join(', ')}` : '';
        return { error: `Сообщение для #${st.lastEnd} Подводя итог, можно начать с #${st.lastEnd + 1}${hint} (Если вы хотите снова суммировать исходный фрагмент, используйте 🔄 в банке памяти)` };
    }
    const skip = from > st.lastEnd + 1 ? [st.lastEnd + 1, from - 1] : null;
    return { n: to - from + 1, skip, words: wordBudget({ size: to - from + 1 }).memory };
}

/** Summarizes exactly chat[from..to] into one memory, for people who set the rhythm themselves. */
async function summarizeChosenRange(from, to) {
    const chk = checkRange(from, to);
    if (chk.error) return toast.warn(chk.error);
    if (busy) return toast.info('в настоящее время работаю');
    busy = (async () => {
        job = { label: 'Сводка выбранного диапазона', done: 0, total: 1, range: `#${from}–#${to}` };
        rangeSize = chk.n;
        renderTopbar();
        try {
            const mem = await summarizeRange(from, to, { updateOverview: !chk.fill });
            // messages skipped on purpose are covered too, so they stop being sent
            const st = state();
            if (st && chk.skip) st.skips = [...(st.skips ?? []), chk.skip];
            if (st && st.lastEnd < to) st.lastEnd = to;
            if (st) saveState();
            lastJob = { ok: true, text: `подвести итог #${from}–#${to} Это память. 1 кусок`, at: Date.now() };
            toast.ok(mem ? `Создайте воспоминание #${from}–#${to} уже` : `диапазон #${from}–#${to} Сводного сообщения нет.`);
        } catch (e) {
            console.error(LOG, e);
            lastJob = { ok: false, text: `подвести итог #${from}–#${to} неудачный: ${failText(e, `#${from}–#${to}`)}`, at: Date.now() };
            toast.err(`Краткое изложение неудачного выбора:\n${failText(e, `#${from}–#${to}`)}`, { timeOut: 15000 });
        } finally {
            rangeSize = null;
            busy = null;
            job = null;
            refreshUi();
        }
    })();
    return busy;
}

async function chooseRangeDialog() {
    const st = state();
    if (!st) return toast.warn('Сначала откройте чат.');
    if (busy) return toast.info('в настоящее время работаю');
    const s = settings();
    const c = ctx();
    const last = c.chat.length - 1;
    const box = document.createElement('div');
    box.className = 'mh_carry';
    box.innerHTML = `
      <h3>Сводка выбранного диапазона</h3>
      <p>Обобщающее сообщение, от какого сообщения к какому сообщению является воспоминанием. 1 общая сумма подведена к #${st.lastEnd} · Последний #${last}</p>
      <label class="mh_row"><span>Поскольку сообщение #</span><input type="number" class="text_pole mh_rg_from" min="0" max="${last}"></label>
      <label class="mh_row"><span>отправить сообщение #</span><input type="number" class="text_pole mh_rg_to" min="0" max="${last}"></label>
      <div class="mh_rg_info mh_hint"></div>`;
    const fromIn = box.querySelector('.mh_rg_from');
    const toIn = box.querySelector('.mh_rg_to');
    const info = box.querySelector('.mh_rg_info');
    const gap = gapsOf(st)[0];
    fromIn.value = gap ? gap[0] : Math.min(st.lastEnd + 1, last);
    toIn.value = gap ? gap[1] : Math.min(last, st.lastEnd + s.chunkSize);
    const show = () => {
        const chk = checkRange(parseInt(fromIn.value, 10), parseInt(toIn.value, 10));
        if (chk.error) { info.innerHTML = `<span class="mh_bad">${esc(chk.error)}</span>`; return; }
        const lines = [`${chk.n} сообщение → память 1 Длина комка не более ~${chk.words} слово`];
        if (chk.skip) lines.push(`<span class="mh_bad">⚠ сообщение #${chk.skip[0]}–#${chk.skip[1]} будет пропущен: Он не запоминается и больше не будет отправлен ботам.</span>`);
        if (chk.n > s.chunkSize * 3) lines.push('Чем длиннее отрезок, тем больше мелких деталей будет потеряно. Если хотите подробностей, разделите его на несколько сегментов. или увеличьте множитель квоты памяти');
        info.innerHTML = lines.join('<br>');
    };
    fromIn.addEventListener('input', show);
    toIn.addEventListener('input', show);
    show();
    const ok = await c.callGenericPopup(box, c.POPUP_TYPE.CONFIRM, '', { okButton: 'Итоги этого периода', cancelButton: 'отмена' });
    if (!ok) return;
    await summarizeChosenRange(parseInt(fromIn.value, 10), parseInt(toIn.value, 10));
}

async function summarizeNow() {
    if (!state()) return toast.warn('Сначала откройте чат.');
    if (busy) return toast.info('в настоящее время работаю');
    autoPausedUntil = 0;
    await runSummaries({ force: true });
}

async function showLastInjection() {
    const li = lastInjection;
    const { Popup, POPUP_TYPE } = ctx();
    if (!li) return toast.info('С момента открытия этого чата сообщений не было отправлено. Попробуйте отправить один или swipe один раз');
    const rows = li.picked.map(p => `<li><b>${esc(p.title)}</b> <small>${esc(p.why.join(' · '))}</small></li>`).join('');
    const html = `<div class="mh_preview">
      <h3>вещи Memory Hub вставить prompt последний</h3>
      <p>Не отправляйте завершенные сообщения. <b>${li.trimmed}</b> сообщение (~${li.trimmedTokens} Токен) ·
         Краткое содержание <b>${li.overviewTokens}</b> Токен · восстановление памяти <b>${li.recallTokens}</b> Токен</p>
      ${rows ? `<h4>Выбранная память (причина)</h4><ul>${rows}</ul>` : ''}
      ${li.overviewText ? `<h4>Краткое содержание</h4><pre>${esc(li.overviewText)}</pre>` : ''}
      ${li.recallText ? `<h4>память</h4><pre>${esc(li.recallText)}</pre>` : ''}
    </div>`;
    await new Popup(html, POPUP_TYPE.TEXT, '', { wide: true, allowVerticalScrolling: true }).show();
}

// ---------------------------------------------------------------- memory manager

let managerEl = null;
let managerFilter = '';

function renderManagerHeader() {
    const st = state();
    const el = managerEl?.querySelector('.mh_mgr_status');
    if (!el || !st) return;
    const len = ctx().chat.length;
    const imported = st.memories.filter(m => m.source === 'import').length;
    const carried = st.memories.filter(m => m.source === 'carry').length;
    const gaps = gapsOf(st);
    el.innerHTML = `память <b>${st.memories.length}</b> кусок${carried ? ` (Сначала из чата ${carried})` : ''}${imported ? ` (импортировать ${imported})` : ''} · В итоге, #${st.lastEnd} от ${len} сообщение${busy ? ' · <i class="fa-solid fa-spinner fa-spin"></i> работающий <a href="#" class="mh_cancel">останавливаться</a>' : ''}`
        + (gaps.length ? `<div class="mh_bad">⚠ ${esc(gapWarning(gaps))} <a href="#" class="mh_gap_fill">Итоги этого периода</a> · <a href="#" class="mh_gap_skip">Не нужно запоминать.</a></div>` : '');
    el.querySelector('.mh_gap_fill')?.addEventListener('click', async e => { e.preventDefault(); await chooseRangeDialog(); renderManagerList(); renderManagerHeader(); });
    el.querySelector('.mh_gap_skip')?.addEventListener('click', async e => { e.preventDefault(); await skipGaps(); renderManagerHeader(); });
    el.querySelector('.mh_cancel')?.addEventListener('click', e => { e.preventDefault(); cancelRequested = true; toast.info('Остановится после завершения этой партии.'); });
}

function memoryCard(m, recalled) {
    const range = m.end >= 0 ? `#${m.start}–#${m.end}`
        : m.source === 'carry' ? `Сначала из чата${m.origin ? ` #${m.origin.start}–#${m.origin.end}` : ''}`
            : m.source === 'import' ? `импортировать${m.optimized ? ' ✓' : ''}` : 'Добавьте это сами';
    return `<div class="mh_card${m.pinned ? ' mh_pinned' : ''}${recalled ? ' mh_recalled' : ''}" data-id="${esc(m.id)}">
      <div class="mh_card_head">
        <input class="text_pole mh_title" value="${esc(m.title)}" placeholder="имя">
        <span class="mh_range" title="${esc(m.origin?.chat ?? '')}">${esc(range)}</span>
        ${m.blocked && !String(m.text ?? '').trim() ? '<span class="mh_trunc" title="В настоящее время оно заблокировано контент-фильтром провайдера, поэтому будет пропущено. — Напишите свои воспоминания в поле ниже или нажмите 🔄 попробовать еще раз">⛔ Заблокировано</span>' : ''}
        ${m.truncated ? '<span class="mh_trunc" title="Ответ модели обрезан на полпути. Эта память может быть неполной. — увеличивать Response length затем нажмите 🔄">⚠ Не завершено</span>' : ''}
        <i class="fa-solid fa-thumbtack mh_icon mh_pin" title="Приколоть: вставить prompt каждый раз"></i>
        ${m.end >= 0 && m.source === 'auto' ? '<i class="fa-solid fa-rotate mh_icon mh_resum" title="Итоги этого периода (Например, после редактирования сообщения)"></i>' : ''}
        <i class="fa-solid fa-trash mh_icon mh_del" title="удалить"></i>
      </div>
      <textarea class="text_pole mh_keys" rows="1" placeholder="ключ (разделены , или новая строка)">${esc((m.keys ?? []).join(', '))}</textarea>
      <textarea class="text_pole mh_text" rows="4">${esc(m.text)}</textarea>
      ${recalled ? '<small class="mh_tag">вставить prompt последний</small>' : ''}
    </div>`;
}

/** Grows a keys box to show every key, so long ones need no scrolling sideways. */
function fitKeys(el) {
    if (!el.isConnected) return;
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight + el.offsetHeight - el.clientHeight}px`;
}
const fitAllKeys = () => requestAnimationFrame(() => managerEl?.querySelectorAll('.mh_keys').forEach(fitKeys));

function renderManagerList() {
    const st = state();
    const list = managerEl?.querySelector('.mh_list');
    if (!list || !st) return;
    const f = managerFilter.trim().toLowerCase();
    const recalled = new Set(lastInjection?.picked.map(p => p.id) ?? []);
    const mems = [...st.memories].reverse().filter(m => !f || `${m.title} ${(m.keys ?? []).join(' ')} ${m.text}`.toLowerCase().includes(f));
    list.innerHTML = mems.length ? mems.map(m => memoryCard(m, recalled.has(m.id))).join('') : '<div class="mh_empty">Все еще нет памяти? Нажимать "Резюме сейчас" Или продолжайте говорить до конца дня</div>';
    fitAllKeys();
    const hasImports = st.memories.some(m => m.source === 'import' && !m.optimized);
    managerEl.querySelector('.mh_do_optimize')?.classList.toggle('mh_hidden', !hasImports);
}

async function openManager() {
    const st = state();
    if (!st) return toast.warn('Сначала откройте чат.');
    const { Popup, POPUP_TYPE } = ctx();

    const root = document.createElement('div');
    root.className = 'mh_manager';
    root.innerHTML = `
      <h3><span class="mh_icon_slot"></span> Память этого чата</h3>
      <div class="mh_mgr_status"></div>
      <div class="mh_btns">
        <div class="menu_button mh_do_now"><i class="fa-solid fa-wand-magic-sparkles"></i> Суммировать сейчас</div>
        <div class="menu_button mh_do_add"><i class="fa-solid fa-plus"></i> Добавить воспоминание</div>
        <div class="menu_button mh_do_import"><i class="fa-solid fa-file-import"></i> Импорт</div>
        <div class="menu_button mh_do_optimize"><i class="fa-solid fa-broom"></i> Упорядочить импортированное (ИИ)</div>
        <div class="menu_button mh_do_rebuild"><i class="fa-solid fa-book-open"></i> Создать краткий сюжет заново</div>
        <div class="menu_button mh_do_carry"><i class="fa-solid fa-forward"></i> Продолжить в новом чате</div>
        <div class="menu_button mh_do_export"><i class="fa-solid fa-file-export"></i> Экспорт</div>
        <div class="menu_button mh_do_reset"><i class="fa-solid fa-eraser"></i> Очистить все</div>
      </div>
      <label><b>Краткий сюжет</b> <small>(можно изменить; обновится при следующем суммировании)</small></label>
      <textarea class="text_pole mh_overview_edit" rows="6" placeholder="еще нет"></textarea>
      <div class="mh_list_head"><b>Воспоминания</b> <input class="text_pole mh_search" placeholder="Поиск…"></div>
      <div class="mh_list"></div>`;
    managerEl = root;
    renderManagerHeader();
    renderManagerList();
    applyIcon(root);

    const ov = root.querySelector('.mh_overview_edit');
    const syncOverview = () => { ov.value = state()?.overview ?? ''; };
    syncOverview();
    ov.addEventListener('input', () => { state().overview = ov.value; saveState(); });

    root.querySelector('.mh_search').addEventListener('input', e => { managerFilter = e.target.value; renderManagerList(); });

    const find = el => {
        const id = el.closest('.mh_card')?.dataset.id;
        return state().memories.find(m => m.id === id);
    };
    root.addEventListener('input', e => {
        const t = e.target;
        const m = t.closest?.('.mh_card') && find(t);
        if (!m) return;
        if (t.classList.contains('mh_title')) m.title = t.value;
        else if (t.classList.contains('mh_keys')) { m.keys = t.value.split(/[,，\n]/).map(x => x.trim()).filter(Boolean); fitKeys(t); }
        else if (t.classList.contains('mh_text')) m.text = t.value;
        else return;
        saveState();
    });
    let popup;
    root.addEventListener('click', async e => {
        const t = e.target;
        if (!(t instanceof Element)) return;
        const guardBusy = () => { if (busy) { toast.info('в настоящее время работаю'); return true; } return false; };
        if (t.closest('.mh_do_now')) { await summarizeNow(); syncOverview(); renderManagerList(); return; }
        if (t.closest('.mh_do_add')) {
            state().memories.push({ id: uid(), start: -1, end: -1, title: 'Новая память', keys: [], text: '', pinned: false, source: 'manual', ts: Date.now() });
            saveState(); renderManagerList();
            return;
        }
        if (t.closest('.mh_do_import')) { await importDialog(); syncOverview(); renderManagerList(); renderManagerHeader(); return; }
        if (t.closest('.mh_do_optimize')) { if (guardBusy()) return; await optimizeImported(); syncOverview(); renderManagerList(); return; }
        if (t.closest('.mh_do_rebuild')) { if (guardBusy()) return; await rebuildOverview(); syncOverview(); return; }
        if (t.closest('.mh_do_export')) { await exportDialog(); return; }
        if (t.closest('.mh_do_carry')) { await popup?.completeCancelled(); await continueInNewChat(); return; }
        if (t.closest('.mh_do_reset')) {
            const ok = await ctx().callGenericPopup('Удалите все воспоминания и резюме этого чата.? (Сообщения чата не удаляются. Старые сообщения вернутся к отправке в полном объеме до тех пор, пока они не будут повторно суммированы.)', ctx().POPUP_TYPE.CONFIRM);
            if (!ok) return;
            const cur = state();
            cur.memories = []; cur.overview = ''; cur.lastEnd = -1; delete cur.skips; delete cur.baseOverview; delete cur.chain;
            saveState();
            syncOverview(); renderManagerList(); refreshUi();
            return;
        }
        const m = find(t);
        if (!m) return;
        if (t.classList.contains('mh_pin')) { m.pinned = !m.pinned; saveState(); renderManagerList(); }
        else if (t.classList.contains('mh_del')) {
            if (m.source === 'auto' && m.end >= 0) {
                if (guardBusy()) return;
                const ok = await ctx().callGenericPopup(`<h3>стереть память #${m.start}–#${m.end}?</h3>
                  <p>Это сообщение снова будет отправлено боту полностью, пока оно не будет повторно суммировано. (Сводка выбранного диапазона или "Резюме сейчас" Если это последний)</p>
                  <p>Если вы просто хотите еще раз подвести итоги после редактирования текста, нажмите 🔄 Можно заменить его этим комочком.</p>`,
                ctx().POPUP_TYPE.CONFIRM, '', { okButton: 'удалить', cancelButton: 'отмена' });
                if (!ok) return;
            }
            const cur = state();
            cur.memories = cur.memories.filter(x => x.id !== m.id);
            saveState();
            reconcile({ announce: true });
            syncOverview(); renderManagerList(); refreshUi();
        } else if (t.classList.contains('mh_resum')) {
            if (guardBusy()) return;
            t.classList.add('fa-spin');
            try {
                job = { label: 'Итоги этого периода', done: 0, total: 1, range: `#${m.start}–#${m.end}` };
                busy = summarizeRange(m.start, m.end, { replaceId: m.id, updateOverview: false });
                await busy;
                toast.ok('Краткое содержание этого периода еще раз');
            } catch (err) { toast.err(`Вывод оказался неудачным.: ${failText(err, `#${m.start}–#${m.end}`)}`, { timeOut: 15000 }); } finally { busy = null; job = null; renderTopbar(); }
            renderManagerList(); refreshUi();
        }
    });

    popup = new Popup(root, POPUP_TYPE.TEXT, '', { wide: true, large: true, allowVerticalScrolling: true, okButton: 'выключать' });
    const shown = popup.show();
    fitAllKeys(); // sizes need the popup on screen
    await shown;
    managerEl = null;
    refreshUi();
}

async function importDialog() {
    const c = ctx();
    const names = c.getWorldInfoNames?.() ?? [];
    const lastSummary = [...c.chat].reverse().find(m => m?.extra?.memory)?.extra?.memory;
    let chats = [];
    try { chats = await listOtherChats(); } catch (e) { console.warn(LOG, e); }
    const box = document.createElement('div');
    box.className = 'mh_import';
    box.innerHTML = `
      <h3>импортировать память</h3>
      <p><b>Из другого чата этого персонажа</b> — Воспроизвести воспоминания и краткое содержание Memory Hub Продолжайте из этого чата.</p>
      <select class="text_pole mh_chat"><option value="">— Выберите Чат —</option>${chats.map(x => `<option value="${esc(x.id)}">${esc(x.label)}</option>`).join('')}</select>
      <div class="menu_button mh_go_chat">Импортировать из чата</div>
      <hr>
      <p><b>из экспортированного файла</b> (.json из Memory Hub)</p>
      <label class="menu_button mh_file_btn"><i class="fa-solid fa-file-import"></i> Выберите файл .json<input type="file" class="mh_file" accept=".json,application/json" hidden></label>
      <hr>
      <p><b>от lorebook</b> (например, в Memory Books созданный) — Каждая запись становится воспоминанием. Затем он подбирается на основе релевантности, а не ключевых слов.</p>
      <select class="text_pole mh_book"><option value="">— выбирать lorebook —</option>${names.map(n => `<option>${esc(n)}</option>`).join('')}</select>
      <label class="checkbox_label"><input type="checkbox" class="mh_skipoff" checked> Пропустить закрытые записи</label>
      <label class="checkbox_label"><input type="checkbox" class="mh_optimize" checked> Организуйте и это. AI После импорта (Сократите длинные записи, измените их ключи и создайте краткий обзор, если у вас его еще нет.)</label>
      <div class="menu_button mh_go_book">импортирован из lorebook</div>
      <small>Каждый раз, когда он импортируется, он будет очищен. HTML Удалите повторяющиеся записи и ключи, которые являются основными именами. (Он не сломан. API) — После импорта удалите lorebook затем выйдите из чата/символ, иначе он будет отправлен снова.</small>
      <hr>
      <p><b>от Summarize в SillyTavern</b> — Используйте последнее резюме этого чата в качестве синопсиса.</p>
      <div class="menu_button mh_go_sum ${lastSummary ? '' : 'disabled'}">${lastSummary ? 'Используйте последнее резюме в качестве синопсиса.' : 'В этом чате нет сводки Summarize'}</div>`;
    let optimizeAfter = false;
    box.querySelector('.mh_file').addEventListener('change', async e => {
        const file = e.target.files?.[0];
        if (!file) return;
        try {
            const data = JSON.parse(await file.text());
            if (data?.format !== 'memory-hub-export' || !Array.isArray(data.memories)) throw new Error('Это не файл экспорта. Memory Hub');
            mergeForeign(data, data.chat || file.name);
        } catch (err) { toast.err(`Не могу импортировать файл: ${errText(err)}`); }
        e.target.value = '';
    });
    box.addEventListener('click', async e => {
        const t = e.target;
        if (!(t instanceof Element)) return;
        if (t.closest('.mh_go_chat')) {
            const id = box.querySelector('.mh_chat').value;
            if (!id) return toast.warn('Сначала выберите чат.');
            try { await importFromChat(id); } catch (err) { toast.err(errText(err)); }
        } else if (t.closest('.mh_go_book')) {
            const name = box.querySelector('.mh_book').value;
            if (!name) return toast.warn('выбирать lorebook до');
            const { n, skipped } = await importFromBook(name, box.querySelector('.mh_skipoff').checked);
            toast.ok(`импортировать ${n} Вход из ${name}${skipped ? ` (Пропустить дубликаты/бесплатно ${skipped})` : ''}`);
            if (n && box.querySelector('.mh_optimize').checked) optimizeAfter = true;
        } else if (t.closest('.mh_go_sum') && lastSummary) {
            state().overview = String(lastSummary);
            saveState();
            toast.ok('Установить как краткий обзор');
        }
    });
    const { Popup, POPUP_TYPE } = c;
    await new Popup(box, POPUP_TYPE.TEXT, '', { okButton: 'выключать' }).show();
    if (optimizeAfter && !busy) await optimizeImported();
}

// ---------------------------------------------------------------- chat top bar

const TOPBAR_ID = 'extensionTopBar';            // SillyTavern's "Top Info Bar" extension
const TOPBAR_NAME_ID = 'extensionTopBarChatName';
let barBtn = null;
let barPanel = null;
let ownBar = null;

function removeTopbar() {
    barBtn?.remove(); barPanel?.remove(); ownBar?.remove();
}

/** Puts the button in the top bar (before the chat name, like Memory Books) and the panel under it. */
function ensureTopbar() {
    const s = settings();
    if (!s.topbar) { removeTopbar(); return false; }
    let host = document.getElementById(TOPBAR_ID);
    if (host) {
        ownBar?.remove();
    } else {
        if (!s.topbarFallback) { removeTopbar(); return false; }
        const sheld = document.getElementById('sheld');
        const chat = document.getElementById('chat');
        if (!sheld || !chat) return false;
        if (!ownBar) {
            ownBar = document.createElement('div');
            ownBar.id = 'mh_ownbar';
            ownBar.innerHTML = '<span class="mh_ownbar_text"></span>';
        }
        if (ownBar.parentElement !== sheld) sheld.insertBefore(ownBar, chat);
        host = ownBar;
    }
    if (!barBtn) {
        barBtn = document.createElement('div');
        barBtn.id = 'mh_topbar_btn';
        barBtn.className = 'right_menu_button mh_topbtn';
        barBtn.tabIndex = 0;
        barBtn.setAttribute('role', 'button');
        barBtn.innerHTML = `<span class="mh_icon_slot"></span><span class="mh_topbadge"></span>`;
        const toggle = () => { barPanel?.classList.toggle('mh_open'); renderTopbar(); };
        barBtn.addEventListener('click', toggle);
        barBtn.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
    }
    const name = document.getElementById(TOPBAR_NAME_ID);
    if (barBtn.parentElement !== host) {
        if (host === ownBar) host.prepend(barBtn);
        else if (name?.parentElement === host) host.insertBefore(barBtn, name);
        else host.appendChild(barBtn);
    }
    if (!barPanel) {
        barPanel = document.createElement('div');
        barPanel.id = 'mh_topbar_panel';
        barPanel.addEventListener('click', onTopbarClick);
        barPanel.addEventListener('change', e => {
            const sel = e.target.closest?.('.mh_tp_add');
            if (!sel?.value) return;
            const id = sel.value;
            sel.blur(); // let the panel redraw (it waits while a list is open)
            if (setBotModules([...resolveModules().ids, id])) refreshUi();
        });
    }
    if (barPanel.parentElement !== host.parentElement) host.after(barPanel);
    return true;
}

async function onTopbarClick(e) {
    const t = e.target;
    if (!(t instanceof Element)) return;
    const a = t.closest('[data-mh]')?.dataset.mh;
    if (!a) return;
    e.preventDefault();
    if (a === 'close') barPanel.classList.remove('mh_open');
    else if (a === 'now') await summarizeNow();
    else if (a === 'range') await chooseRangeDialog();
    else if (a === 'carry') await continueInNewChat();
    else if (a === 'open') await openManager();
    else if (a === 'last') await showLastInjection();
    else if (a === 'stop') { cancelRequested = true; toast.info('Оно прекращается после того, как буханка будет готова.'); }
    else if (a === 'skip') await skipBlocked();
    else if (a === 'gapskip') await skipGaps();
    else if (a === 'resume') { autoPausedUntil = 0; onMessageReceived(null, 'normal'); }
    else if (a === 'mod-del') {
        const id = t.closest('[data-id]')?.dataset.id;
        if (setBotModules(resolveModules().ids.filter(x => x !== id))) refreshUi();
    }
    renderTopbar();
}

function topbarModulesHtml() {
    const r = resolveModules();
    const on = new Set(r.ids);
    const mods = moduleList();
    const chips = mods.filter(m => on.has(m.id)).map(m => `<span class="mh_tp_chip" title="${esc(moduleTip(m))}">${esc(m.name)}<i class="fa-solid fa-xmark" data-mh="mod-del" data-id="${esc(m.id)}" title="удалять"></i></span>`).join('');
    const rest = mods.filter(m => !on.has(m.id));
    const add = rest.length ? `<select class="mh_tp_add" title="Добавить модуль"><option value="">＋ увеличивать</option>${rest.map(m => `<option value="${esc(m.id)}" title="${esc(moduleTip(m))}">${esc(m.name)}</option>`).join('')}</select>` : '';
    return `<div class="mh_tp_mods"><span class="mh_tp_dim">Модуль (${MOD_FROM_TH[r.from] ?? r.from}):</span> ${chips || '<span class="mh_tp_dim">Только основы</span>'} ${add}</div>`;
}

const ago = ts => {
    const m = Math.round((Date.now() - ts) / 60000);
    return m < 1 ? 'минуту назад' : m < 60 ? `${m} минуту назад` : new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

const BADGE_THEME = { quote: '--SmartThemeQuoteColor', em: '--SmartThemeEmColor', underline: '--SmartThemeUnderlineColor' };
/** Badge look from the settings: CSS variables + data attributes on the button. */
function applyBadgeLook(s) {
    const st = barBtn.style;
    barBtn.dataset.bstyle = s.badgeStyle;
    barBtn.dataset.bpos = s.badgePos;
    const fg = s.badgeColor === 'custom' ? s.badgeFg : BADGE_THEME[s.badgeColor] ? `var(${BADGE_THEME[s.badgeColor]})` : '';
    const bg = s.badgeColor === 'custom' ? s.badgeBg : '';
    const bd = s.badgeColor === 'custom' ? s.badgeBd : fg;
    const set = (k, v) => (v ? st.setProperty(k, v) : st.removeProperty(k));
    set('--mh-badge-fg', fg);
    set('--mh-badge-bd', bd);
    set('--mh-badge-bg', bg);
    set('--mh-badge-size', `${Number(s.badgeSize) || 9}px`);
    // in place of the icon: large makes the digits about as tall as the icon
    set('--mh-badge-em', `${{ 9: 1, 11: 1.25, 13: 1.6 }[s.badgeSize] ?? 1}em`);
}

function renderTopbar() {
    if (!ensureTopbar()) return;
    const s = settings();
    const st = state();
    const inChat = !!st;
    barBtn.classList.toggle('mh_busy', !!busy);
    barBtn.classList.toggle('mh_hidden', !inChat);
    const badge = barBtn.querySelector('.mh_topbadge');
    if (!inChat) { barPanel.classList.remove('mh_open'); if (ownBar) ownBar.classList.add('mh_hidden'); return; }
    ownBar?.classList.remove('mh_hidden');

    const len = ctx().chat.length;
    const pending = Math.max(0, len - 1 - st.lastEnd);
    const failed = lastJob && !lastJob.ok && !busy;
    const backlog = hasBacklog(s, st, len);
    applyBadgeLook(s);
    const inPlace = s.badgeStyle.startsWith('replace');
    const text = s.badgeStyle === 'none' ? '' : busy && job ? `${Math.min(job.done + 1, job.total || 1)}/${job.total || 1}` : (st.lastEnd >= 0 ? `${inPlace ? '' : '#'}${st.lastEnd}` : '');
    badge.textContent = text;
    // in the icon's place the width must stay about two icons wide, or the top bar wraps:
    // long numbers get a smaller font instead (monospace digits are ~0.6em wide)
    const em = { 9: 1, 11: 1.25, 13: 1.6 }[s.badgeSize] ?? 1;
    const room = s.badgeStyle === 'replace-badge' ? 2 : 2.4;
    barBtn.style.setProperty('--mh-fit', String(inPlace && text ? Math.min(1, room / (0.6 * text.length * em)) : 1));
    badge.classList.toggle('mh_bad', !!failed || backlog);
    barBtn.classList.toggle('mh_has_badge', !!badge.textContent);
    barBtn.title = busy ? `Memory Hub: ${job?.label ?? 'работающий'} ${job?.range ?? ''}` : `Memory Hub: Краткое содержание сообщения #${st.lastEnd} · Еще не завершено ${pending}`;
    if (ownBar) ownBar.querySelector('.mh_ownbar_text').textContent = busy ? `${job?.label ?? 'работающий'} ${job?.range ?? ''}` : `Краткое изложение #${st.lastEnd} · выдающийся ${pending}`;

    applyIcon(barBtn);
    if (!barPanel.classList.contains('mh_open')) return;
    // A rebuild while the module list is open closes it (iOS shows the picker
    // natively and drops it the moment its <select> is replaced).
    const focused = document.activeElement;
    if (focused?.tagName === 'SELECT' && barPanel.contains(focused)) return;
    const nextAt = st.lastEnd + s.chunkSize + s.keepRaw;
    let jobHtml;
    if (busy && job) {
        jobHtml = `<div class="mh_tp_job"><i class="fa-solid fa-spinner fa-spin"></i>
          <b>${esc(job.label)}</b> ${esc(job.range ?? '')} <span class="mh_tp_dim">(${Math.min(job.done + 1, job.total || 1)}/${job.total || 1})</span>
          ${job.api ? `<br><span class="mh_tp_dim">использовать ${esc(job.api)}${job.attempts > 1 ? ` · API число ${job.attempt}/${job.attempts}` : ''}</span>` : ''}
          <a href="#" data-mh="stop" class="mh_tp_stop">останавливаться</a></div>`;
    } else {
        jobHtml = '<div class="mh_tp_job mh_tp_dim">Работы не ведутся.</div>';
    }
    if (queued) jobHtml += `<div class="mh_tp_dim">Снова жду очереди ${queued} время</div>`;
    if (lastJob && !busy) jobHtml += `<div class="${lastJob.ok ? 'mh_ok' : 'mh_bad'}">${lastJob.ok ? '✔' : '✖'} ${esc(lastJob.text)} <span class="mh_tp_dim">· ${ago(lastJob.at)}</span></div>`;
    const blocked = !busy && currentBlocked();
    const gaps = gapsOf(st);
    if (gaps.length) jobHtml += `<div class="mh_bad">⚠ ${esc(gapWarning(gaps))} <a href="#" data-mh="range">Итоги этого периода</a> · <a href="#" data-mh="gapskip">Не нужно запоминать.</a></div>`;
    if (blocked) jobHtml += `<div class="mh_bad">⛔ диапазон #${blocked.start}–#${blocked.end} Заблокировано фильтрами контента Следующий период не может быть суммирован, пока не пройдет этот период. <a href="#" data-mh="skip">Пропустить этот период (Напиши это сам)</a></div>`;
    const paused = !busy && s.mode !== 'manual' && autoPausedUntil > len;
    const modeLine = !s.enabled ? 'Memory Hub Это выключено.'
        : paused ? `Автоматическая сводка сохраняется после сбоя до появления сообщения #${autoPausedUntil - 1} <a href="#" data-mh="resume">Попробуйте сейчас</a>`
        : s.mode === 'manual' ? 'Режим сводки: нажимать "Резюме сейчас" когда это необходимо'
        : s.mode === 'semi' ? `полуавтоматический: Спросит, прежде чем завершить обсуждение сообщения. #${Math.max(nextAt, (st.remindAt ?? 0) - 1)}`
        : `Автоматически подводить итоги следующего раунда, когда в чате появляется сообщение. #${nextAt}`;
    const html = `
      <div class="mh_tp_head"><b><span class="mh_icon_slot"></span> Memory Hub</b> <span class="mh_tp_dim">${esc(botName())}</span>
        <i class="fa-solid fa-xmark mh_tp_close" data-mh="close" title="выключать"></i></div>
      <div class="mh_tp_stat">Краткое содержание сообщения <b>#${st.lastEnd}</b> от всех ${len} · Еще не завершено <b>${pending}</b> · память ${st.memories.length} кусок</div>
      ${s.style === 'custom' ? '<div class="mh_tp_dim">Prompt подвести итог: Написал все сам</div>' : topbarModulesHtml()}
      <div class="mh_tp_dim">${modeLine}</div>
      ${backlog ? `<div class="mh_bad">⚠ выдающийся ${pending} Сообщения отправляются полностью каждый ход. и старые сообщения могут быть потеряны context Прежде чем быть запомненным <a href="#" data-mh="now">В итоге</a></div>` : ''}
      ${jobHtml}
      <div class="mh_tp_btns">
        <div class="menu_button${busy ? ' disabled' : ''}" data-mh="now"><i class="fa-solid fa-wand-magic-sparkles"></i> Резюме сейчас</div>
        <div class="menu_button${busy ? ' disabled' : ''}" data-mh="carry"><i class="fa-solid fa-forward"></i> подвести итог + Новый чат</div>
        <div class="menu_button" data-mh="open"><i class="fa-solid fa-book-open"></i> банк памяти</div>
        <div class="menu_button${busy ? ' disabled' : ''}" data-mh="range"><i class="fa-solid fa-arrows-left-right-to-line"></i> Резюме сессии…</div>
        <div class="menu_button" data-mh="last"><i class="fa-solid fa-eye"></i> Что ты недавно отправлял?</div>
      </div>`;
    // only touch the DOM when something changed (this runs every 2 s)
    if (barPanel.dataset.html !== html) { barPanel.innerHTML = html; barPanel.dataset.html = html; }
    applyIcon(barPanel);
}

// ---------------------------------------------------------------- init

function registerCommands() {
    const { SlashCommandParser, SlashCommand } = ctx();
    if (!SlashCommandParser || !SlashCommand) return;
    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'memhub',
        callback: async () => { await openManager(); return ''; },
        helpString: 'Откройте свой банк памяти. Memory Hub',
    }));
    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'memhub-now',
        callback: async () => { await summarizeNow(); return ''; },
        helpString: 'Memory Hub: Обобщите сообщения, которые не были обобщены сразу.',
    }));
    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'memhub-range',
        callback: async (_args, value) => {
            const m = String(value ?? '').match(/(\d+)\D+(\d+)/);
            if (m) await summarizeChosenRange(Number(m[1]), Number(m[2]));
            else await chooseRangeDialog();
            return '';
        },
        helpString: 'Memory Hub: Обобщить выделенный диапазон текста в памяти. 1 комок, такой как <code>/memhub-range 40-75</code> (Если вы не введете номер, откроется окно для выбора.)',
    }));
    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'memhub-export',
        callback: async () => { await exportDialog(); return ''; },
        helpString: 'Memory Hub: Экспортировать архив памяти этого чата (Markdown / JSON)',
    }));
    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'memhub-continue',
        callback: async () => { await continueInNewChat(); return ''; },
        helpString: 'Memory Hub: Начните новый чат на ту же тему. Носите свою память с собой.',
    }));
}

jQuery(() => {
    try {
        settings();
        renderSettings();
        registerCommands();
        const { eventSource, eventTypes: E } = ctx();
        eventSource.on(E.MESSAGE_RECEIVED, onMessageReceived);
        eventSource.on(E.MESSAGE_RECEIVED, () => renderTopbar());
        eventSource.on(E.MESSAGE_SENT, () => renderTopbar());
        if (E.APP_READY) eventSource.on(E.APP_READY, () => renderTopbar());
        // the Top Info Bar may load after us, or be switched on/off later
        setInterval(() => { if (settings().topbar) renderTopbar(); }, 2000);
        eventSource.on(E.MESSAGE_DELETED, () => reconcile({ announce: true }));
        eventSource.on(E.CHAT_CHANGED, () => {
            clearPrompts();
            lastInjection = null;
            cancelRequested = true;
            autoPausedUntil = 0;
            backlogWarned = 0;
            migrateBotModules();
            reconcile({ announce: true });
            refreshUi();
        });
        console.log(LOG, `v${VERSION} loaded`);
    } catch (e) {
        console.error(LOG, 'init failed', e);
    }
});
