const MODULE_NAME = 'st_new_chat_with_summary';
const MENU_ITEM_ID = 'st_new_chat_with_summary_wand_button';
const SETTINGS_CONTAINER_ID = 'st_ncws_settings';
const SUMMARY_BACKUP_KEY = 'st_ncws_summary_backup';

function getSettings(context) {
    if (!context.extensionSettings[MODULE_NAME]) {
        context.extensionSettings[MODULE_NAME] = {};
    }

    const settings = context.extensionSettings[MODULE_NAME];
    if (settings.enabled === undefined) {
        settings.enabled = false;
    }
    if (settings.prompt === undefined) {
        settings.prompt = '';
    }

    return settings;
}

// Mirrors the Summarize extension's own drawer style so this settings block blends in.
function addSettingsUI() {
    if (document.getElementById(SETTINGS_CONTAINER_ID)) {
        return;
    }

    const container = document.getElementById('extensions_settings');
    if (!container) {
        return;
    }

    const context = SillyTavern.getContext();
    const settings = getSettings(context);

    const html = `
        <div id="${SETTINGS_CONTAINER_ID}">
            <div class="inline-drawer">
                <div class="inline-drawer-toggle inline-drawer-header">
                    <b>Новый чат со сводкой</b>
                    <div class="inline-drawer-icon fa-solid interactable down fa-circle-chevron-down"></div>
                </div>
                <div class="inline-drawer-content">
                    <label class="checkbox_label" for="st_ncws_enabled" title="Если включено и ниже задан промпт, принудительная сводка использует его вместо промпта Summarize. Модель, длина ответа и другие параметры берутся из настроек Summarize.">
                        <input id="st_ncws_enabled" type="checkbox">
                        <span>Использовать свой промпт для сводки</span>
                    </label>
                    <label for="st_ncws_prompt">Свой промпт для сводки</label>
                    <textarea id="st_ncws_prompt" class="text_pole textarea_compact" rows="6" placeholder="Оставьте пустым, чтобы использовать промпт Summarize."></textarea>
                    <small>Применяется только если перед созданием нового чата выбрано повторное суммирование. Иначе переносится последняя сохранённая сводка.</small>
                </div>
            </div>
        </div>
    `;

    container.insertAdjacentHTML('beforeend', html);

    const enabledInput = document.getElementById('st_ncws_enabled');
    const promptInput = document.getElementById('st_ncws_prompt');
    enabledInput.checked = settings.enabled;
    promptInput.value = settings.prompt;

    enabledInput.addEventListener('input', () => {
        settings.enabled = enabledInput.checked;
        context.saveSettingsDebounced();
    });
    promptInput.addEventListener('input', () => {
        settings.prompt = promptInput.value;
        context.saveSettingsDebounced();
    });
}

function getLastBotMessage(chat) {
    if (!Array.isArray(chat) || chat.length === 0) {
        return null;
    }

    for (let i = chat.length - 1; i >= 0; i--) {
        const mes = chat[i];
        if (mes && !mes.is_user && !mes.is_system) {
            return mes;
        }
    }

    return null;
}

// Same scan as the Summarize extension's own getLatestMemoryFromChat(), but doesn't
// unconditionally discard the last message first - that breaks on a 1-message chat.
function getLatestSummary(chat) {
    if (!Array.isArray(chat) || chat.length === 0) {
        return '';
    }

    const searchable = chat.length > 1 ? chat.slice(0, -1) : chat;

    for (let i = searchable.length - 1; i >= 0; i--) {
        const mes = searchable[i];
        if (mes.extra && mes.extra.memory) {
            return mes.extra.memory;
        }
    }

    return '';
}

// Some models wrap summaries in a reasoning block; strip it before using the text.
function sanitizeSummaryText(text) {
    if (!text) {
        return '';
    }

    return text
        .replace(/<think>[\s\S]*?<\/think>/gi, '')
        .replace(/^\s*<think>/i, '')
        .trim();
}

// Writes through the Summarize extension's own UI so its position/depth/role settings
// apply, then force-saves immediately (bypassing its 1s debounce) and stashes a backup
// on chat_metadata so the summary can be recovered if the memory extension later deletes it.
async function applyToMemoryExtension(context, text) {
    $('#memory_contents').val(text).trigger('input');
    context.chatMetadata[SUMMARY_BACKUP_KEY] = text;
    await context.saveChat();
}

// Same "pre-last message" index the Summarize extension uses for its own writes.
function restoreMemoryToMessage(chat, value) {
    if (!Array.isArray(chat) || chat.length === 0) {
        return false;
    }

    const idx = Math.max(0, chat.length - 2);
    const mes = chat[idx];
    if (!mes) {
        return false;
    }

    if (!mes.extra) {
        mes.extra = {};
    }
    mes.extra.memory = value;
    return true;
}

// Read-only version of the Summarize extension's setMemoryContext(value, false) - updates
// the textarea and extension prompt without touching any chat message.
function reapplyMemoryDisplay(context, value) {
    const memorySettings = context.extensionSettings?.memory ?? {};
    const template = memorySettings.template || 'Summary: {{summary}}';
    const formatted = value ? context.substituteParamsExtended(template, { summary: value.trim() }) : '';

    context.setExtensionPrompt(
        '1_memory',
        formatted,
        memorySettings.position,
        memorySettings.depth,
        memorySettings.scan,
        memorySettings.role,
    );
    $('#memory_contents').val(value);
}

// Two bugs in the built-in Summarize extension surface on a 1-message chat: its
// onChatChanged() always wipes the display (getLatestMemoryFromChat has the same
// off-by-one getLatestSummary works around above), and its onChatEvent() - comparing
// chat length/hash against state left over from whatever chat was open before - can
// mistake switching characters for an edited message and delete mes.extra.memory
// outright. The chat_metadata backup survives that deletion since it lives outside
// any chat message, so it's used to restore the data, not just the display.
function fixMemoryUiOnChatChanged() {
    setTimeout(async () => {
        const context = SillyTavern.getContext();
        const backup = context.chatMetadata?.[SUMMARY_BACKUP_KEY];
        if (!backup) {
            return;
        }

        const liveValue = getLatestSummary(context.chat);
        let correctValue = liveValue;

        if (!liveValue) {
            const restored = restoreMemoryToMessage(context.chat, backup);
            if (restored) {
                await context.saveChat();
                correctValue = backup;
            }
        } else if (liveValue !== backup) {
            // A newer summary was generated since - track it instead of overwriting it.
            context.chatMetadata[SUMMARY_BACKUP_KEY] = liveValue;
            correctValue = liveValue;
        }

        if ($('#memory_contents').val() !== correctValue) {
            reapplyMemoryDisplay(context, correctValue);
        }
    }, 100);
}

function addMenuItem() {
    if (document.getElementById(MENU_ITEM_ID)) {
        return;
    }

    const container = document.getElementById('extensionsMenu');
    if (!container) {
        return;
    }

    const item = document.createElement('div');
    item.id = MENU_ITEM_ID;
    item.classList.add('list-group-item', 'flex-container', 'flexGap5');
    item.innerHTML = '<div class="fa-solid fa-scroll extensionsMenuExtensionButton"></div><span>Новый чат<br>со сводкой</span>';
    container.appendChild(item);

    item.addEventListener('click', onMenuItemClick);
}

// Same "Classic, blocking" mechanism the Summarize extension's Main API source uses,
// reusing its word target / WI-AN skip / response length settings for consistency.
async function forceSummarizeWithCustomPrompt(context) {
    const settings = getSettings(context);
    if (!settings.enabled || !settings.prompt.trim()) {
        return '';
    }

    const memorySettings = context.extensionSettings?.memory ?? {};
    const promptWords = memorySettings.promptWords ?? 200;
    const skipWIAN = memorySettings.SkipWIAN ?? false;
    const responseLength = memorySettings.overrideResponseLength ?? 0;

    const prompt = context.substituteParamsExtended(settings.prompt, { words: promptWords });
    const text = await context.generateQuietPrompt({ quietPrompt: prompt, skipWIAN, responseLength });
    return sanitizeSummaryText(typeof text === 'string' ? text : '');
}

async function forceSummarizeWithMemoryExtension(context) {
    const result = await context.executeSlashCommandsWithOptions('/summarize', { handleExecutionErrors: true });
    const text = result?.pipe;
    return sanitizeSummaryText(typeof text === 'string' ? text : '');
}

async function forceSummarizeNow(context) {
    const customResult = await forceSummarizeWithCustomPrompt(context);
    if (customResult) {
        return customResult;
    }

    return await forceSummarizeWithMemoryExtension(context);
}

async function askForceSummarize(context) {
    const settings = getSettings(context);
    const usingCustomPrompt = settings.enabled && settings.prompt.trim().length > 0;
    const checkboxId = 'st_new_chat_with_summary_force';
    const label = usingCustomPrompt
        ? 'Создать новую сводку со своим промптом'
        : 'Обновить сводку перед началом (через Summarize)';

    const popup = new context.Popup(
        '<h3>Новый чат со сводкой</h3><p>Перенести последнюю сводку в новый чат?</p>',
        context.POPUP_TYPE.CONFIRM,
        null,
        {
            okButton: 'Продолжить',
            cancelButton: 'Отмена',
            customInputs: [{
                id: checkboxId,
                label: label,
                defaultState: false,
            }],
        },
    );
    await popup.show();

    if (popup.result !== context.POPUP_RESULT.AFFIRMATIVE) {
        return { cancelled: true, forceSummarize: false };
    }

    return { cancelled: false, forceSummarize: Boolean(popup.inputResults?.get(checkboxId)) };
}

async function onMenuItemClick() {
    const context = SillyTavern.getContext();

    if (context.groupId === undefined && context.characterId === undefined) {
        toastr.warning('Сначала выберите персонажа или групповой чат.', 'Новый чат со сводкой');
        return;
    }

    const { cancelled, forceSummarize } = await askForceSummarize(context);
    if (cancelled) {
        return;
    }

    let summary = '';
    if (forceSummarize) {
        summary = await forceSummarizeNow(context);
        if (!summary) {
            toastr.warning('Не удалось создать новую сводку. Будет использована последняя сохранённая.', 'Новый чат со сводкой');
        }
    }
    if (!summary) {
        summary = sanitizeSummaryText(getLatestSummary(context.chat));
    }

    if (!summary) {
        toastr.info('В текущем чате нет сводки. Новый чат начнётся без переноса контекста.', 'Новый чат со сводкой');
    }

    // Captured before doNewChat() clears the old chat's in-memory array.
    const lastBotMessage = getLastBotMessage(context.chat);
    const openingMessage = lastBotMessage ? structuredClone(lastBotMessage) : null;

    // doNewChat() isn't exposed on getContext(), so defer to the native "Start new chat"
    // button (with its own confirm popup) and carry context over once CHAT_CHANGED fires.
    let timeoutId;
    const cleanup = () => {
        clearTimeout(timeoutId);
        context.eventSource.removeListener(context.eventTypes.CHAT_CHANGED, onNewChatReady);
    };
    async function onNewChatReady() {
        cleanup();
        const freshContext = SillyTavern.getContext();

        // Replace the auto-inserted greeting with the last thing the bot actually said.
        if (openingMessage) {
            freshContext.chat.splice(0, freshContext.chat.length, openingMessage);
            await freshContext.printMessages();
            await freshContext.saveChat();
        }

        if (!summary) {
            return;
        }

        // Deferred: the memory extension's own CHARACTER_MESSAGE_RENDERED handler fires
        // right after CHAT_CHANGED and wipes the summary textarea for a 1-message chat;
        // this needs to write after that settles to be the value that sticks.
        setTimeout(() => applyToMemoryExtension(freshContext, summary), 100);
    }

    context.eventSource.on(context.eventTypes.CHAT_CHANGED, onNewChatReady);
    timeoutId = setTimeout(cleanup, 30000);

    $('#option_start_new_chat').trigger('click');
}

jQuery(function () {
    const context = SillyTavern.getContext();
    context.eventSource.on(context.eventTypes.APP_READY, addMenuItem);
    context.eventSource.on(context.eventTypes.APP_READY, addSettingsUI);
    context.eventSource.on(context.eventTypes.CHAT_CHANGED, fixMemoryUiOnChatChanged);
});
