# 🌦️ Ambient Weather Overlay

A SillyTavern extension that paints a full-screen ambient weather effect (rain, snow, storms, wind, and day/night lighting) synced to your roleplay — with optional ambient audio and a fully manual **Free Mode** for when you don't want to wait on the AI.

![version](https://img.shields.io/badge/version-5.6-blue)

## ✨ Features

- 🌧️ Rain (light/heavy), ⛈️ storms with lightning, ❄️ snow (light/heavy), 💨 wind gusts (breezy/strong)
- 🌅 Time-of-day lighting: dawn / day / dusk / night tint
- 🔊 Optional ambient audio per weather type, with master + per-track volume control and an in-panel preview button
- 🎮 **Free Mode** — pick the weather yourself from dropdowns, no AI tag needed
- 🪶 Lite Mode for older/slower phones
- 🌐 English / ไทย language switch
- 📱 Mobile-safe rendering
- 🔁 Always in sync — clears/updates automatically on message delete, regenerate, edit, or swipe

## 📦 Installation

1. In SillyTavern, open **Extensions** (the 3 boxes icon) → **Install extension**.
2. Paste your repo URL:
   ```
   https://github.com/xo-nara/st-weather-overlay
   ```
3. Click **Install**, then reload the page.
4. Open **Extensions** → you should see **🌦 Ambient Weather Overlay**. Open it and make sure **Enabled** is on.

## 🚀 Usage

### Option A — Auto Mode (driven by the AI)

**Already using the Gemini Omega 3.0 preset/jailbreak?** Just enable the built-in module — no prompt copying needed:
👇 **Fun Mode** → 🌨️──Weather Simulation

**Using any other preset or character?** Copy this block into that character's **Description** or **System Prompt**:

```
<wx_emit>
At the very END of every response, {{char}} must output ONE line using ONLY this vocabulary, derived from the scene's real weather + hour. No prose, nothing else:

[wx: {none|rain|storm|snow} {light|heavy} {calm|breezy|strong} {dawn|day|dusk|night}]

- Reflect ACTUAL in-scene weather + time. Indoors/no sky → precip=none, wind=calm, but still give the correct light (dawn/day/dusk/night).
- State only — never mention it in narrative, never let characters react to it.
</wx_emit>
```

(Optional) Add a Regex script (Alter Chat Display only) to hide the tag from the chat view:
- Find: `\[wx:[^\]]*\]`
- Replace: *(empty)*

### Option B — Free Mode (fully manual, no AI needed)
1. Open the extension settings → toggle **Free Mode** on.
2. Four dropdowns appear (Precipitation / Intensity / Wind / Time of Day) — pick anything, it applies instantly.
3. Toggle Free Mode off to hand control back to the AI.

## ⚙️ Settings overview

| Setting | What it does |
|---|---|
| Enabled | Master on/off switch |
| Force animations | Overrides the device's reduced-motion setting |
| Lite Mode | ~35% fewer particles, no blur — smoother on older phones |
| Free Mode | Manual weather control (see above) |
| Debug logging | Verbose console logs for troubleshooting |
| Master Volume | Global volume for all weather audio |
| Per-weather audio URL | Direct `.mp3`/`.ogg`/`.wav` link — a volume slider appears once a link is detected |
| Particle Speed | Universal speed multiplier for rain/snow/wind |
| Test Weather | Preview any of 10 weather presets instantly |
| Reload | Force a re-sync to the current last message |

## 🙏 Credits
Contributor: xo.nara, Claude · Tester: zealllll

---
---

# 🌦️ Ambient Weather Overlay (ภาษาไทย)

ส่วนขยาย SillyTavern ที่แสดงเอฟเฟกต์สภาพอากาศเต็มจอ (ฝน หิมะ พายุ ลม และแสงกลางวัน/กลางคืน) ให้ตรงกับฉากในการเล่นบทบาทสมมติ พร้อมเสียงบรรยากาศ (ถ้าต้องการ) และโหมด **Free Mode** ที่เลือกสภาพอากาศเองได้โดยไม่ต้องรอ AI

## ✨ ฟีเจอร์

- 🌧️ ฝน (เบา/หนัก), ⛈️ พายุพร้อมฟ้าแลบ, ❄️ หิมะ (เบา/หนัก), 💨 ลมกระโชก (ลมโชย/แรง)
- 🌅 แสงตามช่วงเวลา: รุ่งอรุณ / กลางวัน / พลบค่ำ / กลางคืน
- 🔊 เสียงบรรยากาศต่อสภาพอากาศ (ถ้าใส่ลิงก์) ปรับระดับเสียงหลัก+ย่อยได้ พร้อมปุ่มพรีวิวในหน้าตั้งค่า
- 🎮 **Free Mode** — เลือกสภาพอากาศเองจากดรอปดาวน์ ไม่ต้องพึ่ง AI
- 🪶 Lite Mode สำหรับมือถือรุ่นเก่า/เครื่องช้า
- 🌐 สลับภาษาอังกฤษ/ไทยได้
- 📱 เรนเดอร์ปลอดภัยบนมือถือ
- 🔁 ซิงก์ตรงเสมอ — เคลียร์/อัปเดตอัตโนมัติเมื่อมีการลบ/รีเจน/แก้ไข/สวมข้อความ

## 📦 วิธีติดตั้ง

1. เปิด SillyTavern → ไปที่ **Extensions** (ไอคอนรูป 3 กล่อง) → **Install extension**
2. วางลิงก์ repo:
   ```
   https://github.com/xo-nara/st-weather-overlay
   ```
3. กด **Install** แล้ว reload หน้าเว็บ
4. เปิดเมนู **Extensions** → ควรเห็น **🌦 Ambient Weather Overlay** เปิดเข้าไปเช็คว่า **Enabled** ติ๊กอยู่

## 🚀 วิธีใช้งาน

### แบบ A — โหมดอัตโนมัติ (ให้ AI ควบคุม)

**ใช้ Preset/เจลเบรก Gemini Omega 3.0 อยู่แล้ว?** แค่เปิดโมดูลที่มีอยู่แล้วในนั้น ไม่ต้องก็อป prompt เพิ่ม:
👇 **Fun Mode** (โหมดสนุกๆ) → 🌨️──Weather Simulation (จำลองบรรยากาศ)

**ใช้ Preset หรือตัวละครอื่น?** ก็อปชุดนี้ไปวางใน **Description** หรือ **System Prompt** ของตัวละครนั้นแทน:

```
<wx_emit>
At the very END of every response, {{char}} must output ONE line using ONLY this vocabulary, derived from the scene's real weather + hour. No prose, nothing else:

[wx: {none|rain|storm|snow} {light|heavy} {calm|breezy|strong} {dawn|day|dusk|night}]

- Reflect ACTUAL in-scene weather + time. Indoors/no sky → precip=none, wind=calm, but still give the correct light (dawn/day/dusk/night).
- State only — never mention it in narrative, never let characters react to it.
</wx_emit>
```

(ถ้าอยากให้สะอาด) เพิ่ม Regex (Alter Chat Display only) เพื่อซ่อนแท็กจากหน้าแชท:
- Find: `\[wx:[^\]]*\]`
- Replace: *(เว้นว่าง)*

### แบบ B — Free Mode (กำหนดเองล้วน ไม่ต้องพึ่ง AI)
1. เปิดหน้าตั้งค่า Extension → เปิด toggle **Free Mode**
2. จะมีดรอปดาวน์ 4 ตัวโผล่มา (ฝน/หิมะ, ความหนัก, ลม, ช่วงเวลา) — เลือกอะไรก็ apply ทันที
3. ปิด Free Mode เพื่อคืนการควบคุมให้ AI

## ⚙️ ภาพรวมการตั้งค่า

| การตั้งค่า | ทำอะไร |
|---|---|
| Enabled | เปิด/ปิดทั้งระบบ |
| Force animations | บังคับข้ามการตั้งค่าลดการเคลื่อนไหวของเครื่อง |
| Lite Mode | ลด particle ~35% ตัด blur — ลื่นขึ้นบนเครื่องรุ่นเก่า |
| Free Mode | ควบคุมสภาพอากาศเอง (ดูด้านบน) |
| Debug logging | log ละเอียดลง console เผื่อแก้ปัญหา |
| Master Volume | ระดับเสียงหลักของทุกสภาพอากาศ |
| ลิงก์เสียงต่อสภาพอากาศ | ใส่ลิงก์ตรง `.mp3`/`.ogg`/`.wav` — ตัวปรับเสียงย่อยจะโผล่เองเมื่อตรวจพบลิงก์ |
| Particle Speed | ตัวคูณความเร็วรวมของฝน/หิมะ/ลม |
| Test Weather | พรีวิว 10 สภาพอากาศได้ทันที |
| Reload | บังคับซิงก์กับข้อความล่าสุด |

## 🙏 เครดิต
Contributor: xo.nara, Claude · Tester: zealllll
