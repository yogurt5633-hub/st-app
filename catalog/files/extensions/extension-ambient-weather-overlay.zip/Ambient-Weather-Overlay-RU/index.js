/* ===========================================================================
 * Ambient Weather Overlay — SillyTavern UI extension  v5.2
 * Contributor: xo.nara, Claude · Tester: zealllll
 * - reads [wx: precip intensity wind light] (or legacy <wx>...</wx>) from the
 *   last chat message and paints a full-screen FX layer + optional ambient audio.
 * - per-weather audio URLs + master/per-slot volume, persisted via extensionSettings.
 * - effect always re-syncs to the CURRENT last message (delete/regenerate/edit/swipe safe).
 * - v5.1: fixed particle position bias + wind-gust "parked" flash, added a universal
 *   particle-speed control, EN/TH language switch (default EN), toggle-switch UI,
 *   lite-mode / debug-log options, and an About/Contributors footer.
 * - v5.2: removed the RPG Companion sync option (unrelated to this extension's use
 *   case), simplified the About footer to plain centered text (no card/box).
 * - v5.3: fixed the real root cause of "effect doesn't clear on delete/regenerate" —
 *   requestResync() nulled lastWeatherKey before calling onMsg(), which made the
 *   "clear" branch's own lastWeatherKey-guard always false, so it silently never ran.
 *   Clear/stop are now unconditional (idempotent) instead of gated on that flag.
 *   Also: hardened auto-resync further (faster 1200ms poll, wider MutationObserver,
 *   click-delegation on #chat), added an autoplay-policy retry so assigned audio
 *   actually starts on the next tap/keypress instead of staying silently blocked,
 *   and made Lite mode noticeably lighter (~35% of normal particle count, no blur).
 * - v5.4: added Free Mode — a manual-control toggle. While on, the "Test Weather"
 *   section is replaced by four dropdowns (precipitation/intensity/wind/time) that
 *   apply instantly and persist; the chat-driven auto-sync is fully paused (onMsg
 *   early-returns) so nothing from the AI's messages can override the manual pick.
 *   Turning it back off resumes normal chat-tag syncing immediately.
 * - v5.5: fixed wind gusts only checking wind==='strong' — picking "Breezy" produced
 *   no gust particles at all. Breezy now reuses the same gust effect, just lighter:
 *   fewer streaks (2 vs 3), slower/less frequent, thinner, and fainter than Strong.
 * - v5.6: same fix for the wind AUDIO layer — playWind() only checked 'strong' too, so
 *   Breezy had no wind sound at all. Breezy now plays the same wind_strong track at
 *   half volume; switching strong<->breezy while it's already playing retargets the
 *   fade in place instead of restarting the track.
 * =========================================================================== */

(function () {
  'use strict';

  const MODULE_NAME  = 'ambientWeatherOverlay';
  const OVERLAY_ID   = 'wx-overlay';
  const EXT_VERSION  = '5.6';

  /* ══════════════════════════ i18n ══════════════════════════ */
  const I18N = {
    en: {
      "sec_general": "Общие настройки",
      "enabled_ttl": "Включено",
      "enabled_sub": "Включить или выключить все эффекты",
      "force_ttl": "Принудительная анимация",
      "force_sub": "Игнорировать настройку уменьшения движения устройства",
      "lite_ttl": "Лёгкий режим",
      "lite_sub": "Меньше частиц — плавнее на старых телефонах",
      "debug_ttl": "Журнал отладки",
      "debug_sub": "Подробные записи в консоли браузера",
      "free_ttl": "Свободный режим (ручное управление)",
      "free_sub": "Выбирайте погоду сами, независимо от сообщений ИИ",
      "sec_volume": "Общая громкость",
      "doc": "Как добавить звук: найдите прямую ссылку на аудиофайл <code>.mp3</code> / <code>.ogg</code> / <code>.wav</code> (например, загрузите файл на catbox.moe и скопируйте ссылку), затем вставьте её в поле нужной погоды ниже. <b>Пустое поле = тишина.</b> После ввода ссылки появится ползунок громкости. Нажмите ▶ для прослушивания. Воспроизведение начнётся после первого касания или сообщения из-за правил браузера.",
      "sec_speed": "Скорость всех частиц",
      "speed_sub": "Влияет на дождь, снег и порывы ветра",
      "sec_test": "Проверка погоды",
      "reload_btn": "↻ Обновить — синхронизировать с последним сообщением",
      "sec_manual": "Ручное управление погодой",
      "manual_hint": "Свободный режим включён: настройки ниже применяются сразу. Сообщения чата их не заменяют.",
      "lbl_precip": "Осадки",
      "lbl_intensity": "Интенсивность",
      "lbl_wind": "Ветер",
      "lbl_light": "Время суток",
      "opt_precip_none": "Нет (ясно)",
      "opt_precip_rain": "Дождь",
      "opt_precip_storm": "Гроза",
      "opt_precip_snow": "Снег",
      "opt_intensity_light": "Слабые",
      "opt_intensity_heavy": "Сильные",
      "opt_wind_calm": "Штиль",
      "opt_wind_breezy": "Лёгкий ветер",
      "opt_wind_strong": "Сильный ветер",
      "opt_light_dawn": "Рассвет",
      "opt_light_day": "День",
      "opt_light_dusk": "Сумерки",
      "opt_light_night": "Ночь",
      "reset_link": "Сбросить все настройки",
      "reset_confirm": "Сбросить все настройки Ambient Weather Overlay, включая ссылки на звук?",
      "status_ready": "Готово ✓ — ожидание сообщения…",
      "status_nomsg": "В чате нет сообщений",
      "status_last": "Последнее:",
      "status_notag": "Последнее: тег погоды не найден",
      "status_reset": "Настройки сброшены",
      "status_reloaded": "Обновлено — синхронизировано с последним сообщением",
      "status_test": "ПРОВЕРКА:",
      "status_manual": "Вручную:",
      "status_cleared": "Эффекты убраны",
      "err_need_url": "Сначала введите ссылку",
      "err_bad_url": "Нужна ссылка, начинающаяся с http(s)://",
      "err_load_fail": "Не удалось загрузить — проверьте ссылку",
      "err_autoplay": "Воспроизведение заблокировано — сначала коснитесь экрана"
},
    th: {
      sec_general: '\u0e17\u0e31\u0e48\u0e27\u0e44\u0e1b',
      enabled_ttl: '\u0e40\u0e1b\u0e34\u0e14\u0e43\u0e0a\u0e49\u0e07\u0e32\u0e19', enabled_sub: '\u0e40\u0e1b\u0e34\u0e14/\u0e1b\u0e34\u0e14\u0e01\u0e32\u0e23\u0e41\u0e2a\u0e14\u0e07\u0e1c\u0e25\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14',
      force_ttl: '\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e2d\u0e19\u0e34\u0e40\u0e21\u0e0a\u0e31\u0e19', force_sub: '\u0e02\u0e49\u0e32\u0e21\u0e01\u0e32\u0e23\u0e15\u0e31\u0e49\u0e07\u0e04\u0e48\u0e32\u0e25\u0e14\u0e01\u0e32\u0e23\u0e40\u0e04\u0e25\u0e37\u0e48\u0e2d\u0e19\u0e44\u0e2b\u0e27\u0e02\u0e2d\u0e07\u0e40\u0e04\u0e23\u0e37\u0e48\u0e2d\u0e07',
      lite_ttl: '\u0e42\u0e2b\u0e21\u0e14\u0e1b\u0e23\u0e30\u0e2b\u0e22\u0e31\u0e14', lite_sub: '\u0e25\u0e14\u0e08\u0e33\u0e19\u0e27\u0e19\u0e1e\u0e32\u0e23\u0e4c\u0e17\u0e34\u0e40\u0e01\u0e34\u0e25 \u0e25\u0e37\u0e48\u0e19\u0e02\u0e36\u0e49\u0e19\u0e1a\u0e19\u0e40\u0e04\u0e23\u0e37\u0e48\u0e2d\u0e07\u0e23\u0e38\u0e48\u0e19\u0e40\u0e01\u0e48\u0e32',
      debug_ttl: '\u0e1a\u0e31\u0e19\u0e17\u0e36\u0e01\u0e25\u0e47\u0e2d\u0e01\u0e14\u0e35\u0e1a\u0e31\u0e01', debug_sub: '\u0e1e\u0e34\u0e21\u0e1e\u0e4c\u0e25\u0e47\u0e2d\u0e01\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e25\u0e07 console \u0e02\u0e2d\u0e07\u0e40\u0e1a\u0e23\u0e32\u0e27\u0e4c\u0e40\u0e0b\u0e2d\u0e23\u0e4c',
      free_ttl: '\u0e42\u0e2b\u0e21\u0e14\u0e2d\u0e34\u0e2a\u0e23\u0e30 (\u0e04\u0e27\u0e1a\u0e04\u0e38\u0e21\u0e40\u0e2d\u0e07)', free_sub: '\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e2a\u0e20\u0e32\u0e1e\u0e2d\u0e32\u0e01\u0e32\u0e28\u0e40\u0e2d\u0e07 \u0e44\u0e21\u0e48\u0e15\u0e49\u0e2d\u0e07\u0e23\u0e2d AI \u0e40\u0e08\u0e19\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21',
      sec_volume: '\u0e23\u0e30\u0e14\u0e31\u0e1a\u0e40\u0e2a\u0e35\u0e22\u0e07\u0e2b\u0e25\u0e31\u0e01',
      doc: '\u0e27\u0e34\u0e18\u0e35\u0e43\u0e2a\u0e48\u0e40\u0e2a\u0e35\u0e22\u0e07: \u0e2b\u0e32 URL \u0e44\u0e1f\u0e25\u0e4c\u0e40\u0e2a\u0e35\u0e22\u0e07\u0e42\u0e14\u0e22\u0e15\u0e23\u0e07 \u0e25\u0e07\u0e17\u0e49\u0e32\u0e22 <code>.mp3</code> / <code>.ogg</code> / <code>.wav</code> (\u0e40\u0e0a\u0e48\u0e19\u0e2d\u0e31\u0e1b\u0e42\u0e2b\u0e25\u0e14\u0e17\u0e35\u0e48 catbox.moe \u0e41\u0e25\u0e49\u0e27\u0e04\u0e31\u0e14\u0e25\u0e2d\u0e01\u0e25\u0e34\u0e07\u0e01\u0e4c) \u0e27\u0e32\u0e07\u0e43\u0e19\u0e0a\u0e48\u0e2d\u0e07\u0e02\u0e2d\u0e07\u0e41\u0e15\u0e48\u0e25\u0e30\u0e2a\u0e20\u0e32\u0e1e\u0e2d\u0e32\u0e01\u0e32\u0e28\u0e14\u0e49\u0e32\u0e19\u0e25\u0e48\u0e32\u0e07 \u2014 <b>\u0e27\u0e48\u0e32\u0e07 = \u0e44\u0e21\u0e48\u0e21\u0e35\u0e40\u0e2a\u0e35\u0e22\u0e07</b> \u0e15\u0e31\u0e27\u0e40\u0e25\u0e37\u0e48\u0e2d\u0e19\u0e23\u0e30\u0e14\u0e31\u0e1a\u0e40\u0e2a\u0e35\u0e22\u0e07\u0e22\u0e48\u0e2d\u0e22\u0e08\u0e30\u0e42\u0e1c\u0e25\u0e48\u0e40\u0e2d\u0e07\u0e40\u0e21\u0e37\u0e48\u0e2d\u0e15\u0e23\u0e27\u0e08\u0e1e\u0e1a\u0e25\u0e34\u0e07\u0e01\u0e4c \u0e01\u0e14 \u25b6 \u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e1e\u0e23\u0e35\u0e27\u0e34\u0e27\u0e01\u0e48\u0e2d\u0e19\u0e40\u0e0b\u0e1f\u0e44\u0e14\u0e49 \u0e40\u0e2a\u0e35\u0e22\u0e07\u0e08\u0e23\u0e34\u0e07\u0e08\u0e30\u0e40\u0e23\u0e34\u0e48\u0e21\u0e40\u0e25\u0e48\u0e19\u0e2b\u0e25\u0e31\u0e07\u0e41\u0e15\u0e30\u0e2b\u0e19\u0e49\u0e32\u0e08\u0e2d/\u0e2a\u0e48\u0e07\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21\u0e04\u0e23\u0e31\u0e49\u0e07\u0e41\u0e23\u0e01',
      sec_speed: '\u0e04\u0e27\u0e32\u0e21\u0e40\u0e23\u0e47\u0e27\u0e02\u0e2d\u0e07\u0e1e\u0e32\u0e23\u0e4c\u0e17\u0e34\u0e40\u0e01\u0e34\u0e25 (\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14)', speed_sub: '\u0e21\u0e35\u0e1c\u0e25\u0e01\u0e31\u0e1a\u0e1d\u0e19 \u0e2b\u0e34\u0e21\u0e30 \u0e41\u0e25\u0e30\u0e25\u0e21\u0e01\u0e23\u0e30\u0e42\u0e0a\u0e01',
      sec_test: '\u0e17\u0e14\u0e2a\u0e2d\u0e1a\u0e2a\u0e20\u0e32\u0e1e\u0e2d\u0e32\u0e01\u0e32\u0e28',
      reload_btn: '\u21bb Reload \u2014 \u0e0b\u0e34\u0e07\u0e01\u0e4c\u0e01\u0e31\u0e1a\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21\u0e25\u0e48\u0e32\u0e2a\u0e38\u0e14',
      sec_manual: '\u0e04\u0e27\u0e1a\u0e04\u0e38\u0e21\u0e2a\u0e20\u0e32\u0e1e\u0e2d\u0e32\u0e01\u0e32\u0e28\u0e40\u0e2d\u0e07',
      manual_hint: '\u0e42\u0e2b\u0e21\u0e14\u0e2d\u0e34\u0e2a\u0e23\u0e30\u0e40\u0e1b\u0e34\u0e14\u0e2d\u0e22\u0e39\u0e48 \u2014 \u0e40\u0e25\u0e37\u0e2d\u0e01\u0e04\u0e48\u0e32\u0e14\u0e49\u0e32\u0e19\u0e25\u0e48\u0e32\u0e07\u0e41\u0e25\u0e49\u0e27\u0e21\u0e35\u0e1c\u0e25\u0e17\u0e31\u0e19\u0e17\u0e35 \u0e08\u0e30\u0e44\u0e21\u0e48\u0e21\u0e35\u0e2d\u0e30\u0e44\u0e23\u0e08\u0e32\u0e01\u0e41\u0e0a\u0e15\u0e21\u0e32\u0e17\u0e31\u0e1a',
      lbl_precip: '\u0e1d\u0e19/\u0e2b\u0e34\u0e21\u0e30', lbl_intensity: '\u0e04\u0e27\u0e32\u0e21\u0e2b\u0e19\u0e31\u0e01', lbl_wind: '\u0e25\u0e21', lbl_light: '\u0e0a\u0e48\u0e27\u0e07\u0e40\u0e27\u0e25\u0e32',
      opt_precip_none: '\u0e44\u0e21\u0e48\u0e21\u0e35 (\u0e1f\u0e49\u0e32\u0e42\u0e25\u0e48\u0e07)', opt_precip_rain: '\u0e1d\u0e19', opt_precip_storm: '\u0e1e\u0e32\u0e22\u0e38', opt_precip_snow: '\u0e2b\u0e34\u0e21\u0e30',
      opt_intensity_light: '\u0e40\u0e1a\u0e32', opt_intensity_heavy: '\u0e2b\u0e19\u0e31\u0e01',
      opt_wind_calm: '\u0e2a\u0e07\u0e1a', opt_wind_breezy: '\u0e25\u0e21\u0e42\u0e0a\u0e22', opt_wind_strong: '\u0e41\u0e23\u0e07',
      opt_light_dawn: '\u0e23\u0e38\u0e48\u0e07\u0e2d\u0e23\u0e38\u0e13', opt_light_day: '\u0e01\u0e25\u0e32\u0e07\u0e27\u0e31\u0e19', opt_light_dusk: '\u0e1e\u0e25\u0e1a\u0e04\u0e48\u0e33', opt_light_night: '\u0e01\u0e25\u0e32\u0e07\u0e04\u0e37\u0e19',
      reset_link: '\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15\u0e01\u0e32\u0e23\u0e15\u0e31\u0e49\u0e07\u0e04\u0e48\u0e32\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14',
      reset_confirm: '\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15\u0e01\u0e32\u0e23\u0e15\u0e31\u0e49\u0e07\u0e04\u0e48\u0e32 Ambient Weather Overlay \u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14 (\u0e23\u0e27\u0e21 URL \u0e40\u0e2a\u0e35\u0e22\u0e07) ?',
      status_ready: '\u0e1e\u0e23\u0e49\u0e2d\u0e21\u0e43\u0e0a\u0e49\u0e07\u0e32\u0e19 \u2713 \u2014 \u0e01\u0e33\u0e25\u0e31\u0e07\u0e23\u0e2d\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21\u2026',
      status_nomsg: '\u0e44\u0e21\u0e48\u0e21\u0e35\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21\u0e43\u0e19\u0e41\u0e0a\u0e15',
      status_last: '\u0e25\u0e48\u0e32\u0e2a\u0e38\u0e14:',
      status_notag: '\u0e25\u0e48\u0e32\u0e2a\u0e38\u0e14: \u0e44\u0e21\u0e48\u0e1e\u0e1a\u0e41\u0e17\u0e47\u0e01\u0e2a\u0e20\u0e32\u0e1e\u0e2d\u0e32\u0e01\u0e32\u0e28',
      status_reset: '\u0e23\u0e35\u0e40\u0e0b\u0e47\u0e15\u0e04\u0e48\u0e32\u0e40\u0e23\u0e34\u0e48\u0e21\u0e15\u0e49\u0e19\u0e41\u0e25\u0e49\u0e27',
      status_reloaded: '\u0e23\u0e35\u0e42\u0e2b\u0e25\u0e14\u0e41\u0e25\u0e49\u0e27 \u2014 \u0e0b\u0e34\u0e07\u0e01\u0e4c\u0e01\u0e31\u0e1a\u0e02\u0e49\u0e2d\u0e04\u0e27\u0e32\u0e21\u0e25\u0e48\u0e32\u0e2a\u0e38\u0e14',
      status_test: 'TEST:',
      status_manual: '\u0e01\u0e33\u0e2b\u0e19\u0e14\u0e40\u0e2d\u0e07:',
      status_cleared: '\u0e40\u0e04\u0e25\u0e35\u0e22\u0e23\u0e4c\u0e41\u0e25\u0e49\u0e27',
      err_need_url: '\u0e43\u0e2a\u0e48 URL \u0e01\u0e48\u0e2d\u0e19',
      err_bad_url: '\u0e04\u0e27\u0e23\u0e40\u0e1b\u0e47\u0e19 URL \u0e17\u0e35\u0e48\u0e02\u0e36\u0e49\u0e19\u0e15\u0e49\u0e19\u0e14\u0e49\u0e27\u0e22 http(s)://',
      err_load_fail: '\u0e42\u0e2b\u0e25\u0e14\u0e44\u0e21\u0e48\u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08 \u2014 \u0e40\u0e0a\u0e47\u0e01 URL',
      err_autoplay: '\u0e40\u0e25\u0e48\u0e19\u0e44\u0e21\u0e48\u0e44\u0e14\u0e49 \u2014 \u0e25\u0e2d\u0e07\u0e41\u0e15\u0e30\u0e2b\u0e19\u0e49\u0e32\u0e08\u0e2d\u0e01\u0e48\u0e2d\u0e19',
    },
  };
  function LANG() { return (S().lang === 'th') ? 'th' : 'en'; }
  function t(key) { const l = LANG(); return (I18N[l] && I18N[l][key]) || I18N.en[key] || key; }
  function bi(obj) { return obj[LANG()] || obj.en; } // bilingual label object -> current-language string

  /* ── audio slot definitions (icon + bilingual label) ── */
  const AUDIO_KEYS = [
    ['rain_light',  '🌦️', { en:"Слабый дождь", th:'\u0e1d\u0e19\u0e1b\u0e23\u0e2d\u0e22' }],
    ['rain_heavy',  '🌧️', { en:"Сильный дождь", th:'\u0e1d\u0e19\u0e2b\u0e19\u0e31\u0e01' }],
    ['storm',       '⛈️', { en:"Гроза", th:'\u0e1e\u0e32\u0e22\u0e38' }],
    ['snow',        '❄️', { en:"Снег", th:'\u0e2b\u0e34\u0e21\u0e30' }],
    ['wind_strong', '💨', { en:"Сильный ветер (дополнительный звук)", th:'\u0e25\u0e21\u0e41\u0e23\u0e07 (\u0e40\u0e25\u0e40\u0e22\u0e2d\u0e23\u0e4c\u0e17\u0e31\u0e1a\u0e40\u0e2a\u0e35\u0e22\u0e07\u0e2b\u0e25\u0e31\u0e01)' }],
    ['night',       '🌙', { en:"Ночь (ясно)", th:'\u0e01\u0e25\u0e32\u0e07\u0e04\u0e37\u0e19 (\u0e1f\u0e49\u0e32\u0e42\u0e25\u0e48\u0e07)' }],
    ['day',         '☀️', { en:"День (ясно)", th:'\u0e01\u0e25\u0e32\u0e07\u0e27\u0e31\u0e19 (\u0e1f\u0e49\u0e32\u0e42\u0e25\u0e48\u0e07)' }],
  ];

  const DEFAULTS = {
    enabled: true,
    forceMotion: true,
    liteMode: false,
    debugLog: false,
    freeMode: false,
    manual: { precip: 'none', intensity: 'light', wind: 'calm', light: 'day' },
    lang: 'en',
    masterVolume: 35,
    particleSpeed: 100,
    audio:   { rain_light:'', rain_heavy:'', storm:'', snow:'', wind_strong:'', night:'', day:'' },
    volumes: { rain_light:100, rain_heavy:100, storm:100, snow:100, wind_strong:100, night:100, day:100 },
  };

  const TEST_PRESETS = {
    day:   { icon:'☀️',  label:{ en:"День",        th:'\u0e01\u0e25\u0e32\u0e07\u0e27\u0e31\u0e19' },   st:{ precip:'none',  intensity:'light', wind:'calm',   light:'day'   } },
    dawn:  { icon:'🌅',  label:{ en:"Рассвет",       th:'\u0e23\u0e38\u0e48\u0e07\u0e2d\u0e23\u0e38\u0e13' },  st:{ precip:'none',  intensity:'light', wind:'calm',   light:'dawn'  } },
    dusk:  { icon:'🌆',  label:{ en:"Сумерки",       th:'\u0e1e\u0e25\u0e1a\u0e04\u0e48\u0e33' },   st:{ precip:'none',  intensity:'light', wind:'calm',   light:'dusk'  } },
    night: { icon:'🌙',  label:{ en:"Ночь",      th:'\u0e01\u0e25\u0e32\u0e07\u0e04\u0e37\u0e19' },  st:{ precip:'none',  intensity:'light', wind:'calm',   light:'night' } },
    windy: { icon:'💨',  label:{ en:"Ветрено",      th:'\u0e25\u0e21\u0e41\u0e23\u0e07' },     st:{ precip:'none',  intensity:'light', wind:'strong', light:'day'   } },
    rainL: { icon:'🌦️', label:{ en:"Слабый дождь", th:'\u0e1d\u0e19\u0e1b\u0e23\u0e2d\u0e22' }, st:{ precip:'rain',  intensity:'light', wind:'calm',   light:'day'   } },
    rainH: { icon:'🌧️', label:{ en:"Сильный дождь", th:'\u0e1d\u0e19\u0e2b\u0e19\u0e31\u0e01' }, st:{ precip:'rain',  intensity:'heavy', wind:'breezy', light:'night' } },
    storm: { icon:'⛈️',  label:{ en:"Гроза",      th:'\u0e1e\u0e32\u0e22\u0e38' },     st:{ precip:'storm', intensity:'heavy', wind:'strong', light:'night' } },
    snowL: { icon:'🌨️', label:{ en:"Слабый снег", th:'\u0e2b\u0e34\u0e21\u0e30\u0e40\u0e1a\u0e32' }, st:{ precip:'snow',  intensity:'light', wind:'calm',   light:'day'   } },
    snowH: { icon:'❄️',  label:{ en:"Сильный снег", th:'\u0e2b\u0e34\u0e21\u0e30\u0e2b\u0e19\u0e31\u0e01' }, st:{ precip:'snow',  intensity:'heavy', wind:'breezy', light:'night' } },
  };

  /* ── CSS injection (failsafe alongside style.css from manifest) ── */
  if (!document.getElementById('wx-style')) {
    const s = document.createElement('style'); s.id = 'wx-style';
    s.textContent = [
      '#wx-overlay{position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;pointer-events:none!important;z-index:2147483647!important;overflow:hidden!important}',
      '#wx-overlay *{pointer-events:none!important}',
      '#wx-overlay .wx-tint{position:absolute;inset:0;transition:background 1.2s ease}',
      '@keyframes wxfall{to{transform:translateY(112vh)}}',
      '@keyframes wxsnow{0%{transform:translateY(-6vh) translateX(0) rotate(0)}50%{transform:translateY(52vh) translateX(16px) rotate(180deg)}100%{transform:translateY(112vh) translateX(-8px) rotate(360deg)}}',
      '@keyframes wxgust{0%{transform:translateX(-30vw) skewX(-6deg);opacity:0}20%{opacity:.55}100%{transform:translateX(125vw) skewX(-6deg);opacity:0}}',
      '@keyframes wxray{0%,100%{opacity:.10}50%{opacity:.24}}',
      '@keyframes wxfog{0%,100%{transform:translateX(-6%);opacity:.16}50%{transform:translateX(6%);opacity:.30}}',
      /* ── settings panel ── */
      '.wx-panel .wx-section{background:#1c1e24;border:1px solid #333844;border-radius:10px;padding:10px 12px;margin-top:8px}',
      '.wx-panel .wx-sectitle{font-size:.8em;opacity:.7;letter-spacing:.4px;margin-bottom:7px;text-transform:uppercase}',
      '.wx-doc{font-size:.82em;line-height:1.65;opacity:.85;background:#14161a;border-radius:8px;padding:8px 10px;margin-bottom:8px}',
      '.wx-doc code{background:#000;padding:1px 5px;border-radius:4px;color:#9fd0ff}',
      '.wx-row{display:flex;align-items:center;gap:8px;margin:6px 0}',
      '.wx-row .lbl{font-size:.85em;min-width:34px;text-align:right;opacity:.8}',
      '.wx-row input[type=range]{flex:1;accent-color:#7aa2e3}',
      '.wx-audiorow{padding:8px 0;border-top:1px solid #2a2e38}',
      '.wx-audiorow:first-child{border-top:none;padding-top:2px}',
      '.wx-audiorow .top{display:flex;align-items:center;gap:6px}',
      '.wx-audiorow .name{font-size:.85em;min-width:150px;flex-shrink:0}',
      '.wx-audiorow input[type=text]{flex:1;min-width:0;background:#0e0f13;border:1px solid #333844;border-radius:6px;color:#ddd;padding:5px 8px;font-size:.82em}',
      '.wx-audiorow button.prev{flex-shrink:0;background:#262a33;border:1px solid #3a3f4b;border-radius:6px;color:#ddd;padding:5px 10px;cursor:pointer;font-size:.8em}',
      '.wx-audiorow button.prev:active{transform:scale(.94)}',
      '.wx-volrow{display:none;align-items:center;gap:8px;margin-top:5px;padding-left:2px}',
      '.wx-volrow.show{display:flex}',
      '.wx-volrow input[type=range]{flex:1;accent-color:#7aa2e3}',
      '.wx-volrow .vlbl{font-size:.78em;color:#9aa0ac;width:38px;text-align:right}',
      '.wx-err{color:#e07a7a;font-size:.75em;margin-top:3px;min-height:1.1em}',
      '.wx-testgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(72px,1fr));gap:6px}',
      '.wx-testbtn{display:flex;flex-direction:column;align-items:center;gap:2px;padding:8px 4px;border-radius:9px;border:1px solid #3a3f4b;background:#20232b;color:#ddd;cursor:pointer;font-size:.76em}',
      '.wx-testbtn:active{transform:scale(.95);background:#2a2e38}',
      '.wx-testbtn .ic{font-size:1.35em;line-height:1}',
      '.wx-reloadbtn{width:100%;padding:10px;border-radius:9px;border:1px solid #5a7ab0;background:linear-gradient(135deg,#3a4a6b,#2a3550);color:#e2ecff;font-weight:600;cursor:pointer;margin-bottom:8px;font-size:.9em}',
      '.wx-reloadbtn:active{transform:scale(.98)}',
      '.wx-resetlink{font-size:.78em;opacity:.6;text-decoration:underline;cursor:pointer;display:inline-block;margin-top:8px}',
      '.wx-langsel{width:100%;background:#0e0f13;border:1px solid #333844;color:#ddd;border-radius:6px;padding:7px 8px;font-size:.9em}',
      /* toggle switch */
      '.wx-toggle-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:7px 0}',
      '.wx-toggle-row+.wx-toggle-row{border-top:1px solid #2a2e38}',
      '.wx-toggle-row .txt{flex:1;min-width:0}',
      '.wx-toggle-row .ttl{font-weight:600;font-size:.9em}',
      '.wx-toggle-row .sub{font-size:.76em;opacity:.6;margin-top:2px;line-height:1.4}',
      '.wx-switch{position:relative;display:inline-block;width:44px;height:25px;flex-shrink:0}',
      '.wx-switch input{opacity:0;width:0;height:0;position:absolute}',
      '.wx-switch .sl{position:absolute;cursor:pointer;inset:0;background:#3a3f4b;transition:.2s;border-radius:999px}',
      '.wx-switch .sl:before{content:"";position:absolute;height:19px;width:19px;left:3px;top:3px;background:#eee;transition:.2s;border-radius:50%;box-shadow:0 1px 3px #0006}',
      '.wx-switch input:checked+.sl{background:#d4af37}',
      '.wx-switch input:checked+.sl:before{transform:translateX(19px);background:#fff}',
    ].join('\n');
    document.head.appendChild(s);
  }

  /* --- context + settings accessors (fresh every call — never cache!) --- */
  function C() { try { return SillyTavern.getContext(); } catch (e) { return null; } }
  function S() {
    const ctx = C();
    if (!ctx) return DEFAULTS;
    if (!ctx.extensionSettings) ctx.extensionSettings = {};
    const all = ctx.extensionSettings;
    if (!all[MODULE_NAME]) all[MODULE_NAME] = JSON.parse(JSON.stringify(DEFAULTS));
    const s = all[MODULE_NAME];
    for (const k in DEFAULTS) if (!(k in s)) s[k] = JSON.parse(JSON.stringify(DEFAULTS[k]));
    if (!s.audio) s.audio = {};
    if (!s.volumes) s.volumes = {};
    if (!s.manual) s.manual = JSON.parse(JSON.stringify(DEFAULTS.manual));
    for (const k in DEFAULTS.audio) if (!(k in s.audio)) s.audio[k] = '';
    for (const k in DEFAULTS.volumes) if (!(k in s.volumes)) s.volumes[k] = 100;
    for (const k in DEFAULTS.manual) if (!(k in s.manual)) s.manual[k] = DEFAULTS.manual[k];
    return s;
  }
  function saveS() { const ctx = C(); try { ctx && ctx.saveSettingsDebounced && ctx.saveSettingsDebounced(); } catch (e) {} }
  function dlog() { if (S().debugLog) console.log.apply(console, ['[wx-overlay]'].concat(Array.prototype.slice.call(arguments))); }

  let lastWeatherKey = null;
  let testModeUntil = 0; // while Date.now() < this, auto-resync pauses so a Test-button preview stays visible
  const reducedMotion = () => !S().forceMotion && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const el = (css) => { const d = document.createElement('div'); d.style.cssText = css; return d; };
  const setStatus = (t) => { const s = document.getElementById('aw_status'); if (s) s.textContent = t; };

  function clearOverlay() {
    const o = document.getElementById(OVERLAY_ID);
    if (o) { if (o._t) o._t.forEach(clearInterval); o.remove(); }
  }

  /* ── uniform-coverage particle placement (fixes L/R clumping on small N) ──
     Splits 0-100% into N equal bins and jitters one point per bin, so rain/snow
     can never randomly bunch onto one half of the screen the way pure
     Math.random()*100 occasionally does with small sample sizes. */
  function stratifiedPositions(n) {
    const out = []; const bw = 100 / n;
    for (let i = 0; i < n; i++) out.push(Math.min(99, bw * i + Math.random() * bw));
    return out;
  }
  /* universal particle-speed multiplier: 100=normal, 200=2x faster (shorter dur), 50=half speed */
  function speedMul() { const v = S().particleSpeed; return 100 / (v || 100); }

  /* ── volume math: effective = master% × slot% ── */
  function volFor(key) {
    const s = S();
    const mv = (s.masterVolume != null ? s.masterVolume : 35) / 100;
    const sv = (s.volumes[key] != null ? s.volumes[key] : 100) / 100;
    return Math.max(0, Math.min(1, mv * sv));
  }

  /* ── audio engine: one looping bed + a separate wind layer, soft fades ── */
  let curKey = null, curEl = null, windEl = null;
  function fadeTo(a, target, ms) {
    if (!a) return; const step = (target - a.volume) / (ms / 60);
    const iv = setInterval(() => {
      let v = a.volume + step;
      if ((step > 0 && v >= target) || (step < 0 && v <= target)) { a.volume = Math.max(0, Math.min(1, target)); clearInterval(iv); if (target === 0) a.pause(); }
      else a.volume = Math.max(0, Math.min(1, v));
    }, 60);
  }
  function playKey(key) {
    if (curKey === key) return;
    if (curEl) { fadeTo(curEl, 0, 900); curEl = null; }
    curKey = key;
    const url = (S().audio[key] || '').trim(); if (!url) return;
    const a = new Audio(url); a.loop = true; a.volume = 0;
    a.addEventListener('error', () => console.warn('[wx-overlay] audio failed to load:', key, url));
    a.play().then(() => fadeTo(a, volFor(key), 1200)).catch(() => {});
    curEl = a;
  }
  /* wind audio volume: strong = full, breezy = quieter layer of the same track */
  function windVolume() {
    const mul = (windEl && windEl._mul) || 1;
    return volFor('wind_strong') * mul;
  }
  function playWind(windState) {
    const on = windState === 'strong' || windState === 'breezy';
    const mul = windState === 'strong' ? 1 : 0.5;
    const url = (S().audio.wind_strong || '').trim();
    if (on && url) {
      if (!windEl) {
        const a = new Audio(url); a.loop = true; a.volume = 0; a._mul = mul;
        a.addEventListener('error', () => console.warn('[wx-overlay] wind audio failed to load'));
        a.play().then(() => fadeTo(a, volFor('wind_strong') * mul, 1200)).catch(() => {});
        windEl = a;
      } else if (windEl._mul !== mul) {
        windEl._mul = mul; // e.g. strong -> breezy while already playing: retarget the fade, don't restart the track
        fadeTo(windEl, windVolume(), 700);
      }
    } else if (!on && windEl) { fadeTo(windEl, 0, 900); windEl = null; }
  }
  function stopAudio() { if (curEl) fadeTo(curEl, 0, 600); if (windEl) fadeTo(windEl, 0, 600); curEl = windEl = null; curKey = null; }
  function pickAudio(st) {
    if (!S().enabled) return stopAudio();
    playWind(st.wind);
    if (st.precip === 'storm') return playKey('storm');
    if (st.precip === 'rain') return playKey(st.intensity === 'heavy' ? 'rain_heavy' : 'rain_light');
    if (st.precip === 'snow') return playKey('snow');
    playKey(st.light === 'night' ? 'night' : 'day');
  }

  /* ── autoplay-policy fix ──
     Browsers block audio.play() until a genuine user gesture has occurred on the page.
     When a weather track gets assigned before that gesture, play() is silently rejected —
     the <audio> sits paused at volume 0 forever with no visible error ("doesn't autoplay").
     Retry on every subsequent tap/keypress so it starts (with its normal fade-in) the moment
     the browser allows it, with no action needed from the user beyond using the chat. */
  function retryBlockedAudio() {
    if (curEl && curEl.paused) curEl.play().then(() => fadeTo(curEl, volFor(curKey), 800)).catch(() => {});
    if (windEl && windEl.paused) windEl.play().then(() => fadeTo(windEl, windVolume(), 800)).catch(() => {});
  }
  ['pointerdown', 'keydown'].forEach((evt) => document.addEventListener(evt, retryBlockedAudio, { capture: true, passive: true }));

  /* ── preview player (settings panel "▶" button) — independent of the main engine ── */
  let previewEl = null, previewKey = null;
  function previewToggle(key, url, btn, errSpan) {
    if (previewEl && previewKey === key) { previewEl.pause(); previewEl = null; previewKey = null; btn.textContent = '▶'; return; }
    if (previewEl) { previewEl.pause(); previewEl = null; previewKey = null; }
    if (!url) { errSpan.textContent = t('err_need_url'); return; }
    errSpan.textContent = '';
    const a = new Audio(url);
    a.volume = volFor(key);
    a.addEventListener('error', () => { errSpan.textContent = t('err_load_fail'); btn.textContent = '▶'; previewEl = null; previewKey = null; });
    a.addEventListener('ended', () => { btn.textContent = '▶'; previewEl = null; previewKey = null; });
    a.play().then(() => { btn.textContent = '⏹'; }).catch(() => { errSpan.textContent = t('err_autoplay'); });
    previewEl = a; previewKey = key;
    setTimeout(() => { if (previewEl === a) { a.pause(); btn.textContent = '▶'; previewEl = null; previewKey = null; } }, 6000);
  }

  /* ── painter ── */
  function paint(st) {
    dlog('paint() \u2192', JSON.stringify(st));
    clearOverlay();
    if (!S().enabled) { stopAudio(); return; }

    try {
      const o = document.createElement('div');
      o.id = OVERLAY_ID;
      o._t = [];
      // MOBILE FIX: mount on <html>, NOT body — a transformed/filtered ancestor on
      // mobile would otherwise capture position:fixed and shrink/clip the overlay.
      (document.documentElement || document.body).appendChild(o);

      o.style.setProperty('position', 'fixed', 'important');
      o.style.setProperty('top', '0', 'important');
      o.style.setProperty('left', '0', 'important');
      o.style.setProperty('width', '100vw', 'important');
      o.style.setProperty('height', '100vh', 'important');
      o.style.setProperty('height', '100dvh', 'important');
      o.style.setProperty('z-index', '2147483647', 'important');
      o.style.setProperty('pointer-events', 'none', 'important');
      o.style.setProperty('overflow', 'hidden', 'important');

      try {
        const r = o.getBoundingClientRect();
        const full = (r.width >= window.innerWidth - 2 && r.height >= window.innerHeight - 2);
        setStatus('overlay ' + Math.round(r.width) + '\u00d7' + Math.round(r.height) + (full ? ' \u2713 full' : ' \u26a0 clipped!'));
      } catch (e) {}

      const { precip, intensity, wind, light } = st;
      const lite = !!S().liteMode;
      const spd = speedMul();

      const tint = el('position:absolute;inset:0;transition:background 1.2s ease');
      tint.className = 'wx-tint';
      tint.style.background =
        light === 'night' ? 'radial-gradient(130% 100% at 50% 0%, transparent 40%, rgba(4,7,22,.55))'
        : light === 'dusk' ? 'linear-gradient(180deg, rgba(70,25,12,.14), transparent 55%)'
        : light === 'dawn' ? 'linear-gradient(180deg, rgba(255,208,138,.15), transparent 58%)'
        : 'transparent';
      o.appendChild(tint);

      pickAudio(st);

      if (reducedMotion()) { dlog('reduced-motion — skip particles'); return; }

      const skew = wind === 'strong' ? 'skewX(-16deg)' : wind === 'breezy' ? 'skewX(-7deg)' : '';
      let pc = 0;

      if (precip === 'rain' || precip === 'storm') {
        let far = intensity === 'heavy' ? 14 : 8;
        let near = intensity === 'heavy' ? 10 : 6;
        if (lite) { far = Math.max(2, Math.round(far / 3)); near = Math.max(2, Math.round(near / 3)); }
        const farPos = stratifiedPositions(far), nearPos = stratifiedPositions(near);
        for (let i = 0; i < far; i++) {
          const dur = ((0.9 + Math.random() * 0.4) * spd).toFixed(2);
          o.appendChild(el(
            'position:absolute;top:-12vh;left:' + farPos[i] + '%;' +
            'width:2px;height:' + (12+Math.random()*10) + 'px;' +
            'background:linear-gradient(transparent,rgba(170,190,220,.5));' +
            'transform:' + skew + ';' +
            'animation:wxfall ' + dur + 's linear ' + (-Math.random()*dur).toFixed(2) + 's infinite backwards'
          )); pc++;
        }
        for (let i = 0; i < near; i++) {
          const dur = ((0.45 + Math.random() * 0.25) * spd).toFixed(2);
          o.appendChild(el(
            'position:absolute;top:-12vh;left:' + nearPos[i] + '%;' +
            'width:3px;height:' + (22+Math.random()*14) + 'px;' +
            'background:linear-gradient(transparent,rgba(200,218,245,.75));' +
            'transform:' + skew + ';' +
            'animation:wxfall ' + dur + 's linear ' + (-Math.random()*dur).toFixed(2) + 's infinite backwards' +
            (lite ? '' : ';filter:blur(.3px)')
          )); pc++;
        }
        if (precip === 'storm') {
          o.appendChild(el('position:absolute;inset:0;box-shadow:inset 0 0 120px rgba(0,0,10,.5)'));
          const f = el('position:absolute;inset:0;background:radial-gradient(80% 60% at 50% 0%,#fff,transparent 70%);opacity:0;transition:opacity .1s');
          o.appendChild(f);
          o._t.push(setInterval(() => {
            f.style.opacity = '.4'; setTimeout(() => (f.style.opacity = '0'), 80);
            setTimeout(() => { f.style.opacity = '.22'; setTimeout(() => (f.style.opacity = '0'), 60); }, 180);
          }, 4200 + Math.random() * 4800));
        }
      } else if (precip === 'snow') {
        let n = intensity === 'heavy' ? 18 : 12;
        if (lite) n = Math.max(3, Math.round(n / 3));
        const snowPos = stratifiedPositions(n);
        for (let i = 0; i < n; i++) {
          const dur = ((3.4 + Math.random() * 2.4) * spd).toFixed(2);
          const sz = 3 + Math.random() * 4;
          o.appendChild(el(
            'position:absolute;top:-8vh;left:' + snowPos[i] + '%;' +
            'width:' + sz + 'px;height:' + sz + 'px;' +
            'border-radius:50%;' +
            'background:rgba(255,255,255,' + (0.55+Math.random()*0.3).toFixed(2) + ');' +
            'box-shadow:0 0 ' + sz + 'px rgba(255,255,255,.5);' +
            'animation:wxsnow ' + dur + 's linear ' + (-Math.random()*dur).toFixed(2) + 's infinite backwards'
          )); pc++;
        }
      }

      if (precip === 'none' && light === 'day') {
        o.appendChild(el('position:absolute;top:-14%;right:-8%;width:70vw;height:70vw;background:radial-gradient(circle at 78% 18%, rgba(255,228,165,.18), transparent 55%);animation:wxray 6s ease-in-out infinite backwards'));
        o.appendChild(el('position:absolute;top:0;right:10%;width:32vw;height:3px;background:linear-gradient(90deg,transparent,rgba(255,235,180,.12),transparent);transform:rotate(24deg);transform-origin:right top;animation:wxray 7s ease-in-out .8s infinite backwards'));
      }
      if (light === 'dawn' || light === 'dusk') {
        o.appendChild(el('position:absolute;bottom:-6%;left:0;right:0;height:34%;background:linear-gradient(0deg,' + (light==='dawn'?'rgba(255,190,120,.10)':'rgba(180,80,50,.10)') + ',transparent);animation:wxfog 9s ease-in-out infinite backwards'));
      }
      if (wind === 'strong' || wind === 'breezy') {
        /* FIX: "breezy" used to fall through this block entirely (only 'strong' was checked),
           so picking Breezy in Manual Control produced nothing. Now breezy reuses the same
           gust effect as strong, just lighter: fewer streaks, slower (= less frequent
           passes across the screen), thinner, and fainter. */
        const isStrong = wind === 'strong';
        let gustCount = isStrong ? 3 : 2;
        if (lite) gustCount = 1;
        for (let i = 0; i < gustCount; i++) {
          const durBase = isStrong ? (1.6 + Math.random() * 0.8) : (2.8 + Math.random() * 1.2);
          const dur = (durBase * spd).toFixed(2);
          const width = isStrong ? 28 : 18;
          const alpha = isStrong ? '.55' : '.32';
          o.appendChild(el(
            'position:absolute;top:' + (18+i*26) + '%;left:0;width:' + width + 'vw;height:1.5px;' +
            'border-radius:999px;background:linear-gradient(90deg,transparent,rgba(220,228,240,' + alpha + '),transparent);' +
            'animation:wxgust ' + dur + 's linear ' + (-Math.random()*dur).toFixed(2) + 's infinite backwards'
          ));
        }
      }

      dlog('paint() done — particles:', pc, 'children:', o.children.length, 'inDOM:', document.contains(o));
    } catch (e) {
      console.error('[wx-overlay] paint() ERROR:', e);
    }
  }

  /* ── parse weather tag: bracket form (regex-cleaner-safe) or legacy <wx> ── */
  function parseWx(text) {
    let m = /\[wx:([^\]]*)\]/i.exec(text || '');
    if (!m) m = /<wx>([\s\S]*?)<\/wx>/i.exec(text || '');
    if (!m) return null;
    const r = m[1].toLowerCase(), has = (w) => r.includes(w);
    return {
      precip: has('storm') ? 'storm' : has('rain') ? 'rain' : has('snow') ? 'snow' : 'none',
      intensity: has('heavy') ? 'heavy' : 'light',
      wind: has('strong') ? 'strong' : has('breez') ? 'breezy' : 'calm',
      light: has('night') ? 'night' : has('dusk') ? 'dusk' : has('dawn') ? 'dawn' : 'day',
    };
  }

  /* ── onMsg — always re-syncs to whatever the CURRENT last message says ──
     clear/stop are idempotent (safe to call even if already cleared), so they run
     unconditionally here — do NOT gate them behind lastWeatherKey, since requestResync()
     nulls that out before calling onMsg() precisely so a same-state repaint can happen;
     gating clear on it too would make clear silently never fire on a resync (real bug, fixed). */
  function onMsg() {
    if (S().freeMode) return;               // Free Mode: manual control owns the overlay, chat never overrides it
    if (Date.now() < testModeUntil) return; // a Test preview is showing — don't sync over it
    try {
      const ctx = C();
      if (!ctx || !ctx.chat || !ctx.chat.length) {
        const wasSomething = lastWeatherKey !== null || !!document.getElementById(OVERLAY_ID);
        lastWeatherKey = null; clearOverlay(); stopAudio();
        if (wasSomething) setStatus(t('status_nomsg'));
        return;
      }
      const st = parseWx(ctx.chat[ctx.chat.length - 1].mes);
      if (st) {
        const key = JSON.stringify(st);
        if (key !== lastWeatherKey) {
          lastWeatherKey = key;
          paint(st);
          setStatus(t('status_last') + ' ' + st.precip + '/' + st.intensity + ' \u00b7 ' + st.wind + ' \u00b7 ' + st.light);
        }
      } else {
        const wasSomething = lastWeatherKey !== null || !!document.getElementById(OVERLAY_ID);
        lastWeatherKey = null;
        clearOverlay(); stopAudio();
        if (wasSomething) setStatus(t('status_notag'));
      }
    } catch (e) { console.warn('[wx-overlay] onMsg error:', e); setStatus('error: ' + e.message); }
  }

  /* single debounced resync so rapid-fire events (delete+regenerate) don't overlap */
  let resyncTimer = null;
  function requestResync(delay) {
    clearTimeout(resyncTimer);
    resyncTimer = setTimeout(() => { lastWeatherKey = null; onMsg(); }, delay == null ? 150 : delay);
  }

  /* ── console/global test hook ── */
  window.wxTest = function (preset) {
    const legacy = { storm: 'storm', rain: 'rainH', snow: 'snowH', clear: 'day' };
    const key = legacy[preset] || preset;
    const p = TEST_PRESETS[key];
    testModeUntil = Date.now() + 4000;
    if (p) { lastWeatherKey = null; paint(p.st); setStatus(t('status_test') + ' ' + bi(p.label)); }
    else { clearOverlay(); stopAudio(); setStatus(t('status_cleared')); }
  };

  /* ══════════════════════════ settings panel ══════════════════════════ */
  function toggleRow(id, ttlKey, subKey, checked) {
    return '<div class="wx-toggle-row"><div class="txt"><div class="ttl">' + t(ttlKey) + '</div><div class="sub">' + t(subKey) + '</div></div>' +
      '<label class="wx-switch"><input id="' + id + '" type="checkbox"' + (checked ? ' checked' : '') + '><span class="sl"></span></label></div>';
  }

  function buildPanelHtml() {
    const s = S();
    const audioRows = AUDIO_KEYS.map(([key, icon, label]) => {
      const url = s.audio[key] || '';
      const vol = s.volumes[key] != null ? s.volumes[key] : 100;
      return (
        '<div class="wx-audiorow">' +
          '<div class="top">' +
            '<span class="name">' + icon + ' ' + bi(label) + '</span>' +
            '<input type="text" id="aw_url_' + key + '" placeholder="https://.../sound.mp3" value="' + url.replace(/"/g,'&quot;') + '">' +
            '<button class="prev" id="aw_prev_' + key + '" type="button">▶</button>' +
          '</div>' +
          '<div class="wx-volrow' + (url ? ' show' : '') + '" id="aw_volrow_' + key + '">' +
            '<span class="vlbl">🔊</span>' +
            '<input type="range" id="aw_vol_' + key + '" min="0" max="100" value="' + vol + '">' +
            '<span class="vlbl" id="aw_vollbl_' + key + '">' + vol + '%</span>' +
          '</div>' +
          '<div class="wx-err" id="aw_err_' + key + '"></div>' +
        '</div>'
      );
    }).join('');

    const testButtons = Object.keys(TEST_PRESETS).map((key) => {
      const p = TEST_PRESETS[key];
      return '<div class="wx-testbtn" data-preset="' + key + '"><span class="ic">' + p.icon + '</span><span>' + bi(p.label) + '</span></div>';
    }).join('');

    return `
    <div class="wx-panel-root">
    <div class="inline-drawer">
      <div class="inline-drawer-toggle inline-drawer-header">
        <b>\u{1F326} Ambient Weather Overlay</b>
        <div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div>
      </div>
      <div class="inline-drawer-content wx-panel">

        <div class="wx-section">
          <div class="wx-sectitle">\u{1F310} Язык</div>
          <select id="aw_lang" class="wx-langsel">
            <option value="en"${s.lang === 'en' ? ' selected' : ''}>Русский</option>
            <option value="th"${s.lang === 'th' ? ' selected' : ''}>\u0e44\u0e17\u0e22</option>
          </select>
        </div>

        <div class="wx-section">
          <div class="wx-sectitle">${t('sec_general')}</div>
          ${toggleRow('aw_enabled', 'enabled_ttl', 'enabled_sub', s.enabled)}
          ${toggleRow('aw_force', 'force_ttl', 'force_sub', s.forceMotion)}
          ${toggleRow('aw_lite', 'lite_ttl', 'lite_sub', s.liteMode)}
          ${toggleRow('aw_debug', 'debug_ttl', 'debug_sub', s.debugLog)}
          ${toggleRow('aw_free', 'free_ttl', 'free_sub', s.freeMode)}
        </div>

        <div class="wx-section">
          <div class="wx-sectitle">${t('sec_volume')}</div>
          <div class="wx-row"><span class="lbl">\u{1F50A}</span><input type="range" id="aw_mastervol" min="0" max="100" value="${s.masterVolume}"><span class="vlbl" id="aw_mastervol_lbl" style="width:38px;text-align:right;font-size:.82em">${s.masterVolume}%</span></div>
          <div class="wx-doc">${t('doc')}</div>
          ${audioRows}
        </div>

        <div class="wx-section">
          <div class="wx-sectitle">${t('sec_speed')}</div>
          <div class="wx-row"><span class="lbl">\u{1F3C3}</span><input type="range" id="aw_speed" min="25" max="300" step="5" value="${s.particleSpeed}"><span class="vlbl" id="aw_speed_lbl" style="width:42px;text-align:right;font-size:.82em">${s.particleSpeed}%</span></div>
          <div style="font-size:.76em;opacity:.6">${t('speed_sub')}</div>
        </div>

        ${s.freeMode ? `
        <div class="wx-section">
          <div class="wx-sectitle">${t('sec_manual')}</div>
          <div class="wx-doc" style="margin-bottom:2px">${t('manual_hint')}</div>
          <div class="wx-row"><span class="lbl" style="min-width:92px;text-align:left;opacity:.85">${t('lbl_precip')}</span>
            <select id="aw_m_precip" style="flex:1;background:#0e0f13;border:1px solid #333844;color:#ddd;border-radius:6px;padding:6px 8px;font-size:.85em">
              <option value="none"${s.manual.precip==='none'?' selected':''}>${t('opt_precip_none')}</option>
              <option value="rain"${s.manual.precip==='rain'?' selected':''}>${t('opt_precip_rain')}</option>
              <option value="storm"${s.manual.precip==='storm'?' selected':''}>${t('opt_precip_storm')}</option>
              <option value="snow"${s.manual.precip==='snow'?' selected':''}>${t('opt_precip_snow')}</option>
            </select>
          </div>
          <div class="wx-row"><span class="lbl" style="min-width:92px;text-align:left;opacity:.85">${t('lbl_intensity')}</span>
            <select id="aw_m_intensity" style="flex:1;background:#0e0f13;border:1px solid #333844;color:#ddd;border-radius:6px;padding:6px 8px;font-size:.85em">
              <option value="light"${s.manual.intensity==='light'?' selected':''}>${t('opt_intensity_light')}</option>
              <option value="heavy"${s.manual.intensity==='heavy'?' selected':''}>${t('opt_intensity_heavy')}</option>
            </select>
          </div>
          <div class="wx-row"><span class="lbl" style="min-width:92px;text-align:left;opacity:.85">${t('lbl_wind')}</span>
            <select id="aw_m_wind" style="flex:1;background:#0e0f13;border:1px solid #333844;color:#ddd;border-radius:6px;padding:6px 8px;font-size:.85em">
              <option value="calm"${s.manual.wind==='calm'?' selected':''}>${t('opt_wind_calm')}</option>
              <option value="breezy"${s.manual.wind==='breezy'?' selected':''}>${t('opt_wind_breezy')}</option>
              <option value="strong"${s.manual.wind==='strong'?' selected':''}>${t('opt_wind_strong')}</option>
            </select>
          </div>
          <div class="wx-row"><span class="lbl" style="min-width:92px;text-align:left;opacity:.85">${t('lbl_light')}</span>
            <select id="aw_m_light" style="flex:1;background:#0e0f13;border:1px solid #333844;color:#ddd;border-radius:6px;padding:6px 8px;font-size:.85em">
              <option value="dawn"${s.manual.light==='dawn'?' selected':''}>${t('opt_light_dawn')}</option>
              <option value="day"${s.manual.light==='day'?' selected':''}>${t('opt_light_day')}</option>
              <option value="dusk"${s.manual.light==='dusk'?' selected':''}>${t('opt_light_dusk')}</option>
              <option value="night"${s.manual.light==='night'?' selected':''}>${t('opt_light_night')}</option>
            </select>
          </div>
        </div>` : `
        <div class="wx-section">
          <div class="wx-sectitle">${t('sec_test')}</div>
          <button class="wx-reloadbtn" id="aw_reload" type="button">${t('reload_btn')}</button>
          <div class="wx-testgrid" id="aw_testgrid">${testButtons}</div>
        </div>`}

        <div id="aw_status" style="opacity:.7;font-size:.85em;margin-top:9px">${t('status_ready')}</div>
        <span class="wx-resetlink" id="aw_reset">${t('reset_link')}</span>

        <div style="text-align:center;font-size:.72em;opacity:.5;margin:12px 0 2px;line-height:1.7">
          Авторы: xo.nara и Claude<br>
          Тестирование: zealllll<br>
          v${EXT_VERSION}
        </div>

      </div>
    </div>
    </div>`;
  }

  function wireAudioRow(key) {
    const urlInput = document.getElementById('aw_url_' + key);
    const volRow   = document.getElementById('aw_volrow_' + key);
    const volInput = document.getElementById('aw_vol_' + key);
    const volLbl   = document.getElementById('aw_vollbl_' + key);
    const errSpan  = document.getElementById('aw_err_' + key);
    const prevBtn  = document.getElementById('aw_prev_' + key);
    if (!urlInput) return;

    urlInput.addEventListener('input', function () {
      const v = this.value.trim();
      S().audio[key] = v; saveS();
      volRow.classList.toggle('show', !!v);
      errSpan.textContent = (v && !/^https?:\/\//i.test(v)) ? t('err_bad_url') : '';
      if (curKey === key || (key === 'wind_strong' && windEl)) { stopAudio(); requestResync(50); }
    });

    volInput.addEventListener('input', function () {
      const v = parseInt(this.value, 10);
      S().volumes[key] = v; saveS();
      volLbl.textContent = v + '%';
      if (curKey === key && curEl) curEl.volume = volFor(key);
      if (key === 'wind_strong' && windEl) windEl.volume = windVolume();
    });

    prevBtn.addEventListener('click', function () { previewToggle(key, urlInput.value.trim(), prevBtn, errSpan); });
  }

  function rebuildPanel() {
    const old = document.querySelector('.wx-panel-root');
    if (old) old.remove();
    addPanel();
  }

  function addPanel(tries) {
    if (document.getElementById('aw_enabled')) return;
    const host = document.querySelector('#extensions_settings2') || document.querySelector('#extensions_settings');
    if (!host) { if ((tries || 0) < 20) setTimeout(() => addPanel((tries || 0) + 1), 500); return; }

    const wrap = document.createElement('div');
    wrap.innerHTML = buildPanelHtml();
    host.appendChild(wrap.firstElementChild);

    document.getElementById('aw_lang').addEventListener('change', function () {
      S().lang = this.value; saveS(); rebuildPanel();
    });

    document.getElementById('aw_enabled').addEventListener('change', function () {
      S().enabled = this.checked; saveS(); lastWeatherKey = null;
      if (!this.checked) { clearOverlay(); stopAudio(); } else onMsg();
    });
    document.getElementById('aw_force').addEventListener('change', function () {
      S().forceMotion = this.checked; saveS(); lastWeatherKey = null; onMsg();
    });
    document.getElementById('aw_lite').addEventListener('change', function () {
      S().liteMode = this.checked; saveS(); lastWeatherKey = null; onMsg();
    });
    document.getElementById('aw_debug').addEventListener('change', function () {
      S().debugLog = this.checked; saveS();
    });
    document.getElementById('aw_free').addEventListener('change', function () {
      const checked = this.checked;
      S().freeMode = checked; saveS();
      testModeUntil = 0;
      lastWeatherKey = null;
      if (checked) paint(S().manual); else onMsg();
      rebuildPanel(); // switches the Test-grid section <-> Manual Control section
      if (checked) {
        const m = S().manual;
        setStatus(t('status_manual') + ' ' + m.precip + '/' + m.intensity + ' \u00b7 ' + m.wind + ' \u00b7 ' + m.light);
      }
    });

    const mv = document.getElementById('aw_mastervol');
    const mvl = document.getElementById('aw_mastervol_lbl');
    mv.addEventListener('input', function () {
      const v = parseInt(this.value, 10);
      S().masterVolume = v; saveS();
      mvl.textContent = v + '%';
      if (curEl) curEl.volume = volFor(curKey);
      if (windEl) windEl.volume = windVolume();
    });

    const sp = document.getElementById('aw_speed');
    const spl = document.getElementById('aw_speed_lbl');
    sp.addEventListener('input', function () {
      const v = parseInt(this.value, 10);
      S().particleSpeed = v; saveS();
      spl.textContent = v + '%';
    });

    AUDIO_KEYS.forEach(([key]) => wireAudioRow(key));

    document.getElementById('aw_reload') && document.getElementById('aw_reload').addEventListener('click', () => {
      testModeUntil = 0; // cancel any active Test preview — Reload means "sync to reality now"
      clearOverlay(); stopAudio();
      lastWeatherKey = null;
      onMsg();
      setStatus(t('status_reloaded'));
    });

    document.getElementById('aw_testgrid') && document.getElementById('aw_testgrid').addEventListener('click', (e) => {
      const b = e.target.closest('.wx-testbtn'); if (!b) return;
      const preset = TEST_PRESETS[b.dataset.preset]; if (!preset) return;
      testModeUntil = Date.now() + 4000; // keep the preview visible for a few seconds, undisturbed by auto-resync
      lastWeatherKey = null; paint(preset.st); setStatus(t('status_test') + ' ' + bi(preset.label));
    });

    /* Manual Control (only present while Free Mode is on) — any change applies instantly */
    if (document.getElementById('aw_m_precip')) {
      const applyManual = () => {
        const m = S().manual;
        m.precip    = document.getElementById('aw_m_precip').value;
        m.intensity = document.getElementById('aw_m_intensity').value;
        m.wind      = document.getElementById('aw_m_wind').value;
        m.light     = document.getElementById('aw_m_light').value;
        saveS();
        lastWeatherKey = null;
        paint(m);
        setStatus(t('status_manual') + ' ' + m.precip + '/' + m.intensity + ' \u00b7 ' + m.wind + ' \u00b7 ' + m.light);
      };
      ['aw_m_precip', 'aw_m_intensity', 'aw_m_wind', 'aw_m_light'].forEach((id) => {
        document.getElementById(id).addEventListener('change', applyManual);
      });
    }

    document.getElementById('aw_reset').addEventListener('click', () => {
      if (!confirm(t('reset_confirm'))) return;
      const ctx = C();
      if (ctx) { if (!ctx.extensionSettings) ctx.extensionSettings = {}; ctx.extensionSettings[MODULE_NAME] = JSON.parse(JSON.stringify(DEFAULTS)); }
      saveS();
      clearOverlay(); stopAudio(); lastWeatherKey = null;
      rebuildPanel();
      setStatus(t('status_reset'));
    });
  }

  /* ══════════════════════════ event binding ══════════════════════════ */
  let bound = false;
  let moObserver = null;
  let pollTimer = null;

  function bindEvents() {
    if (bound) return;
    const ctx = C();
    if (!ctx || !ctx.eventSource) return;

    const E = ctx.event_types || ctx.eventTypes || {};

    /* covers: new message, regenerate, delete, edit, swipe, abort, chat switch */
    const eventsToBind = [
      ['CHARACTER_MESSAGE_RENDERED', 'character_message_rendered'],
      ['MESSAGE_RECEIVED',           'message_received'],
      ['GENERATION_ENDED',           'generation_ended'],
      ['GENERATION_STARTED',         'generation_started'],
      ['GENERATION_STOPPED',         'generation_stopped'],
      ['CHAT_CHANGED',               'chat_changed'],
      ['MESSAGE_SWIPED',             'message_swiped'],
      ['MESSAGE_DELETED',            'message_deleted'],
      ['MESSAGE_EDITED',             'message_edited'],
    ];

    let count = 0;
    eventsToBind.forEach(([key, fallback]) => {
      const evtName = E[key] || fallback;
      if (evtName) {
        try { ctx.eventSource.on(evtName, () => requestResync(150)); count++; }
        catch (e) { console.warn('[wx-overlay] bind fail:', key); }
      }
    });

    const userEvt = E.USER_MESSAGE_RENDERED || 'user_message_rendered';
    if (userEvt) { try { ctx.eventSource.on(userEvt, () => requestResync(150)); count++; } catch (e) {} }

    dlog('Bound', count, 'events');

    /* MutationObserver — catches DOM changes even if an ST event name differs by version,
       or if delete/regenerate animates the DOM (fade/collapse) without firing a message event. */
    try {
      const chat = document.getElementById('chat');
      if (chat && !moObserver) {
        moObserver = new MutationObserver(() => {
          clearTimeout(pollTimer);
          pollTimer = setTimeout(() => requestResync(0), 250);
        });
        moObserver.observe(chat, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['style', 'class'] });
        dlog('MutationObserver active on #chat');
      }
    } catch (e) { console.warn('[wx-overlay] MO failed:', e); }

    /* Click-delegation fallback — delete/regenerate/edit-save are all clicks somewhere
       inside #chat. Catching the click itself resyncs the instant the user acts, regardless
       of what that button is named or which ST version/theme is in use. */
    try {
      const chat2 = document.getElementById('chat');
      if (chat2 && !chat2._wxClickBound) {
        chat2._wxClickBound = true;
        chat2.addEventListener('click', () => requestResync(250), true);
      }
    } catch (e) {}

    bound = true;
    setStatus(t('status_ready'));
    dlog('v' + EXT_VERSION + ' ready \u2713');
  }

  function init() {
    addPanel();
    bindEvents();
    onMsg();
    setInterval(() => { if (S().enabled && !document.hidden) onMsg(); }, 1200); // fast periodic safety net
  }

  function whenReady() {
    const ctx = C();
    if (ctx && ctx.eventSource) {
      const E = ctx.event_types || ctx.eventTypes || {};
      if (E.APP_READY) { try { ctx.eventSource.on(E.APP_READY, init); } catch (e) { setTimeout(init, 1200); } }
      setTimeout(() => { if (!bound) init(); }, 2500);
    } else {
      setTimeout(whenReady, 400);
    }
  }
  whenReady();
})();
